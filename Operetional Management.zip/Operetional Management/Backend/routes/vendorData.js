const express = require('express');
const router=express.Router();
const  VendorModel  = require('../model/vendors');
const bodyparser=require('body-parser');
router.use(bodyparser.json());


//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')


router.post('/create',async (req,res)=>{   
    try
    {           
        
        let data = new VendorModel({ 
                companyName:req.body.companyName,
                name:req.body.name,
                contactNumber:req.body.contactNumber,
                email:req.body.email,
                website:req.body.website,
                address:req.body.address
                        
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
    }
  })
   router.get('/read',async(req,res)=>{
    try
    {      
      console.log("read");
      const data=await VendorModel.find();
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Vendor found"+err.message});
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await VendorModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Vendor deleted"});
          console.log(error);
      }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {
      console.log("start")
      let id=req.params.id;
        const data =await VendorModel.findOne({"_id": id});
       res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Vendor found"});
    }
    })
    router.put('/update',async(req,res)=>{
      try {     
      const postData= await VendorModel.findOneAndUpdate({"_id":req.body._id},req.body)
      res.status(200).send({success:true,msg:'postData',data:postData})
        
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
     console.log(error.message);
    }       
    })
  module.exports= router;