const express = require('express');
const router=express.Router();
const  ItemModel  = require('../model/items');
const  InventoryModel  = require('../model/inventories');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.use(bodyparser.urlencoded({extented:true}));
const multer = require('multer');
const path = require('path');
const { stringify } = require('querystring');
router.use(express.static('public'));

let storage=multer.diskStorage({
  destination:(req,file,callback) =>{
    callback(null,path.join(__dirname,'../public/ProductImage'),function(error,success){

      if(error){console.log(error)} else{console.log("success")}
    });
},
filename:(req,file,callback)=>{
  const name=Date.now()+'-'+file.originalname
  callback(null,name,function (error,success){
    if(error){console.log(error)} else{console.log("success")}
  });
}}
);
const upload= multer({storage:storage})


router.post('/create',upload.single('file'),async (req,res)=>{   
    try
    {      
                let data = new ItemModel({ 
                type:req.body.type,
                itemGroupName:req.body.itemGroupName,
                itemName:req.body.itemName,
                sku:req.body.sku,
              unit:req.body.unit,
              dimension:req.body.dimension,  
              weight:req.body.weight,
              manufacturer:req.body.manufacturer,

              brand:req.body.brand,
              sellingPrice:req.body.sellingPrice,
              costPrice:req.body.costPrice,  
              description:req.body.description,
              openingStock:req.body.openingStock,

              reorderPoint:req.body.reorderPoint,
              preferedVendor:req.body.preferedVendor,
             
              file: req.body.file==''?'': req.file.filename
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    }
  })

  router.post('/createInventory',async (req,res)=>{   
    try
    {                    
        let data = new InventoryModel({ 
          
                itemId:req.body.itemId,
                itemName:req.body.itemName,
                sku:req.body.sku,
                openingStock:req.body.openingStock,
                reorderPoint:req.body.reorderPoint,
                quantityOrdered:req.body.quantityOrdered,
                quantityIn:req.body.quantityIn,
                quantityOut:req.body.quantityOut,
               committedStock:req.body.committedStock,
               stockOnHand:req.body.stockOnHand,
               lastBillDate:req.body.lastBillDate
                
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    
    }
  })

  router.get('/readbygroup/:group', async(req,res)=>{
    try
    {
       
      let group=req.params.group;
      console.log(group);
        const data =await ItemModel.find({"itemGroupName": group});
       res.json(data);  
    }
    catch(err)
    {
        res.status(400).json({error:"No requirement find"});
        
    }
    })
  router.get('/read',async(req,res)=>{
    try
    {
      
      const data=await ItemModel.find();
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Items found"+err.message});
    }
    })
    router.get('/readInventory',async(req,res)=>{
      try
      {
        
        const data=await InventoryModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Inventory found"+err.message});
      }
      })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await ItemModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Item deleted"});
          console.log(error);
      }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {
      console.log("entered");  
      let id=req.params.id;
        const data =await ItemModel.findOne({"_id": id});
       res.json(data);  
    }
    catch(err)
    {
        res.status(400).json({error:"No Customer found"});
    }
    })
     router.get('/readoneitem/:id', async(req,res)=>{
    try
    {
      console.log("entered");  
      let id=req.params.id;
        const data =await InventoryModel.findOne({"itemId": id});
       res.json(data);  
    }
    catch(err)
    {
        res.status(400).json({error:"No Customer found"});
        console.log(message.err);
    }
    })
 router.put('/updateorderedQty/:id',async(req,res)=>{
    
    try {     
      
        let data = new InventoryModel({ 
          _id:req.params.id,
          quantityOrdered:req.body.quantityOrdered
        }
      )
      console.log(data,"data")
      let id=req.params.id; 
     const postData= await InventoryModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      console.log(error.message)
    }       
    })
    router.put('/updateQtyIn/:id',async(req,res)=>{
    
      try {     
        
          let data = new InventoryModel({ 
            _id:req.params.id,
            quantityIn:req.body.quantityIn
          }
        )
        console.log(data,"data")
        let id=req.params.id; 
       const postData= await InventoryModel.findByIdAndUpdate({"_id": id},data);    
       res.status(200).send({success:true,msg:'postData',data:postData})
       
      }
      catch (error)
      {
        res.status(400).send({success:false,msg:error.message})
        console.log(error.message)
      }       
      })
      router.put('/updateQtyOut/:id',async(req,res)=>{
    
        try {     
          
            let data = new InventoryModel({ 
              _id:req.params.id,
              quantityOut:req.body.quantityOut
            }
          )
          console.log(data,"data")
          let id=req.params.id; 
         const postData= await InventoryModel.findByIdAndUpdate({"_id": id},data);    
         res.status(200).send({success:true,msg:'postData',data:postData})
         
        }
        catch (error)
        {
          res.status(400).send({success:false,msg:error.message})
          console.log(error.message)
        }       
        })
        router.put('/updatecommittedStock/:id',async(req,res)=>{
    
          try {     
            
              let data = new InventoryModel({ 
                _id:req.params.id,
                committedStock:req.body.committedStock
              }
            )
            console.log(data,"data")
            let id=req.params.id; 
           const postData= await InventoryModel.findByIdAndUpdate({"_id": id},data);    
           res.status(200).send({success:true,msg:'postData',data:postData})
           
          }
          catch (error)
          {
            res.status(400).send({success:false,msg:error.message})
            console.log(error.message)
          }       
          })
          router.put('/updateStockonHand/:id',async(req,res)=>{
    
            try {     
              
                let data = new InventoryModel({ 
                  _id:req.params.id,
                  stockOnHand:req.body.stockOnHand,
                  lastBillDate:req.body.lastBillDate
                }
              )
              console.log(data,"data")
              let id=req.params.id; 
             const postData= await InventoryModel.findByIdAndUpdate({"_id": id},data);    
             res.status(200).send({success:true,msg:'postData',data:postData})
             
            }
            catch (error)
            {
              res.status(400).send({success:false,msg:error.message})
              console.log(error.message)
            }       
            })
            router.get('/inventorySummaryReport',async(req,res)=>{
              try
              {
               
                const data=await InventoryModel.aggregate([
            {
              $group : {_id:"$itemId",itemName:{"$first":"$itemName"}, sku:{"$first":"$sku"},
            openingStock:{"$first":"$openingStock"},reorderPoint:{"$first":"$reorderPoint"},
            quantityOrdered:{"$first":"$quantityOrdered"},quantityIn:{"$first":"$quantityIn"},
            quantityOut:{"$first":"$quantityOut"},stockOnHand:{"$first":"$stockOnHand"},
            committedStock:{"$first":"$committedStock"}
           
             }        
          },
          {
            $addFields:{ availableforSale: { $subtract: [ { $subtract: [ "$quantityIn", "$quantityOut" ] }, "$committedStock" ] }}
         }
        
        ])
                res.json(data);  
                
              }
              catch(err)
              {
                  res.status(400).json({error:"No Invoice found"+err.message});
                  console.log(err.message);
              }
              })
              router.get('/totalStockOnHand',async(req,res)=>{
                try
                {
                  console.log("fdsdfsdfsf");
                  const data=await InventoryModel.aggregate([
              {$group : {_id:"", Stock:{$sum:"$stockOnHand"}}}
             
            ])
                  res.json(data);  
                  console.log(data); 
                }
                catch(err)
                {
                    res.status(400).json({error:"No Inventory found"+err.message});
                    console.log(err.message);
                }
                })

             

  module.exports= router;