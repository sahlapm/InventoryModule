const express = require('express');
const router=express.Router();
const  DeliveryChallanModel  = require('../model/deliveryChallans');
const  DeliveryChallanDetailsModel  = require('../model/deliveryChallanDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>
{   
    try
    {        
        
        let data = new DeliveryChallanModel({ 
          
                customerId:req.body.customerId,
                customerName:req.body.customerName,
                deliveryChallanNumber:req.body.deliveryChallanNumber,
                reference:req.body.reference,
                date:req.body.date,
                challanType:req.body.challanType,
                wareHouseName:req.body.wareHouseName,
                subTotal:req.body.subTotal,
                discount:req.body.discount,
                total:req.body.total,
                status:req.body.status
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
      console.log(req.body);
             let data =await DeliveryChallanDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      
    }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      let id=req.params.id;
      const data =await DeliveryChallanModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Delivery Challan found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        console.log("entered");
        const data=await DeliveryChallanModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await DeliveryChallanDetailsModel.find({"deliveryChallanId": id});
      res.json(data);   
      console.log(data);
    }
    catch(err)
    {
        res.status(400).json({error:"No delivery Challan found"+err.message});
    }
    })
   

  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new DeliveryChallanModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await DeliveryChallanModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})      
    }       
    })


  module.exports= router;