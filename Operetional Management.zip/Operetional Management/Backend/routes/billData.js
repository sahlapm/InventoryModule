const express = require('express');
const router=express.Router();
const  BillModel  = require('../model/bills');
const  BillDetailsModel  = require('../model/billDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>{   
    try
    {           
       
        if(req.body.purchaseOrderId!='')
        {
        let data = new BillModel({ 
          
                vendorId:req.body.vendorId,
                purchaseOrderId:req.body.purchaseOrderId,
                vendorName:req.body.vendorName,
                billNumber:req.body.billNumber,
                purchaseOrderNumber:req.body.purchaseOrderNumber,
                sourceOfSupply:req.body.sourceOfSupply,
                date:req.body.date,
                terms:req.body.terms,
                dueDate:req.body.dueDate,
                subTotal:req.body.subTotal,
                discount:req.body.discount,
                total:req.body.total,
          paidAmount:req.body.paidAmount,
          dueAmount:req.body.total-req.body.paidAmount,
                status:req.body.status
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
              }
              else
              {
                let data = new BillModel({ 
          
                  vendorId:req.body.vendorId,
                
                  vendorName:req.body.vendorName,
                  invoiceNumber:req.body.invoiceNumber,
                 
                  sourceOfSupply:req.body.sourceOfSupply,
                  date:req.body.date,
                  dueDate:req.body.dueDate,
                  terms:req.body.terms,
                 
                  subTotal:req.body.subTotal,
                  discount:req.body.discount,
                  total:req.body.total,
            paidAmount:req.body.paidAmount,
            dueAmount:req.body.total-req.body.paidAmount,
                  status:req.body.status
                } )
                const postData= await data.save();
                res.status(200).send({success:true,msg:'postData',data:postData})

              }

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
   
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
        
             let data =await BillDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      
      
    }
  })
  router.put('/updatePaidAmount/:id',async(req,res)=>{
    
    try {     
      
        let data = new BillModel({ 
         _id:req.params.id,
          paidAmount:req.body.paidAmount,
          dueAmount:req.body.dueAmount
        }
      )
 
      let id=req.params.id;  
     const postData= await BillModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      console.log(error.message);
    }       
    })

  /*
  router.put('/updatePaidAmount',async (req,res)=>{   
    try
    {           
         console.log(req.body);
             let data =await InvoiceModel.findByIdAndUpdate({"_id": req.body.invoiceId},req.body);
             findByIdAndUpdate({"_id": id},data); 
             res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
      
    }
  })
  */
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
     
      let id=req.params.id;
      const data =await BillModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Bills found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        
        const data=await BillModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Bills found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await BillDetailsModel.find({"billId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No bill details found"+err.message});
    }
    })
    router.get('/billByVendor/:id',async(req,res)=>{
    try
    {
    
      let id=req.params.id;
      const data =await BillModel.find({"$and":[{"vendorId": id},{["dueAmount"]:{$gt:0}}]});
      res.json(data);   
      
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
        
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesOrderModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Adjustment deleted"});
        
      }
  })
  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new BillModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await BillModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      
    }       
    })
  
  

      router.get('/monthwisesPurchase',async(req,res)=>{
        try
        {
          console.log("Checking");
          const data=await BillModel.aggregate([
            {$project :{'total':true,
            'month':{$month:'$date'}}},
      {$group : {_id:"$month", sales:{$sum:"$total"},
      month:{"$first":"$month"}
    }},
    {$sort:{"_id":1}},
    {$addFields:{
      month:{
        $let:{
          vars:{
            monthsInString:[,'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
          },
          in:{
            $arrayElemAt:['$$monthsInString','$month']
          }
        }
      }
    }}
    ])
          res.json(data);  
          console.log(data); 
        }
        catch(err)
        {
            res.status(400).json({error:"No Bill found"+err.message});
            console.log(err.message);
        }
        })
  module.exports= router;