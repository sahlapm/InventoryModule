const express = require('express');
const router=express.Router();
const  InvoiceModel  = require('../model/invoices');
const  InvoiceDetailsModel  = require('../model/invoiceDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');


router.post('/create',async (req,res)=>{   
    try
    {           
        console.log(req.body);
        if(req.body.salesOrderId!='')
        {
        let data = new InvoiceModel({ 
          
                customerId:req.body.customerId,
                salesOrderId:req.body.salesOrderId,
                customerName:req.body.customerName,
                invoiceNumber:req.body.invoiceNumber,
                salesOrderNumber:req.body.salesOrderNumber,
                placeOfSupply:req.body.placeOfSupply,
                date:req.body.date,
                terms:req.body.terms,
                salesPerson:req.body.salesPerson,
                subTotal:req.body.subTotal,
                discount:req.body.discount,
                total:req.body.total,
          paidAmount:req.body.paidAmount,
          dueAmount:req.body.total-req.body.paidAmount,
                status:req.body.status
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
              }
              else
              {
                let data = new InvoiceModel({ 
          
                  customerId:req.body.customerId,                
                  customerName:req.body.customerName,
                  invoiceNumber:req.body.invoiceNumber,                 
                  placeOfSupply:req.body.placeOfSupply,
                  date:req.body.date,
                  terms:req.body.terms,
                  salesPerson:req.body.salesPerson,
                  subTotal:req.body.subTotal,
                  discount:req.body.discount,
                  total:req.body.total,
            paidAmount:req.body.paidAmount,
            dueAmount:req.body.total-req.body.paidAmount,
                  status:req.body.status
                } )
                const postData= await data.save();
                res.status(200).send({success:true,msg:'postData',data:postData})

              }

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
         console.log(req.body);
             let data =await InvoiceDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
      
    }
  })
  router.put('/updatePaidAmount/:id',async(req,res)=>{
    
    try {     
      console.log(req.body);
        let data = new InvoiceModel({ 
         _id:req.params.id,
          paidAmount:req.body.paidAmount,
          dueAmount:req.body.dueAmount
        }
      )
      
      let id=req.params.id;  
     const postData= await InvoiceModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
    
    }       
    })
    router.get('/productsaleReport',async(req,res)=>{
      try
      {
        
        const data=await InvoiceDetailsModel.aggregate([
    {
      $group : {_id:"$itemId",file:{"$first":"$file"},SKU:{"$first":"$sku"}, Name:{"$first":"$itemName"},Price:{"$first":"$sellingPrice"}, QtySold:{$sum:"$quantity"},SalePrice:{$sum:"$rate"}}
    },
    {$sort:{"QtySold":-1}}
  ])
        
    res.json(data);  
       
      }
      catch(err)
      {
          res.status(400).json({error:"No Invoice found"+err.message});          
      }
      })
       router.get('/productwisesalegraph',async(req,res)=>{
      try
      {        
        const data=await InvoiceDetailsModel.aggregate([
    {$group : {_id:"$itemId",Name:{"$first":"$itemName"},sales:{$sum:"$rate"}}}])
        res.json(data);  
       
      }
      catch(err)
      {
          res.status(400).json({error:"No Invoice found"+err.message});          
      }
      })
      router.get('/monthwisesalegraph1',async(req,res)=>{
        try
        {
          const data=await InvoiceModel.aggregate([
      {$group : {_id:"$date",'month':{$month:'$date'}, sales:{$sum:"$rate"}}}])
          res.json(data);           
        }
        catch(err)
        {
            res.status(400).json({error:"No Invoice found"+err.message});
            console.log(err.message);
        }
        })

        router.get('/monthwisesalegraph',async(req,res)=>{
          try
          {
              const data=await InvoiceModel.aggregate([
              {$project :{'total':true,
              'month':{$month:'$date'}}},
        {$group : {_id:"$month", sales:{$sum:"$total"},
        month:{"$first":"$month"}
      }},
      {$sort:{"_id":1}},
      {$addFields:{
        month:{
          $let:{
            vars:{
              monthsInString:[,'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
            },
            in:{
              $arrayElemAt:['$$monthsInString','$month']
            }
          }
        }
      }}
      ])
            res.json(data);       
          }
          catch(err)
          {
              res.status(400).json({error:"No Invoice found"+err.message});
              console.log(err.message);
          }
          })

          
        router.get('/customerwisesale',async(req,res)=>{
          try
          {           
            const data=await InvoiceModel.aggregate([
        {$group : {_id:"$customerId", name:{"$first":"$customerName"}, invoiceCount:{$count:{}},Sales:{$sum:"$total"}}},
        {$sort:{"Sales":-1}}
      ])
            res.json(data);  
     
          }
          catch(err)
          {
              res.status(400).json({error:"No Invoice found"+err.message});
              console.log(err.message);
          }
          })
          router.get('/itemwisesale',async(req,res)=>{
            try
            {
              const data=await InvoiceDetailsModel.aggregate([
          {$group : {_id:"$itemId", name:{"$first":"$itemName"}, invoiceCount:{$count:{}},Sales:{$sum:"$rate"}}},
          {$sort:{"Sales":-1}}
        ])
              res.json(data);  
            }
            catch(err)
            {
                res.status(400).json({error:"No Invoice found"+err.message});
             
            }
            })
            

  /*
  router.put('/updatePaidAmount',async (req,res)=>{   
    try
    {           
         console.log(req.body);
             let data =await InvoiceModel.findByIdAndUpdate({"_id": req.body.invoiceId},req.body);
             findByIdAndUpdate({"_id": id},data); 
             res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
      
    }
  })
  */
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      console.log("entered");
      let id=req.params.id;
      const data =await InvoiceModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        
        const data=await InvoiceModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Invoice found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await InvoiceDetailsModel.find({"invoiceId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
    }
    })
    router.get('/invoiceByCustomer/:id',async(req,res)=>{
    try
    {
      console.log("started")
      let id=req.params.id;
      const data =await InvoiceModel.find({"$and":[{"customerId": id},{["dueAmount"]:{$gt:0}}]});
      res.json(data);   
      
    }
    catch(err)
    {
        res.status(400).json({error:"No Invoice found"+err.message});
        console.log(err.message);
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesOrderModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Adjustment deleted"});
        
      }
  })
  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new InvoiceModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await InvoiceModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      
    }       
    })  
  
  module.exports= router;