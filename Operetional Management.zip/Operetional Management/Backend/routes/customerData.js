const express = require('express');
const router=express.Router();
const  CustomerModel  = require('../model/customers');
const bodyparser=require('body-parser');
router.use(bodyparser.json());


//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')


router.post('/create',async (req,res)=>{   
    try
    {           
        
        let data = new CustomerModel({ 
                type:req.body.type,
                name:req.body.name,
                contactNumber:req.body.contactNumber,
                email:req.body.email,
                website:req.body.website,
                address:req.body.address,
                creditPeriod:req.body.creditPeriod,
                creditLimit:req.body.creditLimit              
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
    }
  })
   router.get('/read',async(req,res)=>{
    try
    {      
      console.log("read");
      const data=await CustomerModel.find();
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Customer found"+err.message});
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await CustomerModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Customer deleted"});
          console.log(error);
      }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {
      
      let id=req.params.id;
        const data =await CustomerModel.findOne({"_id": id});
       res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Customer found"});
    }
    })
    router.put('/update',async(req,res)=>{
      try {     
      const postData= await CustomerModel.findOneAndUpdate({"_id":req.body._id},req.body)
      res.status(200).send({success:true,msg:'postData',data:postData})
        
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
     console.log(error.message);
    }       
    })
  module.exports= router;