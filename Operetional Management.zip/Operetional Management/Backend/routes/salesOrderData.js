const express = require('express');
const router=express.Router();
const  SalesOrderModel  = require('../model/salesOrders');
const  SalesOrderDetailsModel  = require('../model/salesOrderDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>{   
    try
    {           
        
        let data = new SalesOrderModel({ 
          
                customerId:req.body.customerId,
                customerName:req.body.customerName,
                salesOrderNumber:req.body.salesOrderNumber,
                reference:req.body.reference,
                date:req.body.date,
                expectedShipmentDate:req.body.expectedShipmentDate,
                deliveryMethod:req.body.deliveryMethod,
                description:req.body.discription,
                subTotal:req.body.subTotal,
                discount:req.body.discount,
                total:req.body.total,
                status:req.body.status,
                isInvoiced:false,
                isPacked:false,
                isShipped:false

              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
         
             let data =await SalesOrderDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      
    }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      let id=req.params.id;
      const data =await SalesOrderModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        const data=await SalesOrderModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
      router.get('/readAllDetails',async(req,res)=>{
        try
        {
          const data=await SalesOrderDetailsModel.find();
          res.json(data);   
     
        }
        catch(err)
        {
            res.status(400).json({error:"No Sales Order found"+err.message});
        }
        })

        router.get('/viewAllDetailsByitem/:id',async(req,res)=>{
          try
          {
            let id=req.params.id;
            const data=await SalesOrderDetailsModel.find({"itemId": id});
            res.json(data);   
       console.log(data);
          }
          catch(err)
          {
              res.status(400).json({error:"No Sales Order found"+err.message});
              console.log(err.message);
          }
          })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await SalesOrderDetailsModel.find({"salesOrderId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
    }
    })
    router.get('/salesorderByCustomer/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await SalesOrderModel.find({"customerId": id});
      res.json(data);   
      
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
        
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesOrderModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Adjustment deleted"});
        
      }
  })
  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new SalesOrderModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await SalesOrderModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      
    }       
    })

  router.put('/updatePackage/:id',async(req,res)=>{
    
    try {     
      console.log(req.body);
        let data = new SalesOrderDetailsModel({ 
         _id:req.params.id,
          packedQuantity:req.body.packedQuantity
        }
      )
      console.log(data,"data");
      let id=req.params.id;  
     const postData= await SalesOrderDetailsModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      console.log(error.message);
    }       
    })


    router.put('/updateReturn/:id',async(req,res)=>{
    
      try {     
        console.log(req.body);
          let data = new SalesOrderDetailsModel({ 
           _id:req.params.id,
            returnedQuantity:req.body.returnedQuantity
          }
        )
        console.log(data,"data");
        let id=req.params.id;  
       const postData= await SalesOrderDetailsModel.findByIdAndUpdate({"_id": id},data);    
       res.status(200).send({success:true,msg:'postData',data:postData})
       
      }
      catch (error)
      {
        res.status(400).send({success:false,msg:error.message})
        console.log(error.message);
      }       
      })

      router.put('/updateInvoice/:id',async(req,res)=>{
    
        try {     
          console.log(req.body);
            let data = new SalesOrderDetailsModel({ 
             _id:req.params.id,
             invoicedQuantity:req.body.quantity
            }
          )
          console.log(data,"data");
          let id=req.params.id;  
         const postData= await SalesOrderDetailsModel.findByIdAndUpdate({"_id": id},data);    
         res.status(200).send({success:true,msg:'postData',data:postData})
         
        }
        catch (error)
        {
          res.status(400).send({success:false,msg:error.message})
          console.log(error.message);
        }       
        })
        router.put('/updateInvoiceStatus/:id',async(req,res)=>{
    
          try {     
            
              let data = new SalesOrderModel({ 
                _id:req.params.id,
                isInvoiced:true
              }
            )
            let id=req.params.id; 
           const postData= await SalesOrderModel.findByIdAndUpdate({"_id": id},data);    
           res.status(200).send({success:true,msg:'postData',data:postData})
           
          }
          catch (error)
          {
            res.status(400).send({success:false,msg:error.message})
            
          }       
          })
          router.put('/updatePackageStatus/:id',async(req,res)=>{
    
            try {     
              
                let data = new SalesOrderModel({ 
                  _id:req.params.id,
                  isPacked:true
                }
              )
              let id=req.params.id; 
             const postData= await SalesOrderModel.findByIdAndUpdate({"_id": id},data);    
             res.status(200).send({success:true,msg:'postData',data:postData})
             
            }
            catch (error)
            {
              res.status(400).send({success:false,msg:error.message})
              
            }       
            })
            router.put('/updateShipmentStatus/:id',async(req,res)=>{
    
              try {     
                
                  let data = new SalesOrderModel({ 
                    _id:req.params.id,
                    isShipped:true
                  }
                )
                let id=req.params.id; 
               const postData= await SalesOrderModel.findByIdAndUpdate({"_id": id},data);    
               res.status(200).send({success:true,msg:'postData',data:postData})
               
              }
              catch (error)
              {
                res.status(400).send({success:false,msg:error.message})
                
              }       
              })
            
  module.exports= router;