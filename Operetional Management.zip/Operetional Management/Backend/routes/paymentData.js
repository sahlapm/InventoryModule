const express = require('express');
const router=express.Router();
const  PaymentModel  = require('../model/payments');
const  PaymentDetailsModel  = require('../model/paymentDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>{   
    try
    {           
        
        let data = new PaymentModel({ 
          
               customerId:req.body.customerId,
                customerName:req.body.customerName,
                paymentNumber:req.body.paymentNumber,
                reference:req.body.reference,
                date:req.body.date,
                paymentMode:req.body.deliveryMethod,
                depositTo:req.body.depositTo,
                paymentReceivedBy:req.body.paymentReceivedBy,
                amountReceived:req.body.amountReceived
                
               
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
         
             let data =await PaymentDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      
    }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      let id=req.params.id;
      const data =await PaymentModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        const data=await PaymentModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await PaymentDetailsModel.find({"paymentId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
    }
    })
    router.get('/salesorderByCustomer/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await SalesOrderModel.find({"customerId": id});
      res.json(data);   
      
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
        
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesOrderModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Adjustment deleted"});
        
      }
  })
  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new SalesOrderModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await SalesOrderModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      
    }       
    })


  module.exports= router;