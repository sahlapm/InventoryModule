const express = require('express');
const router=express.Router();
const  PurchaseOrderModel  = require('../model/purchaseOrders');
const  PurchaseOrderDetailsModel  = require('../model/purchaseOrderDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>{   
    try
    {           
        
        let data = new PurchaseOrderModel({ 
          
                vendorId:req.body.vendorId,
                vendorName:req.body.vendorName,
                purchaseOrderNumber:req.body.purchaseOrderNumber,
                reference:req.body.reference,
                date:req.body.date,
                expectedDeliveryDate:req.body.expectedDeliveryDate,
                shipmentPreference:req.body.shipmentPreference,
                description:req.body.discription,
                subTotal:req.body.subTotal,
                discount:req.body.discount,
                total:req.body.total,
                status:req.body.status
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
         
             let data =await PurchaseOrderDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      
    }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      let id=req.params.id;
      const data =await PurchaseOrderModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Purchase Order found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        const data=await PurchaseOrderModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Purchase Order found"+err.message});
      }
      })
      
      router.get('/viewAllDetailsByitem/:id',async(req,res)=>{
        try
        {
          let id=req.params.id;
          const data=await PurchaseOrderDetailsModel.find({"itemId": id});
          res.json(data);   
     console.log(data);
        }
        catch(err)
        {
            res.status(400).json({error:"No Purchase Order found"+err.message});
            console.log(err.message);
        }
        })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales Order found"+err.message});
      }
      })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await PurchaseOrderDetailsModel.find({"purchaseOrderId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Purchase Order found"+err.message});
    }
    })
    router.get('/purchaseOrderByvendor/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await PurchaseOrderModel.find({"vendorId": id});
      res.json(data);   
      
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
        
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesOrderModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Adjustment deleted"});
        
      }
  })
  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new PurchaseOrderModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await PurchaseOrderModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      
    }       
    })

  router.put('/updatePackage/:id',async(req,res)=>{
    
    try {     
      console.log(req.body);
        let data = new SalesOrderDetailsModel({ 
         _id:req.params.id,
          packedQuantity:req.body.packedQuantity
        }
      )
      console.log(data,"data");
      let id=req.params.id;  
     const postData= await SalesOrderDetailsModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      console.log(error.message);
    }       
    })


    router.put('/updateReturn/:id',async(req,res)=>{
    
      try {     
        console.log(req.body);
          let data = new SalesOrderDetailsModel({ 
           _id:req.params.id,
            returnedQuantity:req.body.returnedQuantity
          }
        )
        console.log(data,"data");
        let id=req.params.id;  
       const postData= await SalesOrderDetailsModel.findByIdAndUpdate({"_id": id},data);    
       res.status(200).send({success:true,msg:'postData',data:postData})
       
      }
      catch (error)
      {
        res.status(400).send({success:false,msg:error.message})
        console.log(error.message);
      }       
      })

      router.put('/updateInvoice/:id',async(req,res)=>{
    
        try {     
          console.log(req.body);
            let data = new PurchaseOrderDetailsModel({ 
             _id:req.params.id,
             invoicedQuantity:req.body.quantity
            }
          )
          console.log(data,"data");
          let id=req.params.id;  
         const postData= await PurchaseOrderDetailsModel.findByIdAndUpdate({"_id": id},data);    
         res.status(200).send({success:true,msg:'postData',data:postData})
         
        }
        catch (error)
        {
          res.status(400).send({success:false,msg:error.message})
          console.log(error.message);
        }       
        })
        router.put('/updateInvoiceStatus/:id',async(req,res)=>{
    
          try {     
            
              let data = new PurchaseOrderModel({ 
                _id:req.params.id,
                isInvoiced:true
              }
            )
            let id=req.params.id; 
           const postData= await PurchaseOrderModel.findByIdAndUpdate({"_id": id},data);    
           res.status(200).send({success:true,msg:'postData',data:postData})
           
          }
          catch (error)
          {
            res.status(400).send({success:false,msg:error.message})
            console.log(error.message);
          }       
          })

  module.exports= router;