const express = require('express');
const router=express.Router();
const  CreditNotesModel  = require('../model/creditNotes');
const  CreditNoteDetailsModel  = require('../model/creditNoteDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>{   
    try
    {           
       
        if(req.body.invoiceId!='')
        {
        let data = new CreditNotesModel({ 
          
                customerId:req.body.customerId,
                invoiceId:req.body.invoiceId,
                customerName:req.body.customerName,
                invoiceNumber:req.body.invoiceNumber,
                creditNoteNumber:req.body.creditNoteNumber,
                date:req.body.date,
                reference:req.body.reference,
                salesPerson:req.body.salesPerson,
                subTotal:req.body.subTotal,
                discount:req.body.discount,
                total:req.body.total,
          paidAmount:req.body.paidAmount,
                status:req.body.status
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
              }
              else
              {
                let data = new CreditNotesModel({ 
          
                  customerId:req.body.customerId,
                
                  customerName:req.body.customerName,
                  creditNoteNumber:req.body.creditNoteNumber,
                 
                   date:req.body.date,
                  reference:req.body.reference,
                  salesPerson:req.body.salesPerson,
                  subTotal:req.body.subTotal,
                  discount:req.body.discount,
                  total:req.body.total,
            paidAmount:req.body.paidAmount,
                  status:req.body.status
                } )
                const postData= await data.save();
                res.status(200).send({success:true,msg:'postData',data:postData})

              }

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
    console.log(err.message);
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {           
       
             let data =await CreditNoteDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
      
    }
  })
  router.put('/updatePaidAmount',async (req,res)=>{   
    try
    {           
         console.log(req.body);
             let data =await InvoiceModel.updateMany({_id:req.body._id},{  $inc: {paidAmount:req.body.paidAmount}});
             //db.employees.updateMany({_id:2}, { $set: {lastName:"Tendulkar", email:"sachin.tendulkar@abc.com"}}) 
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
      
    }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      console.log("entered");
      let id=req.params.id;
      const data =await CreditNotesModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        
        const data=await CreditNotesModel.find();
        res.json(data);   
      }
      catch(err)
      {
          res.status(400).json({error:"No Invoice found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await SalesOrderDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No credit note found"+err.message});
      }
      })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await CreditNoteDetailsModel.find({"creditNoteId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No credit note  found"+err.message});
    }
    })
    router.get('/invoiceByCustomer/:id',async(req,res)=>{
    try
    {
      console.log("started")
      let id=req.params.id;
      const data =await InvoiceModel.find({"customerId": id});
      res.json(data);   
      
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
        
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesOrderModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No credit note deleted"});
        
      }
  })
  router.put('/updateStatus/:id',async(req,res)=>{
    
    try {     
      
        let data = new CreditNotesModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await CreditNotesModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      
    }       
    })


  module.exports= router;