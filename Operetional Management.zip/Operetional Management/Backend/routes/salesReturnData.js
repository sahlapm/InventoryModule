const express = require('express');
const router=express.Router();
const  SalesRetunModel  = require('../model/salesReturn');
const  salesReturnDetailsModel  = require('../model/salesReturnDetails');
const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
const SalesOrderDetailsModel = require('../model/salesOrderDetails');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.post('/create',async (req,res)=>{   
    try
    {           
        let data = new SalesRetunModel({ 
          
                customerId:req.body.customerId,
                salesOrderId:req.body.salesOrderId,
                returnNumber:req.body.returnNumber,
                salesOrderNumber:req.body.salesOrderNumber,
                reason:req.body.reason,
                date:req.body.date,
                status:req.body.status,
                totalreturnedQuantity :req.body.totalreturnedQuantity,
                customerName :req.body.customerName
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})

    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
    }
  })
  router.post('/createDetails',async (req,res)=>{   
    try
    {                    
          console.log(req.body,"details");
      let data =await salesReturnDetailsModel.insertMany(req.body);
             /*  let data =await new SalesOrderModel({ salesOrderId:req.params.Id }).insertMany(req.body);*/
              res.status(200).send({success:true,msg:'postData',data:data})
            
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);      
    }
  })
  router.get('/readone/:id', async(req,res)=>{
    try
    {      
      let id=req.params.id;
      const data =await SalesRetunModel.findOne({"_id": id});
      res.send(data);  
       
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales return found"});
    }
    })
    router.get('/read',async(req,res)=>{
      try
      {
        const data=await SalesRetunModel.find();
        res.json(data);   
        console.log(data);
      }
      catch(err)
      {
          res.status(400).json({error:"No sales return found"+err.message});
      }
      })
       router.get('/readAllDetails',async(req,res)=>{
      try
      {
        const data=await salesReturnDetailsModel.find();
        res.json(data);   
   
      }
      catch(err)
      {
          res.status(400).json({error:"No Sales return found"+err.message});
      }
      })
  router.get('/readDetailsbysalesorder/:id',async(req,res)=>{
    try
    {
      let id=req.params.id;
      const data =await salesReturnDetailsModel.find({"salesOrderId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Sales Order found"+err.message});
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
         let id=req.params.id;
         const data= await SalesRetunModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No sales return deleted"});
        
      }
  })
  router.get('/readDetails/:id',async(req,res)=>{
    try
    {
      console.log("sahla");
      let id=req.params.id;
      const data =await salesReturnDetailsModel.find({"salesReturnId": id});
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No sales return found"+err.message});
    }
    })
   
  router.put('/updateStatus/:id',async(req,res)=>{
    console.log("entered")  
    try {     
      
        let data = new SalesRetunModel({ 
          _id:req.params.id,
          status:req.body.status
        }
      )
      let id=req.params.id; 
     const postData= await SalesRetunModel.findByIdAndUpdate({"_id": id},data);    
     res.status(200).send({success:true,msg:'postData',data:postData})
     console.log(req.body.status,"status");
    }
    catch (error)
    {
      res.status(400).send({success:false,msg:error.message})
      console.log(error.message);
    }       
    })


  module.exports= router;