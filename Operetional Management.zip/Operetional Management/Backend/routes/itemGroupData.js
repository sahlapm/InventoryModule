const express = require('express');
const router=express.Router();
const  ItemGroupModel  = require('../model/itemGroups');

const bodyparser=require('body-parser');
router.use(bodyparser.json());

const { Console } = require('console');
//let verifyToken =require('../routes/verifytoken');
//const bcrpt=require('bcrypt')
//const jwt=require('jsonwebtoken')

router.use(bodyparser.urlencoded({extented:true}));
const multer = require('multer');
const path = require('path');
const { stringify } = require('querystring');
router.use(express.static('public'));

let storage=multer.diskStorage({
  destination:(req,file,callback) =>{
    callback(null,path.join(__dirname,'../public/ItemGroupImage'),function(error,success){

      if(error){console.log(error)} else{console.log("success")}
    });
},
filename:(req,file,callback)=>{
  const name=Date.now()+'-'+file.originalname
  callback(null,name,function (error,success){
    if(error){console.log(error)} else{console.log("success")}
  });
}}
);
const upload= multer({storage:storage})




router.post('/create',upload.single('file'),async (req,res)=>{   
    try
    {
       
     console.log("file : "+req.body.file)
              let data = new ItemGroupModel({ 
                type:req.body.type,
                itemGroupName:req.body.itemGroupName,
              unit:req.body.unit,
              manufacturer:req.body.manufacturer,
              brand:req.body.brand,
              description:req.body.description,
              file: req.body.file==''?'': req.file.filename
              } )
              const postData= await data.save();
              res.status(200).send({success:true,msg:'postData',data:postData})
    
    }
    catch(err)
    {
      res.status(400).send({success:false,msg:err.message})
      console.log(err.message);
    }
  })

  router.get('/read',async(req,res)=>{
    try
    {
      
      const data=await ItemGroupModel.find();
      res.json(data);   
    }
    catch(err)
    {
        res.status(400).json({error:"No Items found"+err.message});
    }
    })
    router.delete('/delete/:id',async(req,res)=>{           
      try
      {
       
        let id=req.params.id;
         const data= await ItemGroupModel.findOneAndDelete({"_id":id});
         res.json({"status":"success"})
      }
      catch (error)
      {
          res.status(400).json({error:"No Item deleted"});
          console.log(error);
      }
  })


  module.exports= router;