const express = require('express');
var app = new express();
app.use(express.json());

const cors = require('cors');
app.use(cors({ origin: '*' }));
const mongoose = require('mongoose');

mongoose.set("strictQuery", false);
const item = require('./routes/itemData');
const itemGroup = require('./routes/itemGroupData');
const adjustment = require('./routes/adjustmentData');
const customer = require('./routes/customerData');
const salesOrder = require('./routes/salesOrderData');
const package = require('./routes/packadeData');
const challan = require('./routes/deliveryChallanData');
const invoice = require('./routes/invoiceData');
const payment = require('./routes/paymentData');
const vendor = require('./routes/vendorData');
const salesReturn = require('./routes/salesReturnData');
const CreditNote = require('./routes/creditNoteData');
const PurchaseOrder = require('./routes/purchaseOrderData');
const Bill = require('./routes/billData');
const VendorPayment = require('./routes/vendorPaymentData');
const VendorCredit = require('./routes/vendorCreditData');

mongoose.connect('mongodb+srv://sahla:sahlaAtlas@cluster0.2wlvq8k.mongodb.net/OperationsDB?retryWrites=true&w=majority',
{
    useNewUrlParser:true
});


app.use('/api/item', item);
app.use("/api/itemgroup", itemGroup);
app.use("/api/adjustment", adjustment);
app.use('/api/customer',customer);
app.use('/api/salesorder',salesOrder);
app.use('/api/package',package);
app.use('/api/challan',challan);
app.use('/api/invoice',invoice);
app.use('/api/payment',payment);
app.use('/api/vendor',vendor);
app.use('/api/salesReturn',salesReturn);
app.use('/api/credit',CreditNote);
app.use('/api/purchaseOrder',PurchaseOrder);
app.use('/api/bill',Bill);
app.use('/api/vendorpayment',VendorPayment);
app.use('/api/vendorcredit',VendorCredit);
//Running server at port 5000

app.listen(5000, () => {
    console.log("Server listening to port 5000");
})