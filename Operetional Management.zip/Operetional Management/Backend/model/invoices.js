const mongoose=require('mongoose');
const InvoicesSchema=mongoose.Schema(
    {
        customerName: {
            type: String
          },
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          salesOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrders'},
          salesOrderNumber: {
            type: String
          },
          invoiceNumber: {
            type: String
          },
          placeOfSupply: {
            type: String
          },
         date : {
          type: Date
        },
      
          terms : {
            type: String
          },
          salesPerson : {
            type: String
          },
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: Number
          },
          paidAmount
          : {
            type: Number
          },
          dueAmount
          : {
            type: Number
          },
          status : {
            type: String
          }
        
    }
);
var InvoiceModel=mongoose.model('Invoices',InvoicesSchema);
module.exports=InvoiceModel

