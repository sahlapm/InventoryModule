const mongoose=require('mongoose');
const PurchaseOrdersDetailsSchema=mongoose.Schema(
    {
          purchaseOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'PurchaseOrders'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          quantity : {
            type: Number
          },
          rate : {
            type: Number
          },
          amount : {
            type: Number
          },
          brand : {
            type: String
          },
          packedQuantity   : {
            type: Number,
            default: 0
          },
          returnedQuantity   : {
            type: Number,
            default: 0
          },
          invoicedQuantity   : {
            type: Number,
            default: 0
          }
        
    }
);
var PurchasesOrderDetailsModel=mongoose.model('PurchaseOrderDetails',PurchaseOrdersDetailsSchema);
module.exports=PurchasesOrderDetailsModel

