const mongoose=require('mongoose');
const InventoryAdjustmentSchema=mongoose.Schema(
    {
        mode: {
            type: String
          },
          referenceNumber: {
            type: String
          },
          date: {
            type: Date,
    default: Date.now
          },
          reason : {
          type: String
        },
         description : {
            type: String
          },
          itemName : {
            type: String
          },
          currentValue : {
            type: Number
          },
          changedValue : {
            type: String
          },
          adjusateddValue : {
            type: String
          },
          file : {
            type: String
          }
  
    }
);
var InventoryAdjustmentModel=mongoose.model('InventoryAdjustments',InventoryAdjustmentSchema);
module.exports=InventoryAdjustmentModel