const mongoose=require('mongoose');
const SalesReturnSchema=mongoose.Schema(
    {
         returnNumber :{
            type: String
          },
          salesOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrders'},
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          salesOrderNumber: {
            type: String
          },
          reason: {
            type: String
          },
         date : {
          type: String
         },
          status : {
            type: String
          } ,       
          totalReturnedQuantity: {
            type: Number
          },
          customerName : {
            type: String
          }
          
    }
    
);
var SalesReturnModel=mongoose.model('SalesReturns',SalesReturnSchema);
module.exports=SalesReturnModel

