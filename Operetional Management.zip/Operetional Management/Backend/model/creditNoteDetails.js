const mongoose=require('mongoose');
const CreditNoteDetailsSchema=mongoose.Schema(
    {
          creditNoteId:{type:mongoose.Schema.Types.ObjectId, ref:'CreditNotes'},
       
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          quantity : {
            type: Number
          },
          rate : {
            type: Number
          },
          amount : {
            type: Number
          },
          brand : {
            type: String
          }
        
    }
);
var CreditNoteDetailsModel=mongoose.model('CreditNoteDetails',CreditNoteDetailsSchema);
module.exports=CreditNoteDetailsModel

