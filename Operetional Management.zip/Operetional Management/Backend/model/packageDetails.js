const mongoose=require('mongoose');
const PackageDetailsSchema=mongoose.Schema(
    {
       
          salesOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrders'},
          packageId:{type:mongoose.Schema.Types.ObjectId, ref:'Packages'},
          salesDetailsId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrderDetails'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          totalQuantity : {
            type: Number
          },
          packedQuantity : {
            type: Number
          },
          oldPackedQuantity : {
            type: Number
          }
         
        
    }
);
var PackageDetailsModel=mongoose.model('PackageDetails',PackageDetailsSchema);
module.exports=PackageDetailsModel

