const mongoose=require('mongoose');
const PaymentsSchema=mongoose.Schema(
    {
        
         customerName: {
            type: String
          },
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
       
          paymentNumber: {
            type: String
          },
          reference: {
            type: String
          },
          paymentMode: {
            type: String
          },
         date : {
          type: String
        },
      
        depositTo : {
            type: String
          },
          paymentReceivedBy : {
            type: String
          },
          amountReceived : {
            type: Number
          }
        
        
    }
);
var PaymentModel=mongoose.model('Payments',PaymentsSchema);
module.exports=PaymentModel

