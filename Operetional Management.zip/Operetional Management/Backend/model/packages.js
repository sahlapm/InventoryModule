const mongoose=require('mongoose');
const PackagesSchema=mongoose.Schema(
    {
        packageSlip :{
            type: String
          },
          salesOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrders'},
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          salesOrderNumber: {
            type: String
          },
          internalNote: {
            type: String
          },
         date : {
          type: String
        },
          status : {
            type: String
          } ,       
          totalPackedQuantity: {
            type: Number
          },
          customerName : {
            type: String
          }
          
    }
    
);
var PackageModel=mongoose.model('Packages',PackagesSchema);
module.exports=PackageModel

