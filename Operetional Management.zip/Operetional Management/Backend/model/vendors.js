const mongoose=require('mongoose');
const VendorSchema=mongoose.Schema(
    {
      companyName: {
            type: String
          },
          name: {
            type: String
          },
          contactNumber : {
          type: String
        },
         email : {
            type: String
          },
          website : {
            type: String
          },
          address : {
            type: String
          }
  
    }
);
var VendorModel=mongoose.model('Vendors',VendorSchema);
module.exports=VendorModel