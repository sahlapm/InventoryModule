const mongoose=require('mongoose');
const BillsSchema=mongoose.Schema(
    {
        vendorName: {
            type: String
          },
          vendorId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          purchaseOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'PurchaseOrders'},
          purchaseOrderNumber: {
            type: String
          },
          billNumber: {
            type: String
          },
          sourceOfSupply: {
            type: String
          },
         date : {
          type: Date
        },
        dueDate : {
          type: String
        },
          terms : {
            type: String
          },
         
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: Number
          },
          paidAmount
          : {
            type: Number
          },
          dueAmount
          : {
            type: Number
          },
          status : {
            type: String
          }
        
    }
);
var BillsModel=mongoose.model('Bills',BillsSchema);
module.exports=BillsModel

