const mongoose=require('mongoose');
const ItemSchema=mongoose.Schema(
    {
        type: {
            type: String
          },
          itemGroupName: {
            type: String
          },
          
          itemName: {
            type: String
          },
          sku: {
            type: String
          },
        unit : {
          type: String
        },
        dimension:{
            type: String
          },
        weight : {
            type: String
          },
          manufacturer : {
            type: String
          },
          brand : {
            type: String
          },
          sellingPrice : {
            type: Number
          },
          costPrice : {
            type: Number
          },
          description : {
            type: String
          },
          openingStock : {
            type: Number
          },
          reorderPoint : {
            type: Number
          },
          preferedVendor : {
            type: String
          },
          file : {
            type: String
          }
          
          
          
          
         
    }
);
var ItemModel=mongoose.model('Items',ItemSchema);
module.exports=ItemModel