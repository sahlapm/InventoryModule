const mongoose=require('mongoose');
const DeliveryChallanSchema=mongoose.Schema(
    {
        customerName: {
            type: String
          },
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          deliveryChallanNumber: {
            type: String
          },
          reference: {
            type: String
          },
         date : {
          type: String
        },
         challanType : {
            type: String
          },
          warehouseName : {
            type: String
          },
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: String
          },
          status : {
            type: String
          }
        
          
    }
);
var DeliveryChallanModel=mongoose.model('DeliveryChallans',DeliveryChallanSchema);
module.exports=DeliveryChallanModel

