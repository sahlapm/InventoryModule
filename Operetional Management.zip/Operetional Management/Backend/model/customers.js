const mongoose=require('mongoose');
const CustomerSchema=mongoose.Schema(
    {
        type: {
            type: String
          },
          name: {
            type: String
          },
          contactNumber : {
          type: String
        },
         email : {
            type: String
          },
          website : {
            type: String
          },
          address : {
            type: String
          },
          creditPeriod : {
            type: Number
          },
          creditLimit : {
            type: Number
          }
    }
);
var CustomerModel=mongoose.model('Customers',CustomerSchema);
module.exports=CustomerModel