const mongoose=require('mongoose');
const DeliveryChallanDetailsSchema=mongoose.Schema(
    {
          deliveryChallanId:{type:mongoose.Schema.Types.ObjectId, ref:'DeliveryChallan'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          quantity : {
            type: Number
          },
          rate : {
            type: Number
          },
          amount : {
            type: Number
          },
          brand : {
            type: String
          }
        
    }
);
var DeliveryChallanDetailsModel=mongoose.model('DeliveryChallanDetails',DeliveryChallanDetailsSchema);
module.exports=DeliveryChallanDetailsModel

