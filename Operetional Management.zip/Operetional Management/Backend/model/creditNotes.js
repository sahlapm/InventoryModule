const mongoose=require('mongoose');
const CreditNoteSchema=mongoose.Schema(
    {
        customerName: {
            type: String
          },
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          invoiceId:{type:mongoose.Schema.Types.ObjectId, ref:'Invoices'},
          creditNoteNumber: {
            type: String
          },
          invoiceNumber: {
            type: String
          },
          
         date : {
          type: String
        },
      
          reference : {
            type: String
          },
          salesPerson : {
            type: String
          },
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: Number
          },
          paidAmount
          : {
            type: Number
          },
          status : {
            type: String
          }
        
    }
);
var CreditNoteModel=mongoose.model('CreditNotes',CreditNoteSchema);
module.exports=CreditNoteModel

