const mongoose=require('mongoose');
const VendorPaymentsSchema=mongoose.Schema(
    {
        
         vendorName: {
            type: String
          },
          vendorId:{type:mongoose.Schema.Types.ObjectId, ref:'Vendors'},
       
          paymentNumber: {
            type: String
          },
          reference: {
            type: String
          },
          paymentMode: {
            type: String
          },
         date : {
          type: String
        },
        paymentDate : {
            type: String
          },
      
          paidThrough : {
            type: String
          },
          paymentReceivedBy : {
            type: String
          },
          amountReceived : {
            type: Number
          }
        
        
    }
);
var VendorPaymentModel=mongoose.model('VendorPayments',VendorPaymentsSchema);
module.exports=VendorPaymentModel

