const mongoose=require('mongoose');
const BillDetailsSchema=mongoose.Schema(
    {
          billId:{type:mongoose.Schema.Types.ObjectId, ref:'Bills'},
          purchaseDetailsId:{type:mongoose.Schema.Types.ObjectId, ref:'PurchaseOrderDetails'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          quantity : {
            type: Number
          },
          rate : {
            type: Number
          },
          amount : {
            type: Number
          },
          brand : {
            type: String
          },
          oldInvoicedQuantity : {
            type: Number
          },
        
    }
);
var BillDetailsModel=mongoose.model('BillDetails',BillDetailsSchema);
module.exports=BillDetailsModel

