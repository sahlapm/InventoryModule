const mongoose=require('mongoose');
const PurchaseOrdersSchema=mongoose.Schema(
    {
        vendorName: {
            type: String
          },
          vendorId:{type:mongoose.Schema.Types.ObjectId, ref:'Vendors'},
          purchaseOrderNumber: {
            type: String
          },
          reference: {
            type: String
          },
         date : {
          type: String
        },
        expectedDeliveryDate:{
            type: String
          },
          shipmentPreference : {
            type: String
          },
          description : {
            type: String
          },
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: String
          },
          status : {
            type: String
          },
        
          isPacked: {
            type: Boolean,
            default: false
        },
        isShipped: {
          type: Boolean,
          default: false
      },
      isInvoiced: {
        type: Boolean,
        default: false
    }
    }
);
var PurchaseOrderModel=mongoose.model('PurchaseOrders',PurchaseOrdersSchema);
module.exports=PurchaseOrderModel

