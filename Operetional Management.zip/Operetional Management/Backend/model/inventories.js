const mongoose=require('mongoose');
const InventorySchema=mongoose.Schema(
    {
        itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          
          itemName: {
            type: String
          },
          sku: {
            type: String
          },
          openingStock : {
            type: Number
          },
          reorderPoint : {
            type: Number
          },
          quantityOrdered : {
            type: Number
          },
          quantityIn : {
            type: Number
          },
          quantityOut : {
            type: Number
          },
          committedStock : {
            type: Number
          },
          stockOnHand : {
            type: Number
          },
          lastBillDate : {
            type: Date
          }
        }
);
var InventoryModel=mongoose.model('Inventories',InventorySchema);
module.exports=InventoryModel