const mongoose=require('mongoose');
const SalesReturnDetailsSchema=mongoose.Schema(
    {
       
          salesOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrders'},
          salesReturnId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesReturns'},
          salesDetailsId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrderDetails'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          totalQuantity : {
            type: Number
          },
          returnedQuantity : {
            type: Number
          }
    }
);
var SalesReturnDetailsModel=mongoose.model('SalesReturnDetails',SalesReturnDetailsSchema);
module.exports=SalesReturnDetailsModel

