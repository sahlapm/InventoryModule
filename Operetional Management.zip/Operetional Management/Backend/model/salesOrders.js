const mongoose=require('mongoose');
const SalesOrdersSchema=mongoose.Schema(
    {
        customerName: {
            type: String
          },
          customerId:{type:mongoose.Schema.Types.ObjectId, ref:'Customers'},
          salesOrderNumber: {
            type: String
          },
          reference: {
            type: String
          },
         date : {
          type: String
        },
        expectedShipmentDate:{
            type: String
          },
          deliveryMethod : {
            type: String
          },
          description : {
            type: String
          },
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: String
          },
          status : {
            type: String
          },
        
          isPacked: {
            type: Boolean
         
        },
        isShipped: {
          type: Boolean
          
      },
      isInvoiced: {
        type: Boolean
      
    }
    }
);
var SalesOrderModel=mongoose.model('SalesOrders',SalesOrdersSchema);
module.exports=SalesOrderModel

