const mongoose=require('mongoose');
const VendorPaymentDetailsSchema=mongoose.Schema(
    {
        
        billId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesDetails'},
         paymentId:{type:mongoose.Schema.Types.ObjectId, ref:'VendorPayments'},
          date : {
            type: String
          },
          billNumber : {
            type: String
          },
        total : {
            type: Number
          },
          paidAmount : {
            type: Number
          },
          
          paymentReceived : {
            type: Number
          }
         
        
    }
);
var VendorPaymentDetailsModel=mongoose.model('VendorPaymentDetails',VendorPaymentDetailsSchema);
module.exports=VendorPaymentDetailsModel

