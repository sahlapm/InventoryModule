const mongoose=require('mongoose');
const VendorCreditDetailsSchema=mongoose.Schema(
    {
          vendorCreditId:{type:mongoose.Schema.Types.ObjectId, ref:'VendorCredits'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          quantity : {
            type: Number
          },
          rate : {
            type: Number
          },
          amount : {
            type: Number
          }
        
        
    }
);
var VendorCreditDetailsModel=mongoose.model('VendorCreditDetails',VendorCreditDetailsSchema);
module.exports=VendorCreditDetailsModel

