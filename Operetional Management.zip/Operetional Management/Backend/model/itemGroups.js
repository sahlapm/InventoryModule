const mongoose=require('mongoose');
const ItemGroupSchema=mongoose.Schema(
    {
        type: {
            type: String
          },
          itemGroupName: {
            type: String
          },
        unit : {
          type: String
        },
          manufacturer : {
            type: String
          },
          brand : {
            type: String
          },
          description : {
            type: String
          },
         file : {
            type: String
          }  
         
    }
);
var ItemGroupModel=mongoose.model('ItemGroups',ItemGroupSchema);
module.exports=ItemGroupModel