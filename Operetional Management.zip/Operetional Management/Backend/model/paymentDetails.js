const mongoose=require('mongoose');
const PaymentDetailsSchema=mongoose.Schema(
    {
        
        invoiceId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesDetails'},
         paymentId:{type:mongoose.Schema.Types.ObjectId, ref:'Payments'},
          date : {
            type: String
          },
          invoiceNumber : {
            type: String
          },
        total : {
            type: Number
          },
          paidAmount : {
            type: Number
          },
          
          paymentReceived : {
            type: Number
          }
         
        
    }
);
var PaymentDetailsModel=mongoose.model('PaymentDetails',PaymentDetailsSchema);
module.exports=PaymentDetailsModel

