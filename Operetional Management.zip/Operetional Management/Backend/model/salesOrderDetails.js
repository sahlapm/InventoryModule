const mongoose=require('mongoose');
const SalesOrdersDetailsSchema=mongoose.Schema(
    {
          salesOrderId:{type:mongoose.Schema.Types.ObjectId, ref:'SalesOrders'},
          itemName : {
            type: String
          },
          itemId:{type:mongoose.Schema.Types.ObjectId, ref:'Items'},
          quantity : {
            type: Number
          },
          rate : {
            type: Number
          },
          amount : {
            type: Number
          },
          brand : {
            type: String
          },
          packedQuantity   : {
            type: Number
         
          },
          returnedQuantity   : {
            type: Number
           
          },
          invoicedQuantity   : {
            type: Number
           
          }
        
    }
);
var SalesOrderDetailsModel=mongoose.model('SalesOrderDetails',SalesOrdersDetailsSchema);
module.exports=SalesOrderDetailsModel

