const mongoose=require('mongoose');
const VendorCreditsSchema=mongoose.Schema(
    {
        vendorName: {
            type: String
          },
          vendorId:{type:mongoose.Schema.Types.ObjectId, ref:'Vendors'},
          creditNoteNumber: {
            type: String
          },
          orderNumber: {
            type: String
          },
         vendorCreditDate : {
          type: String
        },
       
          subTotal : {
            type: Number
          },
          discount : {
            type: Number
          },
          total : {
            type: String
          },
          status : {
            type: String
          }
      
    }
);
var VendorCreditModel=mongoose.model('VendorCredits',VendorCreditsSchema);
module.exports=VendorCreditModel

