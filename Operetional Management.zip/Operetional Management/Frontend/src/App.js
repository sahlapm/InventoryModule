import Sidebar from "./components/sidebar/Sidebar";
import Topbar from "./components/topbar/Topbar";
import "./App.css";
import Home from "./pages/home/Home";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";


import Customer from "./components/sales/customer/Customer";
import CustomerList from "./components/sales/customer/CustomerList";
import ItemList from "./components/inventory/items/ItemList";
import Items from "./components/inventory/items/Items";
import ItemGroup from "./components/inventory/itemGroup/ItemGroup";
import InventoryAdjustment from "./components/inventory/inventoryAdjustment/InventoryAdjustment";
import AdjustmentList from "./components/inventory/inventoryAdjustment/AdjustmentList";
import CustomerEdit from "./components/sales/customer/customerEdit";
import SalesOrder from "./components/sales/salesOrder/SalesOrder";
import SalesOrderList from "./components/sales/salesOrder/SalesOrderList";
import SalesOrderView from "./components/sales/salesOrder/SalesOrderView";
import Packages from "./components/sales/packages/Packages";
import PackageList from "./components/sales/packages/PackageList";
import PackageView from "./components/sales/packages/PackageView";
import DeliveryChallans from "./components/sales/deliveryChallans/DeliveryChallans";
import DeliveryChallanList from "./components/sales/deliveryChallans/DelivertChallanList";
import DeliveryChallanView from "./components/sales/deliveryChallans/DeliveryChallanView";
import Invoice from "./components/sales/invoice/Invoice";
import InvoiceList from "./components/sales/invoice/InvoiceList";
import InvoiceView from "./components/sales/invoice/InvoiceView";
import Payment from "./components/sales/paymentReceived/Payment";
import PaymentList from "./components/sales/paymentReceived/PaymentList";
import PaymentView from "./components/sales/paymentReceived/PaymentView";
import Vendor from "./components/purchase/vendor/Vendor"
import VendorList from "./components/purchase/vendor/VendorList";
import VendorEdit from "./components/purchase/vendor/VendorEdit";
import SalesReturn from "./components/sales/salesReturn/SalesRetun";
import SalesReturnList from "./components/sales/salesReturn/SalesReturnList";
import SalesReturnView from "./components/sales/salesReturn/SalesReturnView";
import CreditNote from "./components/sales/creditNote/CreditNote";
import CreditNoteList from "./components/sales/creditNote/CreditNoteList";
import CreditNoteView from "./components/sales/creditNote/CreditNoteView";
import PurchaseOrder from "./components/purchase/purchaseOrder/PurchaseOrder";
import PurchaseOrderList from "./components/purchase/purchaseOrder/PurchaseOrderList";
import PurchaseOrderView from "./components/purchase/purchaseOrder/PurchaseOrderView";
import Bills from "./components/purchase/bills/Bills";
import BillList from "./components/purchase/bills/BillList";
import BillView from "./components/purchase/bills/BillView";
import VendorPayment from "./components/purchase/payment/Payment";
import VendorPaymentList from "./components/purchase/payment/PaymentList";
import VendorPaymentView from "./components/purchase/payment/PaymentView";
import VendorCredit from "./components/purchase/vendorCredit/VendorCredit";
import VendorCreditList from "./components/purchase/vendorCredit/VendorCreditList";
import VendorCreditView from "./components/purchase/vendorCredit/VendorCreditView";
import SalesReport from "./components/reports/saleReport/SaleReport";
import CustomerSales from "./components/reports/customerSales/CustomerSales";
import ItemSales from "./components/reports/itemSales/ItemSales";
import InventorySummary from "./components/reports/inventorySummary/InventorySummary";
import InventoryAgingSummary from "./components/reports/inventoryAgingSummary/InventoryAgingSummary";


function App() {
  return (
    <Router>
      <Topbar />
      <div className="container">
        <Sidebar />
        <Routes >
          <Route exact path="/" element={<Home />}>
            
          </Route>
          <Route  path="/items" element={<Items/>}>
            
          </Route>
          <Route  path="/itemgroup" element={<ItemGroup/>}>
            
            </Route>
            <Route  path="/adjustment" element={<InventoryAdjustment/>}>
            
            </Route>
            <Route  path="/adjustmentlist" element={<AdjustmentList/>}>
            
            </Route>
          
          <Route path="/customerlist" element={<CustomerList />}>
          </Route>
        
          <Route path="/customeredit/:id" element={<CustomerEdit />}></Route>
          <Route path="/newsalesorder" element={<SalesOrder />}>  </Route>
          <Route path="/salesorder" element={<SalesOrderList />}>  </Route>
          <Route path="/viewsalesorder/:id" element={<SalesOrderView/>}>  </Route>
        
         
          <Route path="/itemlist" element={<ItemList />}>
          </Route>
          <Route path="/Newpackages" element={<Packages />}>
          </Route>
          <Route path="/packages" element={<PackageList/>}></Route>
          <Route path="/viewpackages/:id" element={<PackageView/>}>  </Route>
          
          <Route path="/Newchallans" element={<DeliveryChallans/>}></Route>
          <Route path="/challans" element={<DeliveryChallanList/>}></Route>
          <Route path="/viewchallan/:id" element={<DeliveryChallanView/>}></Route>

          <Route path="/invoice" element={<InvoiceList/>}></Route>
          <Route path="/Newinvoice" element={<Invoice/>}></Route>
          <Route path="/viewinvoice/:id" element={<InvoiceView/>}></Route>
          <Route path="/payment" element={<PaymentList/>}></Route>
          <Route path="/Newpayment" element={<Payment/>}></Route>
          <Route path="/viewpayment/:id" element={<PaymentView/>}></Route>
          <Route path="/salesreturn" element={<SalesReturnList />}></Route>
          <Route path="/Newsalesreturn" element={<SalesReturn />}></Route>
          <Route path="/viewsalesreturn/:id" element={<SalesReturnView/>}></Route>
          <Route path="/newcreditnote" element={<CreditNote />}></Route>
          <Route path="/creditnote" element={<CreditNoteList />}></Route>
          <Route path="/viewcreditnote/:id" element={<CreditNoteView/>}>  </Route>
          <Route path="/vendorlist" element={<VendorList />}></Route>
          <Route path="/newvendor" element={<Vendor />}>
          </Route>
          <Route path="/vendoredit/:id" element={<VendorEdit />}></Route>
          <Route path="/purchaseorder" element={<PurchaseOrderList />}>  </Route>
          <Route path="/Newpurchaseorder" element={<PurchaseOrder />}>  </Route>
          <Route path="/Newbills" element={<Bills />}>  </Route>
          <Route path="/bills" element={<BillList />}>  </Route>
          <Route path="/viewbills/:id" element={<BillView/>}>  </Route>
          <Route path="/viewpurchaseorder/:id" element={<PurchaseOrderView/>}>  </Route>
          <Route path="/vendorpayment" element={<VendorPaymentList/>}></Route>
          <Route path="/Newvendorpayment" element={<VendorPayment/>}></Route>
          <Route path="/viewvendorPayment/:id" element={<VendorPaymentView/>}>  </Route>
          <Route path="/Newvendorcredit" element={<VendorCredit/>}></Route>
          <Route path="/vendorcredit" element={<VendorCreditList/>}></Route>
          <Route path="/viewvendorcredit/:id" element={<VendorCreditView/>}></Route>
          <Route path="/salesreport" element={<SalesReport/>}></Route>
          <Route path="/customersales" element={<CustomerSales/>}></Route>
          <Route path="/itemsales" element={<ItemSales/>}></Route>
          <Route path="/inventorySummary" element={<InventorySummary/>}></Route>
          <Route path="/inventoryaging" element={<InventoryAgingSummary/>}></Route>
          
        </Routes >
      </div>
    </Router>
  );
}

export default App;
