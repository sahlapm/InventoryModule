import Chart from "../../components/chart/Chart";
import FeaturedInfo from "../../components/featuredInfo/FeaturedInfo";
import "./home.css";
import SaleReport from "../../components/reports/saleReport/SaleReport";
import ItemSales from "../../components/reports/itemSales/ItemSales";
import CustomerSales from "../../components/reports/customerSales/CustomerSales";
import { useState,useEffect } from "react";
import axios from 'axios';
sessionStorage.setItem("salesOrderId", "0");
sessionStorage.setItem("invoiceId", "0");
sessionStorage.setItem("purchaseOrderId", "0");
export default function Home() {
   const url="http://localhost:5000/api";
  const [data, setData] = useState([]);
  useEffect(() => {         
    FillData();         

},[])


const FillData=()=>
{
axios.get(url+'/invoice/monthwisesalegraph')
.then((getData)=>{
setData(getData.data);    
console.log(getData.data,"getData.data")
})
}
  

return (

    <div className="home">
      <FeaturedInfo/>
      <div className="homeWidgets">
     <div className="bottomboxLeft">
      <Chart data={data} title="Month Wise Sales" grid dataKey="sales"/>
     </div>
     <div className="bottomboxRight">
     <SaleReport/></div>
     </div>
      <div className="homeWidgets">
        <div className="bottomboxLeft">
        <ItemSales/></div>
        <div className="bottomboxRight">
        <CustomerSales/></div>
      </div>
    </div>
  );
}
