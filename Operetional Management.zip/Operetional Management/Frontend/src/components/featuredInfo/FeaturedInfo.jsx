import "./featuredInfo.css";
import { ArrowDownward, ArrowUpward } from "@material-ui/icons";
import React from 'react';
import { DataGrid } from "@material-ui/data-grid";
import { useState,useEffect } from "react";
import axios from 'axios';
import moment from 'moment';

const FeaturedInfo = () => {
    const url="http://localhost:5000/api";

    const [currentBill, setCurrentBill] = useState(0);
    const [billDiff, setBillDiff] = useState(0);
    const [billVisible, setBillVisible] = useState(true);
    const [currentInvoice, setCurrentInvoice] = useState(0);
    const [invoiceDiff, setInvoiceDiff] = useState(0);
    const [invoiceVisible, setInvoiceVisible] = useState(true);
    const [stock, setStock] = useState(0);
    useEffect(() => {
      FillPurchase();
      FillSales();
      FillStock();
               },[])
                      
  const FillPurchase=()=>
  {
    let currentmonth = moment();
    let month=currentmonth.month();

    const filteredData=[]
    axios.get(url+'/bill/monthwisesPurchase')
    .then((getData)=>{     
     
      const filtered = getData.data.filter(item => {
        return item._id === month+1;
      });

      setCurrentBill(filtered[0].sales);

      const filteredPrev = getData.data.filter(item => {
        return item._id === month;
      });
      setBillDiff(filtered[0].sales-filteredPrev[0].sales);
      if(filtered[0].sales-filteredPrev[0].sales>0)
      {
        setBillVisible(true);
      }
      else{
        setBillVisible(false);
      }
    })
  }
  const FillSales=()=>
  {
    let currentmonth = moment();
    let month=currentmonth.month();
   
    const filteredData=[]
    axios.get(url+'/invoice/monthwisesalegraph')
    .then((getData)=>{     
      
      const filteredsales = getData.data.filter(item => {
        return item._id === month+1;
      });

      setCurrentInvoice(filteredsales[0].sales);
      console.log(filteredsales,"sales")
      const filteredSalesPrev = getData.data.filter(item => {
        return item._id === month;
      });
      setInvoiceDiff(filteredsales[0].sales-filteredSalesPrev[0].sales);
      if(filteredsales[0].sales-filteredSalesPrev[0].sales>0)
      {
        setInvoiceVisible(true);
      }
      else{
        setInvoiceVisible(false);
      }
    })
  }
  const FillStock=()=>
  {
    axios.get(url+'/item/totalStockOnHand')
    .then((getData)=>{
      setStock(getData.data[0].Stock);    
    })
  }


  return (
    <div className="featured">
      <div className="featuredItem">
        <span className="featuredTitle">Total Purchase</span>
        <div className="featuredMoneyContainer">
          <span className="featuredMoney">{"₹ "+currentBill}</span>
          <span className="featuredMoneyRate">
            {billDiff}
            {!billVisible &&
            <ArrowDownward  className="featuredIcon negative"/>}
             {billVisible &&
            <ArrowUpward className="featuredIcon"/>}
          </span>
        </div>
        <span className="featuredSub">Compared to last month</span>
      </div>
      <div className="featuredItem">
        <span className="featuredTitle"> Total Sales</span>
        <div className="featuredMoneyContainer">
          <span className="featuredMoney">{"₹ "+currentInvoice}</span>
          <span className="featuredMoneyRate">
           {invoiceDiff} {!invoiceVisible &&
            <ArrowDownward  className="featuredIcon negative"/>}
             {invoiceVisible &&
            <ArrowUpward className="featuredIcon"/>}
          </span>
        </div>
        <span className="featuredSub">Compared to last month</span>
      </div>
      <div className="featuredItem">
        <span className="featuredTitle">Total Stock On Hand</span>
        <div className="featuredMoneyContainer">
          <span className="featuredMoney">{stock}</span>
        
        </div>
        
      </div>
    </div>
  );
}
export default FeaturedInfo