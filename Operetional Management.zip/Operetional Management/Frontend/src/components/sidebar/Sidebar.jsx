import "./sidebar.css";
import {
  LineStyle,
  Timeline,
  TrendingUp,
  PermIdentity,
  Storefront,
  AttachMoney,
  BarChart,
  MailOutline,
  DynamicFeed,
  ChatBubbleOutline,
  WorkOutline,
  Group,
  ShoppingCart,
  Receipt,
  Payment,
  CreditCard,
  KeyboardReturn,
  StoreOutlined
 

} from "@material-ui/icons";
import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div className="sidebar">
      <div className="sidebarWrapper">
        <div className="sidebarMenu">
          <h3 className="sidebarTitle">Dashboard</h3>
          <ul className="sidebarList">
            <Link to="/" className="link">
            <li className="sidebarListItem active">
              <LineStyle className="sidebarIcon" />
              Home
            </li>
            </Link>
                          
            <Link to="/salesreport" className="link">
            <li className="sidebarListItem">
              <TrendingUp className="sidebarIcon" />
              Product Sales Report
            </li></Link>
            <Link to="/customersales" className="link">
            <li className="sidebarListItem">
              <PermIdentity className="sidebarIcon" />
              Customer Wise Sales Report
            </li></Link>
             <Link to="/itemsales" className="link">
            <li className="sidebarListItem">
              <MailOutline className="sidebarIcon" />
              Item Wise Sales Report
            </li></Link>
            <Link to="/inventorySummary" className="link">
            <li className="sidebarListItem">
              <BarChart className="sidebarIcon" />
              Inventory Summary Report
            </li></Link>

            <Link to="/inventoryaging" className="link">
            <li className="sidebarListItem">
              <StoreOutlined className="sidebarIcon" />
              Inventory Aging Summary Report
            </li></Link>
          </ul>
        </div>
        <div className="sidebarMenu">
          <h3 className="sidebarTitle">Inventory</h3>
          <ul className="sidebarList">
          <Link to="/itemgroup" className="link">
              <li className="sidebarListItem">
                <Group className="sidebarIcon" />
                Item Group
              </li>
            </Link>
            <Link to="/itemlist" className="link">
              <li className="sidebarListItem">
                <ShoppingCart className="sidebarIcon" />
                Items
              </li>
            </Link>
            <Link to="/adjustmentlist" className="link">
              <li className="sidebarListItem">
                <Storefront className="sidebarIcon" />
                Inventory Adjustment
              </li>
            </Link>
           
          
          </ul>
        </div>
        <div className="sidebarMenu">
          <h3 className="sidebarTitle">Sales</h3>
          <ul className="sidebarList"><Link to="/customerlist" className="link">
            <li className="sidebarListItem">
              <PermIdentity className="sidebarIcon" />
              Customer
            </li>
            </Link>
            <Link to="/salesorder" className="link">
            <li className="sidebarListItem">
              <DynamicFeed className="sidebarIcon" />
              SalesOrder
            </li></Link>
            <Link to="/packages" className="link">
            <li className="sidebarListItem">
              <WorkOutline className="sidebarIcon" />
              Packages
            </li> </Link>
             <Link to="/challans" className="link">
            <li className="sidebarListItem">
              <Receipt className="sidebarIcon" />
              Delivery Challans
            </li></Link>
            <Link to="/invoice" className="link">
            <li className="sidebarListItem">
              <ChatBubbleOutline className="sidebarIcon" />
              Invoices
            </li></Link>
            <Link to="/payment" className="link">
            <li className="sidebarListItem">
              <AttachMoney className="sidebarIcon" />
              Payment Received
            </li></Link>
            <Link to="/salesreturn" className="link">
            <li className="sidebarListItem">
              <KeyboardReturn className="sidebarIcon" />
              Sales Return
            </li></Link>
            <Link to="/creditnote" className="link">
            <li className="sidebarListItem">
              <CreditCard className="sidebarIcon" />
              Credit Notes
            </li></Link>
          </ul>
        </div>
        <div className="sidebarMenu">
          <h3 className="sidebarTitle">Purchase</h3>
          <ul className="sidebarList">
          <Link to="/vendorlist" className="link">
            <li className="sidebarListItem">
              <WorkOutline className="sidebarIcon" />
              Vendors
            </li></Link>
            <Link to="/purchaseorder" className="link">
            <li className="sidebarListItem">
              <DynamicFeed className="sidebarIcon" />
              Purchase Order
            </li></Link>
            <Link to="/bills" className="link">
            <li className="sidebarListItem">
              <Timeline className="sidebarIcon" />
              Bill
            </li></Link>
            <Link to="/vendorpayment" className="link">
            <li className="sidebarListItem">
              <Payment className="sidebarIcon" />
             Payment
            </li></Link>
            <Link to="/vendorcredit" className="link">
            <li className="sidebarListItem">
              <AttachMoney className="sidebarIcon" />
              Vendor Credit
            </li></Link>
          </ul>
        </div>
      </div>
    </div>
  );
}
