import React from 'react'
import { DataGrid } from "@material-ui/data-grid";
import moment from 'moment';
import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';


const BillList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    const [details, setDetails] = useState([]);
    const [searchData, setSearchData] = useState([]);
    const [startDate,setStartDate]= useState(new Date());
  const [endDate,setEndDate]= useState(new Date());
 
    useEffect(() => {  
        sessionStorage.setItem("purchaseOrderId", "0");
             FillData();
          
      },[])     
    
      const makeStyle = (status) => {
        if ( status === 'Closed' ||status === 'Draft' ||status === 'Paid' ||status === 'Send' ) {
            return {
                
                color: 'green',
      
            }
        }
        else if (status === 'Open'|| status === 'Overdue') {
            return {
             
                color: 'red',
            }
        }
        else {
            return {
                
                color: 'white',
      
            }
        }
      }
      const FillData=()=>
  {
   console.log("start");
    axios.get(url+'/bill/read')
    .then((getData)=>{
      setData(getData.data);    
      setSearchData(getData.data);
    })
  }

   
  const handleSelect = (dt) =>{
    let filtered = searchData.filter((data)=>{
      let date = new Date(data["date"]);
      return(date>= dt.selection.startDate &&
        date<= dt.selection.endDate);
    })
    setStartDate(dt.selection.startDate);
    setEndDate(dt.selection.endDate);
    setData(filtered);
  };

 
  const selectionRange = {
    startDate: startDate,
    endDate: endDate,
    key: 'selection',
  }




    const columns = [
      
      { field: "vendorName", headerName: "Vendor Name", width: 150 
      ,
        },
      {
        field: "billNumber",
        headerName: "Bill Number",
        width: 150
      },
    
      {
        field: "date",
        headerName: "Date",
        width: 120,
      },
      
      {
        field: "status",
        headerName: "Status",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <label className='status' style={makeStyle(params.row.status)}>{params.row.status}</label>
              
            </>
          );
        },
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <Link to={"/viewbills/" + params.row.id}>
              <button className="productListEdit">View</button>
            </Link>
              
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      vendorName:row.vendorName,
      billNumber: row.billNumber,
      date: moment(row.date).format("DD-MM-YYYY"),
      status:row.status
     

      
    }))
    
    
    return (
      
      <div className="product">
      <div className="productTitleContainer">


        <h1 className="productTitle">Bill List</h1>
        <Link to="/NewBills">
          <button className="productAddButton">Create New</button>
        </Link>
</div>

        <div className="productTop">
          <div className="productTopLeft">
          <h3 className="productTitle">Select Date Range</h3>
          <DateRangePicker
        ranges={[selectionRange]}
        onChange={handleSelect}
      />
          </div>
          <div className="productTopRight">
          

           <DataGrid autoHeight
          rows={rows}
          columns={columns}
          pageSize={8}
                  
        />
                       
                    
          </div>
      </div>
      

      
    
      
       
        
      </div>
    );
}

export default BillList