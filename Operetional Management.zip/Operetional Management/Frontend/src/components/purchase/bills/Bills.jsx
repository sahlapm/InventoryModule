
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
//import "./invoice.css";
import { DeleteOutline } from "@material-ui/icons";
const Bills = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
          
  const [data,setData]=useState([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:'',brand:'',invoiceId:'',oldInvoicedQuantity:0,salesDetailsId:'',quantityIn:0,inventoryId:'',stockOnHand:0}]);
  const [purchase, setPurchase] = useState([]);
  const [item, setItem] = useState([]);
  const [vendor, seVendor] = useState([]);
  const [invoice,setInvoice]=useState({
    vendorName:'',
              vendorId:'',
              billNumber:'',
              purchaseOrderId:'',
              purchaseOrderNumber:'',
              sourceOfSupply:'',
              date:'',
            dueDate:'',
              terms:'',
                        
            subTotal:0,
            discount:0,
            total:0,
            paidAmount:0,
            status:'--Select Status--'
           
  });
const [visible, setVisible] = useState(true);

var total=0;
  useEffect(() => {

    if(sessionStorage.getItem("purchaseOrderId")!=="0")
    {
    var purchaseOrderId=sessionStorage.getItem("purchaseOrderId");
 
    axios.get(url+'/purchaseOrder/readone/'+purchaseOrderId)
            .then((getData) => {   
              console.log(getData.data);     
               setInvoice({...invoice,["purchaseOrderId"]:purchaseOrderId,["vendorId"]:getData.data.vendorId,["vendorName"]:getData.data.vendorName,["purchaseOrderNumber"]:getData.data.purchaseOrderNumber,["subTotal"]:getData.data.subTotal,["discount"]:getData.data.discount,["total"]:getData.data.total})
            })

            
            axios.get(url+'/purchaseOrder/readDetails/'+purchaseOrderId)
            .then((getData)=>{
              setData(getData.data);    
              const onchangeVal = getData.data
              for( let i=0;i< getData.data.length;i++)
              {
                
                onchangeVal[i]["oldInvoicedQuantity"]=onchangeVal[i]["invoicedQuantity"];

                axios.get(url+'/item/readoneitem/'+ onchangeVal[i]["itemId"])
                .then((response) => {
                  onchangeVal[i]["quantityIn"]=response.data.quantityIn;
                  onchangeVal[i]["inventoryId"]=response.data._id;
                  onchangeVal[i]["stockOnHand"]=response.data.stockOnHand;
                })
                          }
            
              console.log(onchangeVal,"onchangeVal67")
             setData(onchangeVal)  
            })
        setVisible(false)
  
    }
    else
    {
    setVisible(true);
   
    }


    FillVendor();
  FillItem(); 
},[])
const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
  })
}
const FillVendor=()=>
{
    axios.get(url+'/vendor/read')
  .then((getData)=>{
    seVendor(getData.data);   
  })
}
const handleAddmoreClick=(i)=>{
  if(data[i].itemName && data[i].quantity && data[i].rate && data[i].amount)
  {
    if(data[i].itemId ==="--Select Item--")
    {
      alert("Select Item");
    }
    else
    {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(data[i].quantity))
    {
      alert('Quantity is invalid')
    }
    else if(!regex.test(data[i].rate))
    {
      alert('Rate is invalid')
    }
    else if(!regex.test(data[i].amount))
    {
      alert('Amount is invalid')
    }
    else
    {
    setData([...data,{itemName:"",quantity:"",rate:"",amount:""}])
    /*
    sbTotal= parseInt(order.subTotal) + parseInt(data[i].amount);
     order.subTotal=sbTotal;*/
    }
  }
  }
    else
    {
      alert("Invalid item details"); 
     }
}
const handleChangeItems=(e,i)=>{
    const {name,value}=e.target
    console.log(data);
    const onchangeVal = [...data]
      
      if(e.target.name==="quantity" || e.target.name==="rate")
      {
            onchangeVal[i][name]=value
            if(onchangeVal[i]["quantity"] && onchangeVal[i]["rate"])
            {
              total=parseInt(onchangeVal[i]["quantity"]) * parseInt(onchangeVal[i]["rate"]);
              onchangeVal[i]["amount"]=total;
            } 
            setData(onchangeVal)
            CalculateTotal()
      }
      else if(e.target.name==="itemId")
      {
        let item_id=e.target.value;
        if(item_id!=='')
        {
       
          axios.get(url+'/item/readone/'+item_id)
          .then((getData) => {
            console.log(getData.data);

            onchangeVal[i]["rate"]=getData.data.sellingPrice;
            onchangeVal[i]["itemName"]=getData.data.itemName;
            onchangeVal[i]["brand"]=getData.data.brand;
            onchangeVal[i]["itemId"]=e.target.value;
            axios.get(url+'/item/readoneitem/'+item_id)
            .then((getData) => {
              onchangeVal[i]["quantityIn"]=getData.data.quantityIn;
              onchangeVal[i]["inventoryId"]=getData.data._id;
              onchangeVal[i]["stockOnHand"]=getData.data.stockOnHand;
            })
            
            setData(onchangeVal); 
            console.log(onchangeVal,"onchangeVal")         
          })  
        }
      }
     total=0;
}

const handleDelete=(i)=>{
  if(i===0)
  {
    setData([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:''}]);
  }
  else
  {
   
    const deleteVal = [...data]
    deleteVal.splice(i,1)
    setData(deleteVal)
    let sum=0;
 
  for(let i=0;i<deleteVal.length;i++)
  {
     sum=sum+parseInt(deleteVal[i]["amount"]);
  }
  setInvoice({...invoice,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(invoice.discount))})
  }
  //CalculateTotal();
}
const sendDataToAPI = async(event)=>{
  console.log(invoice,"invoice")
  const {vendorId, billNumber, date,subTotal,discount,total,status,purchaseOrderId}=invoice

 if(vendorId && billNumber && date && subTotal && total && status)
 {     
  if(vendorId ==="--Select vendor--")
  {
    alert("Select vendor");
  }
  else if(status ==="--Select Status--")
  {
    alert("Select Status");
  }
  else
  {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(subTotal))
    {
      alert('Sub Total is invalid')
    }
    else if(!regex.test(discount))
    {
      alert('Discount is invalid')
    }
    if(!regex.test(total))
    {
      alert('Total is invalid')
    }
   else{
    
     console.log(invoice,"invoice");
    const response= await  axios.post(url+`/bill/create`,invoice)
    if(response.data.success)
    {
        const onchangeVal = [...data];
        for( let i=0;i<data.length;i++)
        {
          onchangeVal[i]["billId"]=response.data.data._id
          onchangeVal[i]["purchaseDetailsId"]  =data[i]["_id"] 
        }
        let new_list = onchangeVal.map(function(obj) {
          if(obj.paymentReceived!=0)
          {
          return {
            itemName: obj.itemName,
            billNumber: obj.billNumber,
            quantity: obj.quantity,
            rate: obj.rate,
            amount : obj.amount,
            brand  : obj.brand,
            billId: obj.billId,
            itemId: obj.itemId,
            invoicedQuantity: obj.invoicedQuantity,
            oldInvoicedQuantity: obj.oldInvoicedQuantity,
            purchaseDetailsId: obj.purchaseDetailsId,
            quantityIn: obj.quantityIn,
            inventoryId: obj.inventoryId,
            stockOnHand: obj.stockOnHand,
          }}})
        console.log(onchangeVal);
        const Detailsresponse= await  axios.post(url+`/bill/createDetails/`,new_list)
        console.log(new_list,"nl");
       
        let isOk=false;
        let OrderStatus={};
        let Inventory={};
        var Invoiceresponse="";
        var Inventoryresponse="";
        let successcount=0; 
      
        for (let i= 0; i<new_list.length; i++) 
        {
           isOk=false;
          
    if(purchaseOrderId!='')
     {
          OrderStatus={};
          OrderStatus=
          {         
              "quantity":parseInt(new_list[i].quantity)+parseInt(new_list[i].oldInvoicedQuantity)
          
            }
          Invoiceresponse=await axios.put(url+`/purchaseorder/updateInvoice/`+new_list[i].purchaseDetailsId,OrderStatus)
      if( Invoiceresponse.data.success)
      {
        isOk=true;
      }
        }
      else
      {
        isOk=true;
      }
     
      if(isOk)
      {     
       if(status ==="Open" ||status ==="OverDue" ||status ==="Paid")
            {
             
             Inventory={};
         Inventory=
         {         
             "quantityIn":parseInt(new_list[i].quantity) +parseInt(new_list[i].quantityIn)
         }
         console.log(Inventory,"Inventory");
         Inventoryresponse=await axios.put(url+`/item/updateQtyIn/`+new_list[i].inventoryId,Inventory)
         if(Inventoryresponse.data.success)
         {
               successcount++;
         }
        }   

        if(status ==="Open")
        {
         
         Inventory={};
     Inventory=
     {         
         "stockOnHand":parseInt(new_list[i].stockOnHand)+parseInt(new_list[i].quantity),
         "lastBillDate":invoice.date
     }
     console.log(Inventory,"Inventory");
     Inventoryresponse=await axios.put(url+`/item/updateStockonHand/`+new_list[i].inventoryId,Inventory)
     if(Inventoryresponse.data.success)
     {
           successcount++;
     }
    }  
       }
 
      }
     let success=false;
    
     if(successcount===new_list.length)
     {
     if(purchaseOrderId!='')
     {
     const Invresponse=await axios.put(url+`/purchaseorder/updateInvoiceStatus/`+purchaseOrderId)
      if(Invresponse.data.success)
      {
      success=true;
      }
      }
      else
      {
        success=true;
      }
     }
  
        if(Detailsresponse.data.success)
        {
          alert("Bills created successfully");
           navigate('/bills');
        }
        else
        {
          alert("Bills creation failed");
        }
      }
    else
    {
      alert("Bills creation failed");
    }
  }
}
}
 else
{
   alert("Invalid Input");  
}
}

    const handleChange=e=>{
      
        const {name,value}=e.target
        const {subTotal}=invoice;
  
        if( e.target.name ==='discount')
        {
          setInvoice({...invoice,[name]:value,["total"]:(parseInt(subTotal) - parseInt(value))})
        }
        else if(e.target.name ==='vendorId')
        {
        //  alert(e.target.value);
          const custId=e.target.value;
         if(custId!=='')
          {
          axios.get(url+'/vendor/readone/'+custId)
          .then((getData) => {
            let custName = getData.data.name;
            setInvoice({...invoice,[name]:value,["vendorName"]:custName})
          })        
              
            axios.get(url+'/purchaseOrder/purchaseOrderByvendor/'+custId)
            .then((getData) => {
              setPurchase(getData.data);     
              console.log(getData.data,"PO");    
           })  
          }

        
        }
        else  if(e.target.name==="purchaseOrderId")
        {
          let item_id=e.target.value;     
          if(item_id!=='')
          {   
            axios.get(url+'/purchaseorder/readone/'+item_id)
            .then((getData) => {   
              console.log(getData.data);     
               setInvoice({...invoice,[name]:value,["purchaseOrderNumber"]:getData.data.purchaseOrderNumber,["subTotal"]:getData.data.subTotal,["discount"]:getData.data.discount,["total"]:getData.data.total})
            })
console.log(invoice)
            
            axios.get(url+'/purchaseorder/readDetails/'+item_id)
            .then((getData)=>{
              setData(getData.data);     

console.log(getData.data,"getData.data");
              const onchangeVal = getData.data
              for( let i=0;i< getData.data.length;i++)
              {
                
                onchangeVal[i]["oldInvoicedQuantity"]=onchangeVal[i]["invoicedQuantity"];

                axios.get(url+'/item/readoneitem/'+ onchangeVal[i]["itemId"])
                .then((response) => {
                  onchangeVal[i]["quantityIn"]=response.data.quantityIn;
                  onchangeVal[i]["inventoryId"]=response.data._id;
                  onchangeVal[i]["stockOnHand"]=response.data.stockOnHand;
                })
                          }
            
              console.log(onchangeVal,"onchangeVal67")
             setData(onchangeVal)


            })
          }
        }
        else
        {
            setInvoice({...invoice,[name]:value});
        }
     console.log(invoice);
      
     }
  

const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<data.length;i++)
  {
     sum=sum+parseInt(data[i]["amount"]);
  }
  setInvoice({...invoice,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(invoice.discount))})
 
}
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Bills</h1>
        <Link to="/bills">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Bills</Header>
            <Segment>
              <Form>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Vendor Name</label>
                  <span className="salesTotalsValue"> 
                  {visible &&       <select id="Select" name='vendorId'  onChange={handleChange} >
                  <option>--Select Vendor--</option>
                  {vendor.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
  }
   {!visible &&
 <label>{invoice.vendorName}</label>}
                  </span>
               </div> </Form.Field>
               <Form.Field>
              <div className="salesInfoTotals">
                  <label>Purchase Order</label>
                  <span className="salesTotalsValue"> 
            {visible &&      <select id="Select" name='purchaseOrderId'  onChange={handleChange} >
                  <option>--Select Purchase Order--</option>
                  {purchase.map((so,index)=>{return(<option key={index} value={so._id}>{so.purchaseOrderNumber}</option> )})} </select>
  }
   {!visible &&
 <label>{invoice.purchaseOrderNumber}</label>}
                  </span>
               </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Bill Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='billNumber' value={invoice.billNumber} onChange={handleChange}  placeholder='Bill Number'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Source of Supply</label>
                  <span className="salesTotalsValue"> 
                  <input name='sourceOfSupply' value={invoice.sourceOfSupply} onChange={handleChange}  placeholder='Source of Supply'  />
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={invoice.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
                
                
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Due Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='dueDate' value={invoice.dueDate} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
                
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Terms</label>
                  <span className="salesTotalsValue"> 
                  <input  name='terms' value={invoice.terms} onChange={handleChange}   placeholder='Terms'  />
            </span>  </div>  </Form.Field>            
               

                {
                data.map((val,i)=>

                <div className='itemContainerbox' key={i}> 
                <Form.Field>
                <div className='itemRow'>
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                  <label></label> </div>
                </Form.Field>
                <Form.Field>
                <div className='itemRow'>
                <span className='productInfoValue'> 
               <select  id="Select" name='itemId'  onChange={(e)=>handleChangeItems(e,i)} placeholder='Item' >
               <option>--Select Item--</option>
                  {item.map((ds,index)=>{return(<option key={index} value={ds._id}
                  selected={ds._id === val.itemId}
                  > {ds.itemName}</option> )})} </select>
            </span>
             <span className='productInfoValue'> 
              <input  required name='quantity' value={val.quantity} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Quantity'  />
             </span> 
             <span className='productInfoValue'> 
              <input className='productInfoValue' required name='rate' value={val.rate} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Rate'  />
             </span>
             <span className='productInfoValue'> 
              <input required name='amount' value={val.amount} onChange={(e)=>handleChangeItems(e,i)} placeholder='Amount'  />
              </span>
              
              
              <DeleteOutline 
                className="productListDelete" onClick={()=>handleDelete(i)}
                   />
            
              <button className="productListEdit"  onClick={()=>handleAddmoreClick(i)}>Add More Item</button>
           </div> 
              </Form.Field>
              <Form.Field>

              </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft">
              
          </div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue">  <input required name='subTotal' value={invoice.subTotal} onChange={handleChange}   placeholder='Sub Total'  />
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <input required name='discount' value={invoice.discount} onChange={handleChange}  placeholder='Discount'  />
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                 <input required name='total' value={invoice.total} onChange={handleChange}   placeholder='Total'  />
                </span> </div>
                </Form.Field> 
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Amount Paid</label>
                  <span className="salesTotalsValue"> 
                  <input required name='paidAmount' value={invoice.paidAmount} onChange={handleChange}  placeholder='Amount Paid'  />
             </span>  </div> </Form.Field>
                 </div>     </div>        
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={invoice.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Select Status" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>     
      <option>Send</option>
      <option>Overdue</option>     
      <option>Paid</option>
      <option>Closed</option>
    </select></span>
               </div> </Form.Field>       
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/bills' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default Bills