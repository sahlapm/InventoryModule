
import { Button, Segment, Form,Header, StatisticGroup } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 
//import "./invoice.css";

const BillView = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([]);
  const [item, setItem] = useState([]);
 
  const [invoice,setInvoice]=useState({});
  const [status,setStatus]=useState({});    
  let params=useParams();   
  let Id=params.id;
  sessionStorage.setItem("billId", Id);
var total=0;


useEffect(() => {  
    FillInvoice();
 FillDetails();
},[])


const FillInvoice=()=>
{         
  axios.get(url+'/bill/readone/'+Id)
  .then((getData)=>{
    setInvoice(getData.data);  
   
   
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/bill/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
  
  })
}


const sendDataToAPI = async(event)=>{
  

const OrderStatus=
{
  "_id":Id,
    "status":status
}
      const response= await  axios.put(url+`/bill/updateStatus/`+Id,OrderStatus)
      if(response.data.success)
      {
        let success=false;
        if(status ==="Open" ||status ==="OverDue" ||status ==="Paid")
       {
        let  Inventory={};
        let successcount=0;
        var Inventoryresponse="";
        
        for (let i= 0; i<data.length; i++) {
          axios.get(url+'/item/readoneitem/'+data[i].itemId)
          .then((getData) => {
             Inventory={};
          Inventory=
          {         
              "quantityIn":parseInt(data[i].quantity) +parseInt(getData.data.quantityIn)
          }
           console.log(Inventory,"Inventory")
          /**/Inventoryresponse= axios.put(url+`/item/updateQtyIn/`+getData.data._id,Inventory)
          
          if(Inventoryresponse.data.success )
          {
            successcount++;
          }       
        
          
    
          })
      
          }

          if(successcount===data.length)
          {
            success=true;
            }
   }
   if(status ==="Open")
   {
    let  Inventory={};
    let successcount=0;
    var Inventoryresponse="";
    
    for (let i= 0; i<data.length; i++) {
      axios.get(url+'/item/readoneitem/'+data[i].itemId)
      .then((getData) => {
         Inventory={};
      Inventory=
      {         
          "stockOnHand":parseInt(getData.data.stockOnHand)+parseInt(data[i].quantity) 
      }
       
      Inventoryresponse= axios.put(url+`/item/updateStockonHand/`+getData.data._id,Inventory)
      /*alert(Inventoryresponse.data.success )
      if(Inventoryresponse.data.success )
      {*/
        successcount++; 
        if(successcount===data.length)
      {
        success=true;
        }
     /* }  */     
      })
  
      }
     
           }
       
        alert("Status updated successfully");     
      
      }
      else
      {
        alert("Status updation failed");
      }
 

}


const makeStyle = (status) => {
  if (status === 'Shipped' ||status === 'Packed'|| status === 'Clossed' || status === 'Invoiced') {
      return {
          background: 'rgb(145 254 159 / 47%)',
          color: 'green',

      }
  }
  else if (status === 'Not Shipped' ||status === 'Not Packed'|| status === 'Open' || status === 'Not Invoiced') {
      return {
          background: '#ecb3b5',
          color: 'red',
      }
  }
  else {
      return {
          background: '#59bfff',
          color: 'white',

      }
  }
}


  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Bill</h1>
        <Link to="/creditnote">
          <button className="productAddButton">credit note</button>
        </Link>
        <Link to="/bills">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Vendor Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.vendorName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Bill Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.billNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Source Of Supply</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.sourceOfSupply}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{invoice.date}</label>
               </span> </div></Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                <label>Due Date</label>
                <span className="salesTotalsValue"> 
                <label>{invoice.dueDate}</label>
               </span> </div></Form.Field>
                              <Form.Field>
                <div className="salesInfoTotals">
                  <label>Terms</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.terms}</label>
            </span>  </div>  </Form.Field>            
               
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.status}</label>
              </span></div> 
               </Form.Field>
               </div>
         </div>
                {
                data.map((val,i)=>

                <div className='itemContainer' key={i}>
                <Form.Field>
                <div className="itemRow">
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                   </div>
                </Form.Field>
                <Form.Field>
                <div className="itemRow">
                  <label>{val.itemName}</label><label>{val.quantity}</label><label>{val.rate}</label> <label>{val.amount}</label>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue"> 
               <label>{invoice.subTotal}</label>
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.discount}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                  <label>{invoice.total}</label>
                </span> </div>
                </Form.Field>  </div>  
                   </div>    
                   <div className='itemContainer'>   
                <Header as='h3'> Update Status</Header>
                 <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
                  <option>Draft</option>
      <option>Open</option>     
      <option>Send</option>
      <option>Overdue</option>     
      <option>Paid</option>
      <option>Closed</option>
    </select>
                  </span>
                  
                   </div>    </Form.Field>
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/bills' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default BillView