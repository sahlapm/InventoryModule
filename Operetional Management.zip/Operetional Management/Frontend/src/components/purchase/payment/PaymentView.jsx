
import { Button, Segment, Form} from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 
//import "./deliveryChallans.css";

const PaymentView = () => {
  const url="http://localhost:5000/api";
 
  const [data,setData]=useState([]);
 const [payment,setPayment]=useState({});
 
  let params=useParams();   
  let Id=params.id;



useEffect(() => {  
    FillPayment();
 FillDetails();
},[])


const FillPayment=()=>
{         
  axios.get(url+'/vendorpayment/readone/'+Id)
  .then((getData)=>{
    setPayment(getData.data);  
  
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/vendorpayment/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
  console.log(getData.data)
  })
}


  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Payment</h1>
       
        <Link to="/vendorpayment">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Vendor Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{payment.vendorName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Payment Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{payment.paymentNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{payment.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{payment.date}</label>
               </span> </div></Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                <label>Payment Date</label>
                <span className="salesTotalsValue"> 
                <label>{payment.paymentDate}</label>
               </span> </div></Form.Field>
                              <Form.Field>
                <div className="salesInfoTotals">
                  <label>payment Mode</label>
                  <span className="salesTotalsValue"> 
                  <label>{payment.paymentMode}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Paid Through</label>
                  <span className="salesTotalsValue"> 
                  <label>{payment.paidThrough}</label>
              </span></div> 
               </Form.Field>
              
               
               </div>
         </div>
         <div className='itemContainer'>
            <div className="itemRow">
            <label>Date</label><label>Bill Number</label><label>Bill Amount</label>  <label>Payment</label>
                   </div></div>
         {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label name="date" key={i} >{val.date}</label>
                  <label name="invoiceNumber" >{val.billNumber}</label>
                  <label name="total" >{val.total}</label>
                
                  <label name="paymentReceived"  >{val.paymentReceived}</label> 
                  
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>Amount Received</label></span> 
               <span className="salesTotalsValue"> 
               <label>{payment.amountReceived}</label>
                 </span>  </div>   </Form.Field>            
               
                  </div>  
                   </div>    
                   <div className='itemContainer'>   
         
                              
                <Button size='mini' color='grey'>
                  <Link to='/vendorpayment' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default PaymentView