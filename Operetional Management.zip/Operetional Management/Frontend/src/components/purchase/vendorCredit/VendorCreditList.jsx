import React from 'react'

import { DataGrid } from "@material-ui/data-grid";

import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';


const VendorCreditList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    const [details, setDetails] = useState([]);
    const [searchData, setSearchData] = useState([]);
    const [startDate,setStartDate]= useState(new Date());
  const [endDate,setEndDate]= useState(new Date());
  const [searchTerm, setSearchTerm] = useState("");
    useEffect(() => {  
      sessionStorage.setItem("salesOrderId", "0");
             FillData();
             
      },[])     
    
      const makeStyle = (status) => {
        if ( status === 'Closed' || status === 'Draft' ) {
            return {
                
                color: 'green',
      
            }
        }
        else if (status === 'Open') {
            return {
             
                color: 'red',
            }
        }
        else {
            return {
                
                color: 'white',
      
            }
        }
      }
      const FillData=()=>
  {
   console.log("start");
    axios.get(url+'/vendorcredit/read')
    .then((getData)=>{
      setData(getData.data);    
      setSearchData(getData.data)
    })
  }


  const handleSelect = (dt) =>{
    let filtered = searchData.filter((data)=>{
      let date = new Date(data["date"]);
      return(date>= dt.selection.startDate &&
        date<= dt.selection.endDate);
    })
    setStartDate(dt.selection.startDate);
    setEndDate(dt.selection.endDate);
    setData(filtered);
  };


  const selectionRange = {
    startDate: startDate,
    endDate: endDate,
    key: 'selection',
  }




    const columns = [
      
      {
        field: "vendorName",
        headerName: "Vendor Name",
        width: 150
      },
      {
        field: "creditNoteNumber",
        headerName: "Credit Note Number",
        width: 120
      },
      {
        field: "orderNumber",
        headerName: "Order Number",
        width: 120,
      },
      {
        field: "vendorCreditDate",
        headerName: "Vendor Credit Date",
        width: 120,
      },
     
     
      {
        field: "status",
        headerName: "Status",
        width: 120,
        renderCell: (params) => {
          return (
            <>
              <label className='status' style={makeStyle(params.row.status)}>{params.row.status}</label>
              
            </>
          );
        },
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <Link to={"/viewvendorcredit/" + params.row.id}>
              <button className="productListEdit">View</button>
            </Link>
              
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      vendorName : row.vendorName,
      creditNoteNumber: row.creditNoteNumber,
      orderNumber:row.orderNumber,
      vendorCreditDate: row.vendorCreditDate,
      status: row.status
            
    }))
    
    
    return (
      
      <div className="product">
      <div className="productTitleContainer">


        <h1 className="productTitle">Vendor Credit List</h1>
        <Link to="/Newvendorcredit">
          <button className="productAddButton">Create New</button>
        </Link>
</div>

        <div className="productTop">
          <div className="productTopLeft">
          <h3 className="productTitle">Select Date Range</h3>
          <DateRangePicker
        ranges={[selectionRange]}
        onChange={handleSelect}
      />
          </div>
          <div className="productTopRight">
                <DataGrid autoHeight
          rows={rows}
          columns={columns}
          pageSize={8}
          
         
        />
                       
                    
          </div>
      </div>
      

       
    
      
       
        
      </div>
    );
}

export default VendorCreditList