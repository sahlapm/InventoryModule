
import { Button, Segment, Form,Header, StatisticGroup } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 


const VendorCreditView = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([]);
  const [item, setItem] = useState([]);
 
  const [credit,setCredit]=useState({});
  const [status,setStatus]=useState({});    
  let params=useParams();   
  let Id=params.id;


useEffect(() => {  
 FillCredit();
 FillDetails();
},[])


const FillCredit=()=>
{         
  axios.get(url+'/vendorcredit/readone/'+Id)
  .then((getData)=>{
    setCredit(getData.data);     
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/vendorcredit/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
   
  })
}



const sendDataToAPI = async(event)=>{
  

const OrderStatus=
{
  "_id":Id,
    "status":status
}
      const response= await  axios.put(url+`/vendorCredit/updateStatus/`+Id,OrderStatus)
      if(response.data.success)
      {
        let success=false;
        if(status ==="Open" ||status ==="Closed")
       {
        let  Inventory={};
        let successcount=0;
        var Inventoryresponse="";
        
        for (let i= 0; i<data.length; i++) {
          axios.get(url+'/item/readoneitem/'+data[i].itemId)
          .then((getData) => {
             Inventory={};
          Inventory=
          {         
              "quantityOut":parseInt(data[i].quantity) +parseInt(getData.data.quantityOut)
          }
           console.log(Inventory,"Inventory")
          /**/Inventoryresponse= axios.put(url+`/item/updateQtyOut/`+getData.data._id,Inventory)
          
          if(Inventoryresponse.data.success )
          {
            successcount++;
          }
         
        
          if(successcount===data.length)
          {
            success=true;
            }
    
          })
      
          }


      }
        
        
        
        alert("Status updated successfully");        
      }
      else
      {
        alert("Status updation failed");
      }
}

 return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Vendor Credit</h1>
       
        <Link to="/vendorcredit">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Vendor Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.vendorName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Credit Note Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.creditNoteNumber}</label>
                </span></div>
                
                </Form.Field>
               
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.orderNumber}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Vendor Credit Date</label>
                <span className="salesTotalsValue"> 
                <label>{credit.vendorCreditDate}</label>
               </span> </div></Form.Field>
                                         
              
               </div>
         </div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                <Form.Field>
                <div className="itemRow">
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                   </div>
                </Form.Field>
                <Form.Field>
                <div className="itemRow">
                  <label>{val.itemName}</label><label>{val.quantity}</label><label>{val.rate}</label> <label>{val.amount}</label>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue"> 
               <label>{credit.subTotal}</label>
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.discount}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.total}</label>
                </span> </div>
                </Form.Field>  </div>  
                   </div>    
                   <div className='itemContainer'>   
                <Header as='h3'> Update Status</Header>
                 <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"    required>
                                 
                  <option>--Select Status--</option>
                  <option>Draft</option>
      <option>Open</option>
           <option>Closed</option>
    </select>
                  </span>
                  
                   </div>    </Form.Field>
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/vendorcredit' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default VendorCreditView