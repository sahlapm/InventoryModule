
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,Link} from 'react-router-dom' 
//import "./salesOrder.css";

const PurchaseOrderView = () => {
  const url="http://localhost:5000/api";

  const [data,setData]=useState([]);

  const [order,setOrder]=useState({});
  const [status,setStatus]=useState({});    
  let params=useParams();   
  let Id=params.id;
  sessionStorage.setItem("purchaseOrderId", Id);



useEffect(() => {  
 FillOrder();
 FillDetails();
},[])


const FillOrder=()=>
{
         
  axios.get(url+'/purchaseorder/readone/'+Id)
  .then((getData)=>{
    setOrder(getData.data);  
    sessionStorage.setItem("customerId", getData.data.customerId);
    
   
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/purchaseorder/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
  
  })
}



const sendDataToAPI = async(event)=>{
  

const OrderStatus=
{
  "_id":Id,
    "status":status
}
      const response= await  axios.put(url+`/purchaseorder/updateStatus/`+Id,OrderStatus)
      if(response.data.success)
      {
        let success=false;
        if(status ==="Open" ||status ==="Closed")
       {
        let  Inventory={};
        let successcount=0;
        var Inventoryresponse="";
        
        for (let i= 0; i<data.length; i++) {
          axios.get(url+'/item/readoneitem/'+data[i].itemId)
          .then((getData) => {
             Inventory={};
          Inventory=
          {         
              "quantityOrdered":parseInt(data[i].quantity) +parseInt(getData.data.quantityOrdered)
          }
           console.log(Inventory,"Inventory")
          /**/Inventoryresponse= axios.put(url+`/item/updateorderedQty/`+getData.data._id,Inventory)
          
          if(Inventoryresponse.data.success )
          {
            successcount++;
          }
         
        
          if(successcount===data.length)
          {
            success=true;
            }
    
          })
      
          }


      }
        
        
        alert("Status updated successfully");        
      }
      else
      {
        alert("Status updation failed");
      }
 

}




  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Purchase order</h1>
        <Link to="/NewBills">
          <button className="headerdButton">Convert To Bill</button>
        </Link>
        <Link to="/purchaseorder">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Vendor Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.vendorName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Purchase Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.purchaseOrderNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.date}</label>
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected Delivery Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.expectedDeliveryDate}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Shipment Preferences</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.shipmentPreference}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.description}</label>
              </span></div> 
               </Form.Field>
               </div>
          </div>
            <div className='itemContainer'>
            <Form.Field>
                <div className="itemRow">
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                   </div>
                </Form.Field></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label>{val.itemName}</label>

                 


                  <label>{val.quantity}</label><label>{val.rate}</label> <label>{val.amount}</label>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue"> 
               <label>{order.subTotal}</label>
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.discount}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.total}</label>
                </span> </div>
                </Form.Field>  </div>  
                   </div>    
                   <div className='itemContainer'>   
                <Header as='h3'> Update Status</Header>
                 <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>
      <option>Dispatched</option>
      <option>Delivered</option>
      <option>Void</option>
      <option>On hold</option>
      <option>Closed</option>
    </select>
                  </span>
                  
                   </div>    </Form.Field>
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/learner' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default PurchaseOrderView