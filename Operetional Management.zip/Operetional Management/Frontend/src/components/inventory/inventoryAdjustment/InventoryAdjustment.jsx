
import { Button, Segment, Form, TextArea, Dropdown, Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 

const InventoryAdjustment = () => {

  const url="http://localhost:5000/api";


  const navigate=useNavigate();  
  const [item, setItem] = useState([]);
  const [adjustment,SetAdjustment]=useState({
    mode:'Quantity',
              referenceNumber:'',
              date:'',
              reason:'',
              description:'',
              itemName:'',
              currentValue:'',
              changedValue:'',
              adjustedValue:'',
             file:''
  });

  useEffect(() => {
    FillItem(); 
 
},[])

const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
     
  })
}

  const sendDataToAPI = async(event)=>{
    const {mode, date, reason, itemName,currentValue,changedValue, adjustedValue}=adjustment
   if(mode && itemName && date && reason && currentValue && changedValue && adjustedValue)
   {     
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    
    if(!regex.test(currentValue))
    {
      alert('Current Value is invalid')
    }
    else if(!regex.test(changedValue))
    {
      alert('Changed Value is invalid')
    }
    if(!regex.test(adjustedValue))
    {
      alert('Adjusted Value is invalid')
    }
     else{
        const config={
        headers :{'content-type':'multipart/form-data'}};
      const formData=new FormData();
      formData.append('mode',adjustment.mode);
      formData.append('referenceNumber',adjustment.referenceNumber);
      formData.append('date',adjustment.date);
      formData.append('reason',adjustment.reason);
      formData.append('description',adjustment.description);
      formData.append('itemName',adjustment.itemName);
      formData.append('currentValue',adjustment.currentValue);
      formData.append('changedValue',adjustment.changedValue);
      formData.append('adjustedValue',adjustment.adjustedValue);
      formData.append('file',adjustment.file);
     
     const response= await  axios.post(url+`/adjustment/create`,formData,config)
     
     if(response.data.success)
     {
       alert("Adjustment created successfully");
       navigate('/adjustmentlist');
     }
     else
     {
       alert("Adjustment Creation failed");
     }  
    }
 }
   else
   {
     alert("Invalid Input");  }
  
    }
    const handleChange=e=>{
      if(e.target.name !=='file')
      {
        const {name,value}=e.target
        SetAdjustment({...adjustment,[name]:value})
        console.log(value)
        
      }
      else
      {
       let name=e.target.name;
       let value=e.target.files[0];
       SetAdjustment({...adjustment,[name]:value})
       console.log(value);
        } 
   
     }

  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Inventory Adjustment</h1>
        <Link to="/itemlist">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Adjustment</Header>
            <Segment>
              <Form>
              <Form.Field>
                  <label>Mode of Adjustment</label>
                  <select id="Select" name='mode' value={adjustment.mode} onChange={handleChange}   placeholder="mode" required>
        <option>Quantity</option>
      <option>Value</option>   
          </select>
                </Form.Field>
            
                <Form.Field>
                  <label>ReferenceNumber</label>
                  <input required name='referenceNumber' value={adjustment.referenceNumber} onChange={handleChange}  placeholder='Reference Number'  />
                </Form.Field>

                <Form.Field>
                <label>Date</label>
            
                  <input type='date' required name='date' value={adjustment.date} onChange={handleChange}   placeholder='Date'  />
                </Form.Field>
                <Form.Field>
                  <label>Reason</label>
                  <input required name='reason' value={adjustment.reason} onChange={handleChange}   placeholder='Reasonnsion'  />
                </Form.Field>            
                <Form.Field>
                  <label>Description</label>
                  <input required name='description' value={adjustment.description} onChange={handleChange}  placeholder='Description'  />
                </Form.Field>
                <div className='itemContainer'>
                <Form.Field>
                  <label>Item</label>
                  <select id="Select" name='itemName' value={adjustment.itemName} onChange={handleChange} >
                  {item.map((ds,index)=>{return(<option key={index}>{ds.itemName}</option> )})} </select>
                </Form.Field>
                <Form.Field>
                  <label>Current Value</label>
                  <input required name='currentValue' value={adjustment.currentValue} onChange={handleChange}  placeholder='Current Value'  />
                </Form.Field>
                <Form.Field>
                  <label>Changed Value</label>
                  <input required name='changedValue' value={adjustment.changedValue} onChange={handleChange}  placeholder='Changed Value'  />
                </Form.Field>
                <Form.Field>
                  <label>Adjusted Value</label>
                  <input required name='adjustedValue' value={adjustment.adjustedValue} onChange={handleChange}  placeholder='Adjusted Value'  />
                </Form.Field>
                </div>
                 <Form.Field>
                  <label>File</label>
                  <input type="file"  name="file" onChange={handleChange}  placeholder='Choose file'/>
                                </Form.Field>

               



                <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>

                <Button size='mini' color='grey'>
                  <Link to='/learner' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default InventoryAdjustment