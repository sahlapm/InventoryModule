import React from 'react'
import "./InventoryAdjustment.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";

import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';


const ItemList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])

     
    
      const handleDelete=(id)=>
      {
     /*   var token=sessionStorage.getItem("userToken");
        const  headers ={'x-access-token':token};*/
        console.log("start");
        axios.delete(url+'/adjustment/delete/'+id)
        .then((response)=>
        {if(response.data.status==="success")
        {
          alert("Adjustment deleted successfully");
          FillData();
        }
        else
        {
          alert("Something went wrong");
        }
        })
      }
    
      const FillData=()=>
  {
    axios.get(url+'/adjustment/read')
    .then((getData)=>{
      setData(getData.data);    
    })
  }

    
  
    const columns = [
       
      { field: "mode", headerName: "Mode", width: 160 
      ,
      
    },
      {
        field: "referenceNumber",
        headerName: "Reference Number",
        width: 150
      },
      { field: "date", headerName: "Date", width: 150 },
      {
        field: "reason",
        headerName: "Reason",
        width: 200,
      },
      {
        field: "itemName",
        headerName: "Item Name",
        width: 160,
      },
      {
        field: "currentValue",
        headerName: "Current Value",
        width: 150,
      },
      {
        field: "changedValue",
        headerName: "Changed Value",
        width: 150,
      },
      {
        field: "adjustedValue",
        headerName: "Adjusted Value",
        width: 150,
      },
      {
        field: "action",
        headerName: "Action",
        width: 120,
        renderCell: (params) => {
          return (
            <>
              
              <DeleteOutline
                className="productListDelete"
                onClick={() => handleDelete(params.row.id)}
              />
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      mode:row.mode,
      referenceNumber: row.referenceNumber,
      date:row.date,
      reason:row.reason,
      itemName:row.itemName,
      currentValue: row.currentValue,
      changedValue:row.changedValue,
      adjustedValue:row.adjustedValue

    }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Inventory Adjustment</h1>
        <Link to="/adjustment">
          <button className="productAddButton">Create New</button>
        </Link>
      </div>
        <DataGrid
          rows={rows}
         
          columns={columns}
      
         
        />
        
      </div>
    );
}

export default ItemList