
import { Button, Form,  Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
import "./item.css";

const Items = () => {

  const url="http://localhost:5000/api";


  const navigate=useNavigate();  
  const [itemGroup, setItemGroup] = useState([]);
  const [item,setItem]=useState({
    type:'Product',
              itemName:'',
              itemGroupName:'',
              sku:'',
              unit:'',
              dimension:'',  
              weight:'',
              manufacturer:'',
              brand:'',
              sellingPrice:'',
              costPrice:'',  
              description:'',
              openingStock:'',
              reorderPoint:'',
              preferedVendor:'',
             file:''
  });

  useEffect(() => {
    FillGroup(); 
 
},[])

const FillGroup=()=>
{
  axios.get(url+'/itemgroup/read')
  .then((getData)=>{
    setItemGroup(getData.data);   
     
  })
}

  const sendDataToAPI = async(event)=>{
    const {type,itemName, unit, dimension, weight,manufacturer, brand ,sellingPrice , costPrice,description,
      openingStock,reorderPoint, preferedVendor,file}=item
  /* if(type && itemName && unit && dimension&& weight && manufacturer && brand && sellingPrice && costPrice && description && openingStock && reorderPoint && preferedVendor && file)
   {*/
     let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    
     if(!regex.test(sellingPrice))
     {
       alert('Selling price is invalid')
     }
     else if(!regex.test(costPrice))
     {
       alert('Cost price is invalid')
     }
     if(!regex.test(openingStock))
     {
       alert('Opening Stock is invalid')
     }
     else if(!regex.test(reorderPoint))
     {
       alert('Reorder Point is invalid')
     }
     else
     {
       /*var token=sessionStorage.getItem("userToken");*/
       const config={
        headers :{'content-type':'multipart/form-data'}};
      const formData=new FormData();
      console.log("type : "+item.file);
      formData.append('type',item.type);
      formData.append('itemGroupName',item.itemGroupName);
      formData.append('itemName',item.itemName);
      formData.append('sku',item.sku);
      formData.append('unit',item.unit);
      formData.append('dimension',item.dimension);
      formData.append('weight',item.weight);
      formData.append('manufacturer',item.manufacturer);
      formData.append('brand',item.brand);
      formData.append('sellingPrice',item.sellingPrice);
      formData.append('costPrice',item.costPrice);
      formData.append('description',item.description);
      formData.append('openingStock',item.openingStock);
      formData.append('reorderPoint',item.reorderPoint);
      formData.append('preferedVendor',item.preferedVendor);
      formData.append('file',item.file);
     
     const response= await  axios.post(url+`/item/create`,formData,config)
     
     if(response.data.success)
     {
       
    let Inventory=
          {         
              "itemName": item.itemName,
              "sku": item.sku,
              "openingStock": item.openingStock,
              "reorderPoint": item.reorderPoint,
               "itemId": response.data.data._id,
               "quantityOrdered": 0,
               "quantityIn":0,
               "quantityOut":0,
               "committedStock":0,
               "stockOnHand":0,
               "lastBillDate":new Date(),
               "file":item.file
          }

          const Inventoryresponse=await axios.post(url+`/item/createInventory`,Inventory)
          if(Inventoryresponse.data.success)
          {
      
      alert("Items created successfully");
       navigate('/itemlist');
          }
    
     else
     {
       alert("Items Creation failed");
     }
    }
    else
    {
      alert("Items Creation failed");
    }
   }
  /* }
   else
   {
     alert("Invalid Input");
   }
   */
    }
    const handleChange=e=>{
      if(e.target.name !=='file')
      {
        const {name,value}=e.target
        setItem({...item,[name]:value})
        
      }
      else
      {
       let name=e.target.name;
       let value=e.target.files[0];
      setItem({...item,[name]:value})
        } 
   
     }

  return (
    <div className="product">
      
      <div className="productTitleContainer">
        <h1 className="productTitle">Items</h1>
        <Link to="/itemlist">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Items</Header>
            <div className="topBox">
            
              
              <div className="topboxLeft">
                <Form>
              <Form.Field>
                  <label>Type</label>
                  <select id="Select" name='type' value={item.type} onChange={handleChange} className="form-control form-control-md"   placeholder="Type" required>
    
    <option>Product</option>
      <option>Services</option>
      
      
    </select>
                </Form.Field>
                <Form.Field>
                  <label>Item Group</label>
                  <select id="Select" name='itemGroupName' value={item.itemGroupName} onChange={handleChange} >
                  {itemGroup.map((ds,index)=>{return(<option key={index}>{ds.itemGroupName}</option> )})} </select>
                </Form.Field>
               
                <Form.Field>
                  <label>Item Name</label>
                  <input required name='itemName' value={item.itemName} onChange={handleChange}  placeholder='Item Name'  />
                </Form.Field>
                <Form.Field>
                  <label>SKU</label>
                  <input required name='sku' value={item.sku} onChange={handleChange}  placeholder='SKU'  />
                </Form.Field>
                <Form.Field>
                  <label>Unit</label>
                  <input required name='unit' value={item.unit} onChange={handleChange}   placeholder='Unit'  />
                </Form.Field>
                <Form.Field>
                  <label>Dimension</label>
                  <input required name='dimension' value={item.dimension} onChange={handleChange}   placeholder='Dimension'  />
                </Form.Field>

                <Form.Field>
                  <label>Weight</label>
                  <input required name='weight' value={item.weight} onChange={handleChange}  placeholder='Weight'  />
                </Form.Field>
                
                <Form.Field>
                  <label>Manufacturer</label>
                  <input required name='manufacturer' value={item.manufacturer} onChange={handleChange}  placeholder='Manufacturer'  />
                </Form.Field>

                <Form.Field>
                  <label>Brand</label>
                  <input required name='brand' value={item.brand} onChange={handleChange}  placeholder='Brand'  />
                </Form.Field>
                </Form>
                </div>
                <div className="topboxRight">
                  <Form>
                <Form.Field>
                  <label>Selling Price</label>
                  <input required name='sellingPrice' value={item.sellingPrice} onChange={handleChange}   placeholder='Selling Price'  />
                </Form.Field>

                <Form.Field>
                  <label>Cost Price</label>
                  <input required name='costPrice' value={item.costPrice} onChange={handleChange}  placeholder='Cost Price'  />
                </Form.Field>
               
                <Form.Field>
                  <label>Description</label>
                  <input required name='description' value={item.description} onChange={handleChange}  placeholder='Description'  />
                </Form.Field>
                <Form.Field>
                  <label>Opening Stock</label>
                  <input required name='openingStock' value={item.openingStock} onChange={handleChange}  placeholder='Opening Stock'  />
                </Form.Field>

                <Form.Field>
                  <label>Re order point</label>
                  <input required name='reorderPoint' value={item.reorderPoint} onChange={handleChange}  placeholder='Re order point'  />
                </Form.Field>
                <Form.Field>
                  <label>Prefered Vendor</label>
                  <input required name='preferedVendor' value={item.preferedVendor} onChange={handleChange}  placeholder='Prefered Vendor'  />
                </Form.Field>

                <Form.Field>
                  <label>Image</label>
                  <input type="file"  name="file" onChange={handleChange}  placeholder='Choose file'/>
                                </Form.Field>

               
                              
<Form.Field>

                <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>

                <Button size='mini' color='grey'>
                  <Link to='/itemlist' style={{ color: '#FFF' }}>Cancel</Link>
                </Button> </Form.Field> </Form> </div>
              
            </div>
          </div>
    </div>
  )
}

export default Items