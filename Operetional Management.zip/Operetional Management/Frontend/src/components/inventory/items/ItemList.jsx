import React from 'react'
//import "./ItemList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";

import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';

const ItemList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])

     
    
      const handleDelete=(id)=>
      {
     /*   var token=sessionStorage.getItem("userToken");
        const  headers ={'x-access-token':token};*/
        console.log("start");
        axios.delete(url+'/item/delete/'+id)
        .then((response)=>
        {if(response.data.status==="success")
        {
          alert("Item deleted successfully");
          FillData();
        }
        else
        {
          alert("Something went wrong");
        }
        })
      }
    
      const FillData=()=>
  {
    axios.get(url+'/item/read')
    .then((getData)=>{
      setData(getData.data);    
    })
  }

    
  
    const columns = [
        
      { field: "itemName", headerName: "Item Name", width: 200 
      ,
      renderCell: (params) => {
        return (
          <div className="productListItem">
            <img className="productListImg" src={url+"/item/ProductImage/"+params.row.file} alt="" />
            {params.row.itemName}
          </div>
          
        );
      },
    },
      {
        field: "unit",
        headerName: "Unit",
        width: 150
      },
      { field: "brand", headerName: "Brand", width: 150 },
      {
        field: "manufacturer",
        headerName: "Manufacturer",
        width: 200,
      },
      {
        field: "sellingPrice",
        headerName: "Selling Price",
        width: 160,
      },
      {
        field: "costPrice",
        headerName: "Cost Price",
        width: 160,
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              
              <DeleteOutline
                className="productListDelete"
                onClick={() => handleDelete(params.row.id)}
              />
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      itemName:row.itemName,
      unit: row.unit,
      brand:row.brand,
      manufacturer: row.manufacturer,
      sellingPrice:row.sellingPrice,
      costPrice:row.costPrice,
      file:row.file

    }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Item List</h1>
        <Link to="/items">
          <button className="productAddButton">Create New</button>
        </Link>
      </div>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={8}
          
         
        />
        
      </div>
    );
}

export default ItemList