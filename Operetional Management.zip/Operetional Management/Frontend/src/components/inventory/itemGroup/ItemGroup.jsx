
import { Button, Segment,Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import "./itemGroup.css";
import React, { useState , useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
import { DataGrid } from "@material-ui/data-grid";


const ItemGroup = () => {

  const url="http://localhost:5000/api";


  const navigate=useNavigate();  
  const [visible, setVisible] = useState(true);
  const [itemGroups,setItemGroups]=useState({
    type:'Product',
              itemGroupName:'',
              unit:'',
              manufacturer:'',
              brand:'',
              description:'',
              file:''
  });
  const [data, setData] = useState([]);
  const [item, setItem] = useState([]);

  useEffect(() => {
    setTimeout(() => {
      FillData();
    }, 1000)
           },[])
const FillProduct=(groupName)=>
  {
    console.log(groupName);
    axios.get(url+'/item/readbygroup/'+groupName)
    .then((getData)=>{
      setItem(getData.data);  
      
    })
  }
const FillData=()=>
{
  axios.get(url+'/itemgroup/read')
  .then((getData)=>{
    setData(getData.data);   
     
  })
}

const getDetails=(type,itemGroupName,unit,manufacturer,brand,description,file)=>{
  console.log("type : "+itemGroupName)
  setItemGroups({
  type:type,
  itemGroupName :itemGroupName,
  unit:unit,
  manufacturer:manufacturer,
  brand:brand,
  description:description,
  file:file
}) 
FillProduct(itemGroupName);
 setVisible(false);
 }

 const Itemcolumns = [

  { field: "itemName", headerName: "Item Name", width: 300 
  ,
  renderCell: (params) => {
    return (
      <div className="productListItem">
        <img className="productListImg" src={url+"/item/ProductImage/"+params.row.file} alt="" />
        {params.row.itemName}
      </div>
      
    );
  },
  },
  

  ];

  const Itemrows=item.map((row)=>({
    id : row._id,
    itemName:row.itemName,    
  file:row.file
  }))

const columns = [

{ field: "itemGroupName", headerName: "Item Group Name", width: 300 
,
renderCell: (params) => {
  return (
    <div className="productListItem">
      <img className="productListImg" src={url+'/itemgroup/ItemGroupImage/'+params.row.file} alt="" />
      {params.row.itemGroupName}
    </div>
  );
},
},

{
  field: "action",
  headerName: "Action",
  width: 250,
   renderCell: (params) => {
        return (
          <>
            
              <button className="productListEdit"
              onClick={()=>getDetails(params.row.type,params.row.itemGroupName,params.row.unit,params.row.manufacturer,params.row.brand,params.row.description,params.row.file)}
              >View Details</button>
          
          
          </>
        );
      },
},
];

const rows=data.map((row)=>({
  id : row._id,
  type:row.type,
  itemGroupName:row.itemGroupName,
  unit:row.unit,
  manufacturer:row.manufacturer,
  brand:row.brand,
  description:row.description,
  file:row.file
  

}))

const clear=()=>{
  setItemGroups({
    type:'Product',
    itemGroupName:'',
    unit:'',
    manufacturer:'',
    brand:'',
    description:'',
    file:''
})

 }
 const createNewGroup=()=>{
  setItemGroups({
    type:'Product',
    itemGroupName:'',
    unit:'',
    manufacturer:'',
    brand:'',
    description:'',
    file:''
})
setVisible(true);
 }
  const sendDataToAPI = async(event)=>{
    const {type,itemGroupName, unit, manufacturer, brand ,description,file}=itemGroups
   if(type && itemGroupName && unit && manufacturer && brand && description && file)
   {
    
       /*var token=sessionStorage.getItem("userToken");*/
       const config={
        headers :{'content-type':'multipart/form-data'}};
      const formData=new FormData();
      
      formData.append('type',itemGroups.type);
      formData.append('itemGroupName',itemGroups.itemGroupName);
      formData.append('unit',itemGroups.unit);
      formData.append('manufacturer',itemGroups.manufacturer);
      formData.append('brand',itemGroups.brand);
      formData.append('description',itemGroups.description);
      formData.append('file',itemGroups.file);
     
     const response= await  axios.post(url+`/itemgroup/create`,formData,config)
     
     if(response.data.success)
     {
       alert("ItemGroup created successfully");
       FillData();
     }
     else
     {
       alert("ItemGroup Creation failed");
     }
   

   }
   else
   {
     alert("Invalid Input");
   }
  
    }
    const handleChange=e=>{
      console.log(e.target.name);
      if(e.target.name !=='file')
      {
        const {name,value}=e.target
        setItemGroups({...itemGroups,[name]:value})
        console.log("name:"+name);
      }
      else
      {
       let name=e.target.name;
       let value=e.target.files[0];
      setItemGroups({...itemGroups,[name]:value})
      
      } 
      
     }

  return (
    <div className="product">
      <div className="productTitleContainer">
        <h1 className="productTitle">Item Group</h1>
        
          <button className="productAddButton" onClick={createNewGroup}>Create New</button>
        
      </div>
      <div className="productTop">


      <div className="topLeft">
      <div className='itemGroupTop'>
      <Header as='h3'>Item Groups</Header>
      <DataGrid autoHeight
          rows={rows}
         
          columns={columns}
          pageSize={8}       
         
        /></div>
    {!visible &&  
      <div className='itemGroupTop'>
      <Header as='h3'>Items under selected Group</Header>
      <DataGrid autoHeight
          rows={Itemrows}
         
          columns={Itemcolumns}
          pageSize={8}
         
         
        />  </div>}
          </div>
          <div className="topRight">
             
              <div className="infoBottom">
                 <Header as='h3'>New Item Group</Header>
            <Segment>
              <Form>
              <Form.Field>
                  <label>Type</label>
                  <select id="Select" name='type' value={itemGroups.type} onChange={handleChange} className="form-control form-control-md"   placeholder="Area of Training" required>
    
    <option>Product</option>
      <option>Services</option>
      
      
    </select>
                </Form.Field>
                <Form.Field>
                  <label>Item Group Name</label>
                  <input required name='itemGroupName' value={itemGroups.itemGroupName} onChange={handleChange}  placeholder='Item Name'  />
                </Form.Field>

                <Form.Field>
                  <label>Unit</label>
                  <input required name='unit' value={itemGroups.unit} onChange={handleChange}   placeholder='Unit'  />
                </Form.Field>
                
                <Form.Field>
                  <label>Manufacturer</label>
                  <input required name='manufacturer' value={itemGroups.manufacturer} onChange={handleChange}  placeholder='Manufacturer'  />
                </Form.Field>

                <Form.Field>
                  <label>Brand</label>
                  <input required name='brand' value={itemGroups.brand} onChange={handleChange}  placeholder='Brand'  />
                </Form.Field>
                              
                <Form.Field>
                  <label>Description</label>
                  <input required name='description' value={itemGroups.description} onChange={handleChange}  placeholder='Description'  />
                </Form.Field>
               
                <Form.Field>
                  <label>Image</label>
                  <input type="file"  name="file" onChange={handleChange}  placeholder='Choose file'/>
                                </Form.Field>
                                {visible &&
                                     <Form.Field>
                <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>

                <Button size='mini' color='grey' onClick={clear}>
                 Clear
                </Button></Form.Field>}
              </Form>
            </Segment>
              </div>
          </div>



            
          </div>
      
    </div>
  )
}

export default ItemGroup