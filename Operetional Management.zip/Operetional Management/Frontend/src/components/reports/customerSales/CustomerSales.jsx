import React from 'react'
import { DataGrid } from "@material-ui/data-grid";
import { useState,useEffect } from "react";
import axios from 'axios';

const CustomerSales = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])

  const FillData=()=>
  {
    axios.get(url+'/invoice/customerwisesale')
    .then((getData)=>{
      setData(getData.data);    
    })
  }


    const columns = [
        
      { field: "name", headerName: "Name", width: 200 
     
    },
      {
        field: "invoiceCount",
        headerName: "Invoice Count",
        width: 200
      },
      { field: "Sales", headerName: "Sales", width: 200 },
    
     
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      name:row.name,
      invoiceCount:row.invoiceCount,
        Sales: row.Sales

    }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Customer wise Sales</h1>
       
      </div>
        <DataGrid autoHeight
          rows={rows}
          columns={columns}
          pageSize={8}
          rowsPerPageOptions={[8]}
        />
        
      </div>
    );
}

export default CustomerSales