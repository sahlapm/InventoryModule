import React from 'react'
import { DataGrid } from "@material-ui/data-grid";
import moment from 'moment';
import { useState,useEffect } from "react";
import axios from 'axios';

const InventoryAgingSummary = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])

     
    
    
    
      const FillData=()=>
      {
        axios.get(url+'/item/readInventory')
        .then((getData)=>{
         //setData(getData.data);
         const onchangeVal=getData.data;   
          for( let i=0;i< getData.data.length;i++)
          {          
              const currentDate = moment(); // Current date and time
              const createdAtDate = moment(onchangeVal[i]["lastBillDate"]); // Specific date
              const differenceInDays = currentDate.diff(createdAtDate, 'days');
              onchangeVal[i]["less30"]=differenceInDays >= 0 && differenceInDays < 31 ? (onchangeVal[i]["stockOnHand"]) : ('0');
              onchangeVal[i]["less60"]=differenceInDays > 30 && differenceInDays < 61 ? (onchangeVal[i]["stockOnHand"]) : ('0');
              onchangeVal[i]["less90"]=differenceInDays > 60 && differenceInDays < 91 ? (onchangeVal[i]["stockOnHand"]) : ('0');
              onchangeVal[i]["above90"]=differenceInDays > 90 ? (onchangeVal[i]["stockOnHand"]) : ('0');
          }
                      setData(onchangeVal);
  
        })
      } 

    
  
      const columns = [
            
        { field: "itemName", headerName: "Item Name", width: 220 
       
      },
        
        { field: "less30", headerName: "0 to 30 Days", width: 220 },
        { field: "less60", headerName: "31 to 60 Days", width: 220 },
        { field: "less90", headerName: "61 to 60 Days", width: 220 },
        { field: "above90", headerName: "Above 90 Days", width: 220 },
      
       
      ];
  
      const rows=data.map((row)=>({
        id : row._id,
        itemName:row.itemName,
        less30:row.less30,
        less60:row.less60,
        less90:row.less90,
        above90:row.above90
  
      }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Inventory Ageing Summary Report</h1>
       
      </div>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={8}
          rowsPerPageOptions={[8]}
        />
        
      </div>
    );
}

export default InventoryAgingSummary