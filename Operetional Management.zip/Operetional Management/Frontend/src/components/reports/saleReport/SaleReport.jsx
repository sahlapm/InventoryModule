import React from 'react'
import { DataGrid } from "@material-ui/data-grid";
import { useState,useEffect } from "react";
import axios from 'axios';

const SalesReport = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
   
    
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])
    
  const FillData=()=>
  {
    axios.get(url+'/invoice/productsaleReport')
    .then((getData)=>{
      setData(getData.data);    
      
    })
  }

    const columns = [
        
      { field: "Name", headerName: "Name", width: 180 
      ,
      renderCell: (params) => {
        return (
          <div className="productListItem">
            <img className="productListImg" src={url+"/item/ProductImage/"+params.row.file} alt="" />
            {params.row.Name}
          </div>
          
        );
      },
    },
      {
        field: "SKU",
        headerName: "SKU",
        width: 170
      },
      { field: "QtySold", headerName: "QtySold", width: 140 },
      {
        field: "SalePrice",
        headerName: "SalePrice",
        width: 160,
      },
     
    ];
  
   const  rows=data.map((row)=>({
      id : row._id,
      Name:row.Name,
      SKU:row.SKU,
        Price: row.Price,
        QtySold:row.QtySold,
        SalePrice:row.SalePrice,
        file:row.file

    }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Product Sales Report</h1>
       
      </div>
        <DataGrid 
         autoHeight={true}
          rows={rows}
          columns={columns}
          pageSize={8}
          rowsPerPageOptions={[8]}
         
          
         
        />
        
      </div>
    );
}

export default SalesReport