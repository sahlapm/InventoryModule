import React from 'react'
import { DataGrid } from "@material-ui/data-grid";
import { useState,useEffect } from "react";
import axios from 'axios';

const InventorySummary = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])
  const FillData=()=>
  {
    axios.get(url+'/item/inventorySummaryReport')
    .then((getData)=>{
      setData(getData.data);    
    })
  }
    const columns = [
        
      { field: "itemName", headerName: "Item Name", width: 150 
     
    },
      {
        field: "sku",
        headerName: "SKU",
        width: 150
      },
      { field: "reorderPoint", headerName: "Reorder Point", width: 150},
      { field: "quantityOrdered", headerName: "Quantity Ordered", width: 150 
     
    },
      {
        field: "quantityIn",
        headerName: "Quantity In",
        width: 150
      },
      { field: "quantityOut", headerName: "Quantity Out", width: 150 },
      { field: "stockOnHand", headerName: "Stock In Hand", width: 150},
      { field: "committedStock", headerName: "Committed Stock", width: 150 },
      { field: "availableforSale", headerName: "Available For Sale", width: 200},
      
     
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      itemName:row.itemName,
      sku:row.sku,
        reorderPoint: row.reorderPoint,
        quantityOrdered : row.quantityOrdered,
        quantityIn:row.quantityIn,
        quantityOut:row.quantityOut,
        stockOnHand: row.stockOnHand,
          committedStock:row.committedStock,
          availableforSale: row.availableforSale

    }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Inventory Summary Report</h1>
       
      </div>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={8}
          rowsPerPageOptions={[8]}

        />
        
      </div>
    );
}

export default InventorySummary