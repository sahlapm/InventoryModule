
import { Button, Segment, Form,Header, StatisticGroup } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 
import "./packages.css";
import _ from 'lodash';
const PackageView = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
 
  const [data,setData]=useState([]);
  const [details,setDetails]=useState([{itemName:'',totalQuantity:0,packedQuantity:0,itemId:'',salesOrderId:'',salesDetailsId:'',packageId:''}]);
  const [sales, setSales] = useState([]);
  const [order,setOrder]=useState({});
  const [customer, setCustomer] = useState([]);
  const [orderDetails,setOrderDetails]=useState([]);
  const [packages,setPackages]=useState({salesOrderId:'',customerId:'',customerName:'', packageSlip:'',
  salesOrderNumber:'', internalNote:'', date:'', status:'',totalPackedQuantity:0}); 
  const [visible, setVisible] = useState(true);
  const [status,setStatus]=useState({});   

  let params=useParams();   
  let Id=params.id;
var total=0;
let itemCount=0;


useEffect(() => {  

    axios.get(url+'/package/readone/'+Id)
    .then((getData) => {
        console.log(getData,"one");
       setPackages(getData.data);
       var salesOrderId=getData.data.salesOrderId;
       axios.get(url+'/salesorder/readone/'+salesOrderId)
       .then((getData) => {
          setOrder(getData.data);
          axios.get(url+'/package/readDetails/'+Id)
         .then((getData)=>{
           setData(getData.data); 
       })
    })  })
},[])


const sendDataToAPI = async(event)=>{
  
  const OrderStatus=
  {
    "_id":Id,
      "status":status
  }
        const response= await  axios.put(url+`/package/updateStatus/`+Id,OrderStatus)
        if(response.data.success)
        {
          if(status ==="Shipped")
        {
        const shippedresponse=await axios.put(url+`/salesorder/updateShipmentStatus/`+packages.salesOrderId)
        if(shippedresponse.data.success)
        {  
          alert("Status updated successfully");    
        }
      }
        }
        else
        {
          alert("Status updation failed");
        }
  }
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Package</h1>
        <Link to="/packages">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="packageInfo">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue">                    
  
  <label>{packages.customerName}</label>
                  </span>
               </div> </Form.Field>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Sales Order</label>
                  <span className="salesTotalsValue"> 
            
<label>{packages.salesOrderNumber}</label>
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Package slip</label>
                  <span className="salesTotalsValue"> 
                  <label>{packages.packageSlip}</label>
                </span></div>
                
                </Form.Field>
                               <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{packages.date}</label>
               </span> </div></Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Internal Note</label>
                  <span className="salesTotalsValue"> 
                  <label>{packages.internalNote}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                   <label>{packages.status}</label>
                 </span>
               </div> </Form.Field>    
               </div>
          <div className="salesRight">
          <Header as='h3'> Sales order Details</Header>
          <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.salesOrderNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.date}</label>
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected shipment Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.expectedShipmentDate}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Method</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.deliveryMethod}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.description}</label>
              </span></div> 
               </Form.Field>

            </div></div>
            <div className='itemContainer'>
            <div className="itemRow">
                  <label>Item</label><label>Ordered</label><label>Packed</label> <label>Quantity To Pack</label>
                   </div></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label name="itemName" >{val.itemName}</label>
                  <label name="totalQuantity" >{val.quantity}</label>
                  <label name="oldpackedQuantity">0</label> 
                  <div> 
                  <span className='productInfoValue'> 
                  <label name="totalQuantity" >{val.packedQuantity}</label>
            </span>
                     </div>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>Total Quantity Packed</label></span> 
               <span className="salesTotalsValue"> 
               <label>{packages.totalPackedQuantity}</label>
                 </span>  </div>   </Form.Field>            
                
                 </div>  
                   </div>    
                   <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option>Shipped</option>
      <option>Not Shipped</option>
      
    </select>
                  </span>
                  
                   </div>    </Form.Field>
              
                   <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/packages' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>  
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default PackageView