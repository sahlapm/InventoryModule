import React from 'react'

import { DataGrid } from "@material-ui/data-grid";
import "./packageList.css";
import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';


const PackageList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    const [details, setDetails] = useState([]);
    const [searchData, setSearchData] = useState([]);
    const [startDate,setStartDate]= useState(new Date());
  const [endDate,setEndDate]= useState(new Date());
  const [searchTerm, setSearchTerm] = useState("");
    useEffect(() => {  
      sessionStorage.setItem("salesOrderId", "0");
             FillData();
             FillDetails();
      },[])     
    
      const makeStyle = (status) => {
        if ( status === 'Shipped' ) {
            return {
                
                color: 'green',
      
            }
        }
        else if (status === 'Not Shipped') {
            return {
             
                color: 'red',
            }
        }
        else {
            return {
               
                color: 'white',
      
            }
        }
      }
      const FillData=()=>
  {
   console.log("start");
    axios.get(url+'/package/read')
    .then((getData)=>{
      setData(getData.data);    
      setSearchData(getData.data)
    })
  }

   const FillDetails=()=>
  {
  
    axios.get(url+'/salesorder/readAllDetails')
    .then((getData)=>{
      setDetails(getData.data);    
     
    })
  }
  const handleSelect = (dt) =>{
    let filtered = searchData.filter((data)=>{
      let date = new Date(data["date"]);
      return(date>= dt.selection.startDate &&
        date<= dt.selection.endDate);
    })
    setStartDate(dt.selection.startDate);
    setEndDate(dt.selection.endDate);
    setData(filtered);
  };

  const handleItemSearch = (e) =>{
    details.filter((val) => {
        // console.log(searchTerm)
        // if (searchTerm == "") {
        //     return val;
        // } else 
let searchTerm=e.target.value;
        if (searchTerm !== '') {
            if (val.itemName.toLowerCase().includes(searchTerm.toLowerCase())      
               
            ) {
              console.log(val,"val");
              const res = searchData.filter(f => val.some(item => item.salesOrderId === f._id));
              console.log(res);
              }
        }
    })
  }
  const selectionRange = {
    startDate: startDate,
    endDate: endDate,
    key: 'selection',
  }




    const columns = [
      
      {
        field: "customerName",
        headerName: "Customer Name",
        width: 150
      },
      {
        field: "salesOrderNumber",
        headerName: "SO Number",
        width: 120
      },
      { field: "packageSlip", headerName: "Package Slip", width: 120 },
      {
        field: "date",
        headerName: "Date",
        width: 120,
      },
     
     
      {
        field: "status",
        headerName: "Status",
        width: 120,
        renderCell: (params) => {
          return (
            <>
              <label className='status' style={makeStyle(params.row.status)}>{params.row.status}</label>
              
            </>
          );
        },
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <Link to={"/viewpackages/" + params.row.id}>
              <button className="productListEdit">View</button>
            </Link>
              
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      customerName : row.customerName
      ,
      salesOrderNumber: row.salesOrderNumber,
      reference:row.reference,
      packageSlip:row.packageSlip,
      date: row.date,
      status:row.status,
     packageSlip : row.packageSlip



      
    }))
    
    
    return (
      
      <div className="product">
      <div className="productTitleContainer">


        <h1 className="productTitle">Package List</h1>
        <Link to="/NewPackages">
          <button className="productAddButton">Create New</button>
        </Link>
</div>

        <div className="productTop">
          <div className="productTopLeft">
          <h3 className="productTitle">Select Date Range</h3>
          <DateRangePicker
        ranges={[selectionRange]}
        onChange={handleSelect}
      />
          </div>
          <div className="productTopRight">
                <DataGrid autoHeight
          rows={rows}
          columns={columns}
          pageSize={8}
          
         
        />
                       
                    
          </div>
      </div>
      

       
    
      
       
        
      </div>
    );
}

export default PackageList