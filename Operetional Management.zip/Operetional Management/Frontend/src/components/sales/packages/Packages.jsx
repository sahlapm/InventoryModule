
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
import "./packages.css";
import _ from 'lodash';
const Packages = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
 
  const [data,setData]=useState([]);
  const [details,setDetails]=useState([{itemName:'',totalQuantity:0,packedQuantity:0,oldpackedQuantity:0,itemId:'',salesOrderId:'',salesDetailsId:'',packageId:''}]);
  const [sales, setSales] = useState([]);
  const [order,setOrder]=useState({});
  const [customer, setCustomer] = useState([]);
  const [orderDetails,setOrderDetails]=useState([]);
  const [packages,setPackages]=useState({salesOrderId:'',customerId:'',customerName:'', packageSlip:'',
  salesOrderNumber:'', internalNote:'', date:'', status:'',totalPackedQuantity:0}); 
  const [visible, setVisible] = useState(true);
 
useEffect(() => {  

  if(sessionStorage.getItem("salesOrderId")!=="0")
  {
  var salesOrderId=sessionStorage.getItem("salesOrderId");
 
  axios.get(url+'/salesorder/readone/'+salesOrderId)
        .then((getData) => {
           setOrder(getData.data);
          
           let soNumber = getData.data.salesOrderNumber;
           
           setPackages({...packages,["salesOrderId"]:salesOrderId,["salesOrderNumber"]:soNumber,["customerId"]:getData.data.customerId,["customerName"]:getData.data.customerName})
          
           axios.get(url+'/salesorder/readDetails/'+salesOrderId)
         .then((getData)=>{
           setData(getData.data);         
          
           axios.get(url+'/package/readDetailsbysalesorder/'+salesOrderId)
           .then((getDetails)=>{
            setOrderDetails(getDetails.data);         
            if(getDetails.data.length>0)
            {
              alert("yes");
            }
             
           })
         })
               
        })  
         setVisible(false);

  }
  else
  {
    setVisible(true);
 
  }
 
  FillCustomer();
  
},[])
const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
    

  })
}



const sendDataToAPI = async(event)=>{
  
  const {salesOrderId, customerId, date,packageSlip,status}=packages

 if(customerId && salesOrderId &&  date && packageSlip && status)
 {     
  console.log(status,"status")
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else
  {
   
    const response= await  axios.post(url+`/package/create`,packages)
    if(response.data.success)
    {
        for( let i=0;i<data.length;i++)
        {
          details[i]["packageId"]=response.data.data._id    
          details[i]["salesDetailsId"]  =data[i]["_id"] 
          details[i]["totalQuantity"]  =data[i]["quantity"] 
        }
        let new_list = details.map(function(obj) {
          return {
            packageId: obj.packageId,
            salesOrderId: obj.salesOrderId,
            salesDetailsId: obj.salesDetailsId,
            totalQuantity: obj.totalQuantity,
            itemId: obj.itemId,
            itemName: obj.itemName,
            packedQuantity: obj.packedQuantity,
            oldPackedQuantity: obj.oldPackedQuantity
          }})
        const Detailsresponse= await  axios.post(url+`/package/createDetails/`,new_list)
       console.log(new_list,"nl");
       
        let OrderStatus={};
        var Invoiceresponse="";
        let successcount=0;
        for (let i= 0; i<new_list.length; i++) {
          OrderStatus={};
          OrderStatus=
          {         
              "packedQuantity":parseInt(new_list[i].packedQuantity)+parseInt(new_list[i].oldPackedQuantity)
          }
          Invoiceresponse=await axios.put(url+`/salesorder/updatePackage/`+new_list[i].salesDetailsId,OrderStatus)
          if(Invoiceresponse.data.success )
          {
            successcount++;
          }
      }
     let success=false;
    
     if(successcount===new_list.length)
     {
      const packageresponse=await axios.put(url+`/salesorder/updatePackageStatus/`+salesOrderId)
      const shippedresponse=''
      if(packageresponse.data.success)
      {
        
        if(status ==="Shipped")
        {
         
        const shippedresponse=await axios.put(url+`/salesorder/updateShipmentStatus/`+salesOrderId)
        if(shippedresponse.data.success)
        {  
          success=true;
        }
      }
        else
        {
          success=true;
        }
      }
     
      }
       
       
        if(Detailsresponse.data.success && success)
        {
          alert("Package created successfully"); 
          navigate('/packages');
        }
        else
        {
          alert("Package creation failed");
        }
      }
    else
    {
      alert("Package creation failed");
    }
  }
}
 else
{
   alert("Invalid Input");  
}
}
const handleChangeItems=(e,i)=>{

  const {name,value}=e.target
  const onchangeVal = [...data]
  onchangeVal[i][name]=value
  setDetails(onchangeVal);
  CalculateTotal();
  
  console.log(packages);
 

   
}
const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<details.length;i++)
  {
     sum=sum+parseInt(details[i]["packedQuantity"]);
  }
  setPackages({...packages,["totalPackedQuantity"]:sum,});

}
const handleChange=e=>{
      
    const {name,value}=e.target;
   
    if(e.target.name==="customerId")
    {      
      let item_id=e.target.value;
      if(item_id!=='')
      {    
        axios.get(url+'/salesorder/salesorderByCustomer/'+item_id)
        .then((getData) => {
          setSales(getData.data);
        

         setPackages({...packages,[name]:value});
        })  
      }
    }
   else  if(e.target.name==="salesOrderId")
    {
      let item_id=e.target.value;     
      if(item_id!=='')
      {   
        axios.get(url+'/salesorder/readone/'+item_id)
        .then((getData) => {
           setOrder(getData.data);
          
           let soNumber = getData.data.salesOrderNumber;
           
           setPackages({...packages,[name]:value,["salesOrderNumber"]:soNumber,["customerName"]:getData.data.customerName})
        
           axios.get(url+'/salesorder/readDetails/'+item_id)
         .then((getData)=>{
                

           const onchangeVal = getData.data
            for( let i=0;i< getData.data.length;i++)
            {
              
              onchangeVal[i]["oldPackedQuantity"]=onchangeVal[i]["packedQuantity"];
                        }
          
            console.log(onchangeVal,"onchangeVal")
           setData(onchangeVal)

          
          /* axios.get(url+'/package/readDetailsbysalesorder/'+item_id)
           .then((getDetails)=>{
            setOrderDetails(getDetails.data);         
            if(getDetails.data.length>0)
            {
              alert("yes");
            }
             
           })*/
         })
         /*  onchangeVal[i]["rate"]=getData.data.sellingPrice;
          onchangeVal[i]["itemName"]=getData.data.itemName;
          onchangeVal[i]["brand"]=getData.data.brand;
          onchangeVal[i]["itemId"]=e.target.value;
          setData(onchangeVal);  */        
        })  
      }
    }
 else
 {
  setPackages({...packages,[name]:value});
 }
  }

  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Package</h1>
        <Link to="/packages">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="packageInfo">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  {visible &&       <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
  }
  { !visible && <label>{packages.customerName}</label>}
                  </span>
               </div> </Form.Field>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Sales Order</label>
                  <span className="salesTotalsValue"> 
            {visible &&      <select id="Select" name='salesOrderId'  onChange={handleChange} >
                  <option>--Select Sales Order--</option>
                  {sales.map((so,index)=>{return(<option key={index} value={so._id}>{so.salesOrderNumber}</option> )})} </select>
  }
 { !visible && <label>{packages.salesOrderNumber}</label>}
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Package slip</label>
                  <span className="salesTotalsValue"> 
                  <input required name='packageSlip' value={packages.packageSlip} onChange={handleChange}  placeholder='Package slip'  />
                </span></div>
                
                </Form.Field>
                               <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={packages.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Internal Note</label>
                  <span className="salesTotalsValue"> 
                  <input required name='internalNote' value={packages.internalNote} onChange={handleChange}  placeholder='Internal Note'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={packages.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option>Not Shipped</option>
      <option>Shipped</option>
    
    </select></span>
               </div> </Form.Field>    
               </div>
          <div className="salesRight">
          <Header as='h3'> Sales order Details</Header>
          <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.salesOrderNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.date}</label>
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected shipment Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.expectedShipmentDate}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Method</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.deliveryMethod}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.description}</label>
              </span></div> 
               </Form.Field>

            </div></div>
            <div className='itemContainer'>
            <div className="itemRow">
                  <label>Item</label><label>Ordered</label><label>Packed</label> <label>Quantity To Pack</label>
                   </div></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label name="itemName" key={i} onChange={(e)=>handleChangeItems(e,i)}>{val.itemName}</label>
                  <label name="totalQuantity" onChange={(e)=>handleChangeItems(e,i)}>{val.quantity}</label>
                  <label name="oldpackedQuantity" onChange={(e)=>handleChangeItems(e,i)}>{val.oldPackedQuantity}</label> 
                  <div> 
                  <span className='productInfoValue'> 
                  <select name="packedQuantity" className="select-board-size" onChange={(e)=>handleChangeItems(e,i)}>
                { _.range(0, (val.quantity-val.oldPackedQuantity)+ 1).map(value => <option key={value} value={value}>{value}</option>) }
            </select>
            </span>
                     </div>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>Total Quantity Packed</label></span> 
               <span className="salesTotalsValue"> 
               <label>{packages.totalPackedQuantity}</label>
                 </span>  </div>   </Form.Field>            
                
                 </div>  
                   </div>    
                    
              
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/packages' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>  
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default Packages