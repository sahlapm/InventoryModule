
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 
//import "./packages.css";

const SalesReturnView = () => {
  const url="http://localhost:5000/api";

 
  const [data,setData]=useState([]);
  const [order,setOrder]=useState({});
  const [returns,setReturns]=useState({salesOrderId:'',customerId:'',customerName:'', returnNumber:'',
  salesOrderNumber:'', reason:'', date:'', status:'',totalReturnedQuantity:0}); 
  let params=useParams();   
  let Id=params.id;

useEffect(() => {  

    axios.get(url+'/salesreturn/readone/'+Id)
    .then((getData) => {
     
       setReturns(getData.data);
       var salesOrderId=getData.data.salesOrderId;
       axios.get(url+'/salesorder/readone/'+salesOrderId)
       .then((getData) => {
          setOrder(getData.data);
          axios.get(url+'/salesreturn/readDetails/'+Id)
         .then((getData)=>{
           setData(getData.data); 
           console.log(getData.data); 
       })
    })  })
},[])

  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Sales Return</h1>
        <Link to="/salesreturn">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="packageInfo">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue">                    
  
  <label>{returns.customerName}</label>
                  </span>
               </div> </Form.Field>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Sales Order</label>
                  <span className="salesTotalsValue"> 
            
<label>{returns.salesOrderNumber}</label>
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Return Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{returns.returnNumber}</label>
                </span></div>
                
                </Form.Field>
                               <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{returns.date}</label>
               </span> </div></Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reason</label>
                  <span className="salesTotalsValue"> 
                  <label>{returns.reason}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                   <label>{returns.status}</label>
                 </span>
               </div> </Form.Field>    
               </div>
          <div className="salesRight">
          <Header as='h3'> Sales order Details</Header>
          <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.salesOrderNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.date}</label>
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected shipment Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.expectedShipmentDate}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Method</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.deliveryMethod}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.description}</label>
              </span></div> 
               </Form.Field>

            </div></div>
            <div className='itemContainer'>
            <div className="itemRow">
                  <label>Item</label><label>Ordered</label><label>Packed</label> <label>Quantity To Pack</label>
                   </div></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label name="itemName" >{val.itemName}</label>
                  <label name="totalQuantity" >{val.totalQuantity}</label>
                  <label name="oldreturnedQuantity">0</label> 
                  <div> 
                  <span className='productInfoValue'> 
                  <label name="totalQuantity" >{val.returnedQuantity}</label>
            </span>
                     </div>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>Total Quantity Retrurned</label></span> 
               <span className="salesTotalsValue"> 
               <label>{returns.totalReturnedQuantity}</label>
                 </span>  </div>   </Form.Field>            
                
                 </div>  
                   </div>    
                    
              
                             
                <Button size='mini' color='grey'>
                  <Link to='/salesreturn' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>  
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default SalesReturnView