
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
//import "./packages.css";
import _ from 'lodash';
const SalesReturn = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
 
  const [data,setData]=useState([]);
  const [details,setDetails]=useState([{itemName:'',totalQuantity:0,packedQuantity:0,itemId:'',salesOrderId:'',salesDetailsId:'',returnId:'',oldReturnedQuantity:0}]);
  const [sales, setSales] = useState([]);
  const [order,setOrder]=useState({});
  const [orderDetails,setOrderDetails]=useState([]);
  const [customer, setCustomer] = useState([]);
  const [returns,setReturns]=useState({salesOrderId:'',customerId:'',customerName:'', returnNumber:'',
  salesOrderNumber:'', reason:'', date:'', status:'',totalReturnedQuantity:0}); 
  const [visible, setVisible] = useState(true);
 
useEffect(() => {  

  if(sessionStorage.getItem("salesOrderId")!=="0")
  {
  var salesOrderId=sessionStorage.getItem("salesOrderId");
 
  axios.get(url+'/salesorder/readone/'+salesOrderId)
        .then((getData) => {
           setOrder(getData.data);
          
           let soNumber = getData.data.salesOrderNumber;
           
           setReturns({...returns,["salesOrderId"]:salesOrderId,["salesOrderNumber"]:soNumber,["customerId"]:getData.data.customerId,["customerName"]:getData.data.customerName})
          
           axios.get(url+'/salesorder/readDetails/'+salesOrderId)
         .then((getData)=>{
           setData(getData.data);         
          
           axios.get(url+'/package/readDetailsbysalesorder/'+salesOrderId)
           .then((getDetails)=>{
            setOrderDetails(getDetails.data);         
            if(getDetails.data.length>0)
            {
              alert("yes");
            }
             
           })
         })
               
        })  
         setVisible(false);
  }
  else
  {
    setVisible(true);
  }
  FillCustomer();
  
},[])
const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
  })
}



const sendDataToAPI = async(event)=>{
  console.log(returns);
  const {salesOrderId, customerId, date,returnNumber}=returns

 if(customerId && salesOrderId &&  date && returnNumber)
 {     
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else
  {
    const response= await  axios.post(url+`/salesReturn/create`,returns)
    if(response.data.success)
    {
        for( let i=0;i<data.length;i++)
        {
          details[i]["salesReturnId"]=response.data.data._id    
          details[i]["salesDetailsId"]  =data[i]["_id"] 
          details[i]["totalQuantity"]  =data[i]["quantity"] 
        }
        let new_list = details.map(function(obj) {
          return {
            salesReturnId: obj.salesReturnId,
            salesOrderId: obj.salesOrderId,
            salesDetailsId: obj.salesDetailsId,
            totalQuantity: obj.totalQuantity,
            itemId: obj.itemId,
            itemName: obj.itemName,
            returnedQuantity: obj.returnedQuantity,
            oldReturnedQuantity: obj.oldReturnedQuantity
          }})
        const Detailsresponse= await  axios.post(url+`/salesReturn/createDetails/`,new_list)
       
        console.log(new_list,"nl");
       
        let OrderStatus={};
        var Invoiceresponse="";
        let successcount=0;
        for (let i= 0; i<new_list.length; i++) {
          OrderStatus={};
          OrderStatus=
          {         
              "returnedQuantity":parseInt(new_list[i].returnedQuantity)+parseInt(new_list[i].oldReturnedQuantity)
          }
          Invoiceresponse=await axios.put(url+`/salesorder/updateReturn/`+new_list[i].salesDetailsId,OrderStatus)
          if(Invoiceresponse.data.success )
          {
            successcount++;
          }
      }
     let success=false;
    
     if(successcount===new_list.length)
     {
      success=true;
     }
       
        if(Detailsresponse.data.success)
        {
          alert("Sales Return created successfully"); 
          navigate('/salesreturn');
        }
        else
        {
          alert("Sales Return creation failed");
        }
      }
    else
    {
      alert("Sales Return creation failed");
    }
  }
}
 else
{
   alert("Invalid Input");  
}
}
const handleChangeItems=(e,i)=>{

  const {name,value}=e.target
  const onchangeVal = [...data]
  onchangeVal[i][name]=value
  setDetails(onchangeVal);
  CalculateTotal();
  console.log(returns);
}
const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<details.length;i++)
  {
     sum=sum+parseInt(details[i]["returnedQuantity"]);
  }
  setReturns({...returns,["totalReturnedQuantity"]:sum,});

}
const handleChange=e=>{
      
    const {name,value}=e.target;
   
    if(e.target.name==="customerId")
    {      
      let item_id=e.target.value;
      if(item_id!=='')
      {    
        axios.get(url+'/salesorder/salesorderByCustomer/'+item_id)
        .then((getData) => {
          setSales(getData.data);
        

          setReturns({...returns,[name]:value});
        })  
      }
    }
   else  if(e.target.name==="salesOrderId")
    {
      let item_id=e.target.value;     
      if(item_id!=='')
      {   
        axios.get(url+'/salesorder/readone/'+item_id)
        .then((getData) => {
           setOrder(getData.data);
          
           let soNumber = getData.data.salesOrderNumber;
           
           setReturns({...returns,[name]:value,["salesOrderNumber"]:soNumber,["customerName"]:getData.data.customerName})
        
           axios.get(url+'/salesorder/readDetails/'+item_id)
         .then((getData)=>{
                    
           const onchangeVal = getData.data
           for( let i=0;i< getData.data.length;i++)
           {
             
             onchangeVal[i]["oldReturnedQuantity"]=onchangeVal[i]["returnedQuantity"];
                       }
         
           console.log(onchangeVal,"onchangeVal")
          setData(onchangeVal)
         
         })
         /*  onchangeVal[i]["rate"]=getData.data.sellingPrice;
          onchangeVal[i]["itemName"]=getData.data.itemName;
          onchangeVal[i]["brand"]=getData.data.brand;
          onchangeVal[i]["itemId"]=e.target.value;
          setData(onchangeVal);  */        
        })  
      }
    }
 else
 {
    setReturns({...returns,[name]:value});
 }
  }

  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Sales Return</h1>
        <Link to="/salesreturn">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="packageInfo">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  {visible &&       <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
  }
  { !visible && <label>{returns.customerName}</label>}
                  </span>
               </div> </Form.Field>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Sales Order</label>
                  <span className="salesTotalsValue"> 
            {visible &&      <select id="Select" name='salesOrderId'  onChange={handleChange} >
                  <option>--Select Sales Order--</option>
                  {sales.map((so,index)=>{return(<option key={index} value={so._id}>{so.salesOrderNumber}</option> )})} </select>
  }
 { !visible && <label>{returns.salesOrderNumber}</label>}
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Return Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='returnNumber' value={returns.returnNumber} onChange={handleChange}  placeholder='Return Number'  />
                </span></div>
                
                </Form.Field>
                               <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={returns.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reason</label>
                  <span className="salesTotalsValue"> 
                  <input required name='reason' value={returns.reason} onChange={handleChange}  placeholder='Reason'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Send to inventory</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={returns.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
                  <option>Pending</option>
    <option>Approved</option>
      <option>Rejected</option>
    
    </select></span>
               </div> </Form.Field>    
               </div>
          <div className="salesRight">
          <Header as='h3'> Sales order Details</Header>
          <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.salesOrderNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.date}</label>
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected shipment Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.expectedShipmentDate}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Method</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.deliveryMethod}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.description}</label>
              </span></div> 
               </Form.Field>

            </div></div>
            <div className='itemContainer'>
            <div className="itemRow">
                  <label>Item</label><label>Ordered</label><label>Returned</label> <label>Returned Quantity</label>
                   </div></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label name="itemName" key={i} onChange={(e)=>handleChangeItems(e,i)}>{val.itemName}</label>
                  <label name="totalQuantity" onChange={(e)=>handleChangeItems(e,i)}>{val.quantity}</label>
                  <label name="oldReturnedQuantity" onChange={(e)=>handleChangeItems(e,i)}>{val.oldReturnedQuantity}</label> 
                  <div> 
                  <span className='productInfoValue'> 
                  <select name="returnedQuantity" className="select-board-size" onChange={(e)=>handleChangeItems(e,i)}>
                { _.range(0, (val.quantity-val.oldReturnedQuantity)+ 1).map(value => <option key={value} value={value}>{value}</option>) }
            </select>
            </span>
                     </div>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>Total Quantity Returned</label></span> 
               <span className="salesTotalsValue"> 
               <label>{returns.totalReturnedQuantity}</label>
                 </span>  </div>   </Form.Field>            
                
                 </div>  
                   </div>    
                    
              
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/salesreturn' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>  
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default SalesReturn