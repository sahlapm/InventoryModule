import React from 'react'
//import "./ItemList.css";
import { DataGrid } from "@material-ui/data-grid";
import "./salesOrderList.css";
import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';
import {Form} from 'semantic-ui-react';

const SalesOrderList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    const [details, setDetails] = useState([]);
    const [searchData, setSearchData] = useState([]);
    const [startDate,setStartDate]= useState(new Date());
  const [endDate,setEndDate]= useState(new Date());
  
  const [item, setItem] = useState([]);

    useEffect(() => {  
      FillItem();       
      FillData();
            
      },[])     
          const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
  })
}
      const makeStyle = (status) => {
        if ( status === 'Closed' || status === 'Draft'|| status === 'Dispatched'||status === 'Delivered') {
            return {
                
                color: 'green',
      
            }
        }
        else if (status === 'Open'|| status === 'Void' ||status === 'OnHold') {
            return {
             
                color: 'red',
            }
        }
        else {
            return {
                
                color: 'white',
      
            }
        }
      }
      const FillData=()=>
  {
   console.log("start");
    axios.get(url+'/salesorder/read')
    .then((getData)=>{
      setData(getData.data);    
      setSearchData(getData.data)
    })
  }

  
  const handleSelect = (dt) =>{
    let filtered = searchData.filter((data)=>{
      let date = new Date(data["date"]);
      return(date>= dt.selection.startDate &&
        date<= dt.selection.endDate);
    })
    setStartDate(dt.selection.startDate);
    setEndDate(dt.selection.endDate);
    setData(filtered);
  };


  const handleSearch = (e) =>{

    if(e.target.name ==='itemId')
        {
          
          const itemId=e.target.value;
    const filteredData=[]
          axios.get(url+'/salesorder/viewAllDetailsByitem/'+itemId)
          .then((getData) => {
            //setDetails(getData.data);
            searchData.map((sales,index)=>{
                getData.data.filter((item,no)=>{
                    if(sales._id==item.salesOrderId)
                    {
                        filteredData.push(sales)
                    }
                })
            })
           setData(filteredData);
          })
          }
          
  }
 
  const selectionRange = {
    startDate: startDate,
    endDate: endDate,
    key: 'selection',
  }




    const columns = [
      
      { field: "customerName", headerName: "Customer Name", width: 200 
      ,
        },
      {
        field: "salesOrderNumber",
        headerName: "SO Number",
        width: 150
      },
      { field: "reference", headerName: "Reference", width: 150 },
      {
        field: "date",
        headerName: "Date",
        width: 200,
      },
      {
        field: "expectedShipmentDate",
        headerName: "Expected Shipment Date",
        width: 160,
      },
      {
        field: "deliveryMethod",
        headerName: "Delivery Method",
        width: 160,
      },
      {
        field: "status",
        headerName: "Status",
        width: 200,
        renderCell: (params) => {
          return (
            <>
              <label className='status' style={makeStyle(params.row.status)}>{params.row.status}</label>
              
            </>
          );
        },
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <Link to={"/viewsalesorder/" + params.row.id}>
              <button className="productListEdit">View</button>
            </Link>
              
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      customerName:row.customerName,
      salesOrderNumber: row.salesOrderNumber,
      reference:row.reference,
      date: row.date,
      expectedShipmentDate:row.expectedShipmentDate,
      deliveryMethod:row.deliveryMethod,
      status:row.status
     

      
    }))
    
    
    return (
      
      <div className="product">
      <div className="productTitleContainer">


        <h1 className="productTitle">SalesOrder List</h1>
        <Link to="/newSalesOrder">
          <button className="productAddButton">Create New</button>
        </Link>
</div>

        <div className="productTop">
          <div className="productTopLeft">
          <h3 className="productTitle">Select Date Range</h3>
          <DateRangePicker
        ranges={[selectionRange]}
        onChange={handleSelect}
      />
          </div>
          <div className="productTopRight">
          <Form>
          <Form.Field>
              <div className="salesInfoTotals">
                  <label>Item Name</label>
                  <span className="salesTotalsValue"> 
                  <select  id="Select" name='itemId'   onChange={handleSearch} placeholder='Item' >
               <option>--Select Item--</option>
                  {item.map((ds,index)=>{return(<option key={index} value={ds._id}> {ds.itemName}</option> )})} </select>
                  
                  </span>
               </div> </Form.Field></Form>

          
                       
                    
          </div>
      </div>
      

       <DataGrid autoHeight
          rows={rows}
          columns={columns}
          pageSize={8}
          
         
        />
    
      
       
        
      </div>
    );
}

export default SalesOrderList