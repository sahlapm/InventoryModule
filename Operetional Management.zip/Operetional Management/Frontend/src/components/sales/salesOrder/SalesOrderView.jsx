
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 
import "./salesOrder.css";

const SalesOrderView = () => {
  const url="http://localhost:5000/api";

  const [data,setData]=useState([]);

  const [order,setOrder]=useState({});
  const [status,setStatus]=useState({});    
  let params=useParams();   
  let Id=params.id;
  sessionStorage.setItem("salesOrderId", Id);



useEffect(() => {  
 FillOrder();
 FillDetails();
},[])


const FillOrder=()=>
{
         
  axios.get(url+'/salesorder/readone/'+Id)
  .then((getData)=>{
    setOrder(getData.data);  
    sessionStorage.setItem("customerId", getData.data.customerId);
    
   
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/salesorder/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
  
  })
}



const sendDataToAPI = async(event)=>{

const OrderStatus=
{
  "_id":Id,
    "status":status
}
      const response= await  axios.put(url+`/salesorder/updateStatus/`+Id,OrderStatus)
      if(response.data.success)
      {
        
        let success=false;
        if(status ==="Open" ||status ==="Closed")
       {
        let  Inventory={};
        let successcount=0;
        var Inventoryresponse="";
        
        for (let i= 0; i<data.length; i++) {
          axios.get(url+'/item/readoneitem/'+data[i].itemId)
          .then((getData) => {
             Inventory={};
          Inventory=
          {         
              "committedStock":parseInt(data[i].quantity) +parseInt(getData.data.committedStock)
          }
           console.log(Inventory,"Inventory")
          /**/Inventoryresponse= axios.put(url+`/item/updatecommittedStock/`+getData.data._id,Inventory)
          
          if(Inventoryresponse.data.success )
          {
            successcount++;
          }
         
        
          if(successcount===data.length)
          {
            success=true;
            }
    
          })
      
          }


      }
        alert("Status updated successfully");        
      }
      else
      {
        alert("Status updation failed");
      }
 

}


const makeStyle = (status) => {
  if (status === 'Shipped' ||status === 'Packed'|| status === 'Clossed' || status === 'Invoiced') {
      return {
          background: 'rgb(145 254 159 / 47%)',
          color: 'green',

      }
  }
  else if (status === 'Not Shipped' ||status === 'Not Packed'|| status === 'Open' || status === 'Not Invoiced') {
      return {
          background: '#ecb3b5',
          color: 'red',
      }
  }
  else {
      return {
          background: '#59bfff',
          color: 'white',

      }
  }
}


  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Sales order</h1>
        <Link to="/Newpackages">
          <button className="headerdButton">Package</button>
        </Link>
        <Link to="/NewInvoice">
          <button className="headerdButton">Convert To Invoice</button>
        </Link>
        <Link to="/Newsalesreturn">
          <button className="headerdButton">Sales Return</button>
        </Link>
        <Link to="/salesorder">
          <button className="headerdButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Order Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.salesOrderNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.date}</label>
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected shipment Date</label>
                <span className="salesTotalsValue"> 
                <label>{order.expectedShipmentDate}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Method</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.deliveryMethod}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.description}</label>
              </span></div> 
               </Form.Field>
               </div>
          <div className="salesRight">
          <Header as='h3'> Status</Header>
          <Form.Field>
                <div className="salesInfoTotals">
                  <label>Order</label>
                  <span className="salesStatusValue"> 
                  <label className='status' style={makeStyle(order.status)}>{order.status}</label>
                </span> </div>
                </Form.Field><Form.Field>
                <div className="salesInfoTotals">
                  <label>Invoice</label>
                  <span className="salesStatusValue"> 
                  <label className='status' style={makeStyle(order.isInvoiced ?'Invoiced':'Not Invoiced')}>{order.isInvoiced ?'Invoiced':'Not Invoiced'}</label>
                </span>
                
                 </div>
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Package</label>
                  <span className="salesStatusValue"> 
                  <label className='status' style={makeStyle(order.isPacked ?'Packed':'Not Packed')}>{order.isPacked ?'Packed':'Not Packed'}</label>
                </span> </div>
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Shipment</label>
                  <span className="salesStatusValue"> 
                  <label className='status' style={makeStyle(order.isShipped ?'Shipped':'Not Shipped')}>{order.isShipped ?'Shipped':'Not Shipped'}</label>
                </span> </div>
                </Form.Field>

            </div></div>
            <div className='itemContainer'>
            <Form.Field>
                <div className="itemRow">
                  <label>Item</label><label>Status</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                   </div>
                </Form.Field></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label>{val.itemName}</label>

                  <div className='statusBox'>
                    <label>{val.packedQuantity+" Packed"} </label>
                  <label>{val.invoicedQuantity+" Invoiced"}</label>
                  <label>{val.returnedQuantity+"  Returned"}</label>
                  </div>


                  <label>{val.quantity}</label><label>{val.rate}</label> <label>{val.amount}</label>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue"> 
               <label>{order.subTotal}</label>
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.discount}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                  <label>{order.total}</label>
                </span> </div>
                </Form.Field>  </div>  
                   </div>    
                   <div className='itemContainer'>   
                <Header as='h3'> Update Status</Header>
                 <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>
      <option>Dispatched</option>
      <option>Delivered</option>
      <option>Void</option>
      <option>On hold</option>
      <option>Closed</option>
    </select>
                  </span>
                  
                   </div>    </Form.Field>
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/learner' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default SalesOrderView