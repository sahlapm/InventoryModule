
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
import "./salesOrder.css";
import { DeleteOutline } from "@material-ui/icons";
const SalesOrder = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:'',brand:'',salesOrderId:'',committedStock:0,invewntoryId:'',packedQuantity:0,returnedQuantity:0,invoicedQuantity:0}]);
  
  const [item, setItem] = useState([]);
  const [customer, setCustomer] = useState([]);
  const [order,setOrder]=useState({
    customerName:'',
              customerId:'',
              salesOrderNumber:'',
              reference:'',
              date:'',
              expectedShipmentDate:'',
              deliveryMethod:'',
              description:'',
              
            subTotal:0,
            discount:0,
            total:0,
            status:'--Select Status--'
           
  });
var total=0;
  useEffect(() => {
    FillCustomer();
  FillItem(); 
},[])
const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
  })
}
const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
  })
}
const handleAddmoreClick=(i)=>{
  if(data[i].itemName && data[i].quantity && data[i].rate && data[i].amount)
  {
    if(data[i].itemId ==="--Select Item--")
    {
      alert("Select Item");
    }
    else
    {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(data[i].quantity))
    {
      alert('Quantity is invalid')
    }
    else if(!regex.test(data[i].rate))
    {
      alert('Rate is invalid')
    }
    else if(!regex.test(data[i].amount))
    {
      alert('Amount is invalid')
    }
    else
    {
    setData([...data,{itemName:"",quantity:"",rate:"",amount:""}])
    /*
    sbTotal= parseInt(order.subTotal) + parseInt(data[i].amount);
     order.subTotal=sbTotal;*/
    }
  }
  }
    else
    {
      alert("Invalid item details"); 
     }
}
const handleChangeItems=(e,i)=>{
    const {name,value}=e.target
    console.log(data);
    const onchangeVal = [...data]
      
      if(e.target.name==="quantity" || e.target.name==="rate")
      {
            onchangeVal[i][name]=value
            if(onchangeVal[i]["quantity"] && onchangeVal[i]["rate"])
            {
              total=parseInt(onchangeVal[i]["quantity"]) * parseInt(onchangeVal[i]["rate"]);
              onchangeVal[i]["amount"]=total;
            } 
            setData(onchangeVal)
            CalculateTotal()
      }
      else if(e.target.name==="itemId")
      {
        let item_id=e.target.value;
        if(item_id!=='')
        {
       
          axios.get(url+'/item/readone/'+item_id)
          .then((getData) => {
            console.log(getData.data);

            onchangeVal[i]["rate"]=getData.data.sellingPrice;
            onchangeVal[i]["itemName"]=getData.data.itemName;
            onchangeVal[i]["brand"]=getData.data.brand;
            onchangeVal[i]["itemId"]=e.target.value;
            axios.get(url+'/item/readoneitem/'+item_id)
            .then((getData) => {
              onchangeVal[i]["committedStock"]=getData.data.committedStock;
              onchangeVal[i]["inventoryId"]=getData.data._id;
            })
            setData(onchangeVal);          
          })  
        }
      }
     total=0;
}

const handleDelete=(i)=>{
  if(i===0)
  {
    setData([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:''}]);
  }
  else
  {
   
    const deleteVal = [...data]
    deleteVal.splice(i,1)
    setData(deleteVal)
    let sum=0;
 
  for(let i=0;i<deleteVal.length;i++)
  {
     sum=sum+parseInt(deleteVal[i]["amount"]);
  }
  setOrder({...order,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(order.discount))})
  }
  //CalculateTotal();
}
const sendDataToAPI = async(event)=>{
  const {customerId, salesOrderNumber, date,subTotal,discount,total,status}=order

 if(customerId && salesOrderNumber && date && subTotal && total && status)
 {     
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else if(status ==="--Select Status--")
  {
    alert("Select Status");
  }
  else
  {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(subTotal))
    {
      alert('Sub Total is invalid')
    }
    else if(!regex.test(discount))
    {
      alert('Discount is invalid')
    }
    if(!regex.test(total))
    {
      alert('Total is invalid')
    }
   else{
    
     console.log(order,"order");
    const response= await  axios.post(url+`/salesorder/create`,order)
    if(response.data.success)
    {
        const onchangeVal = [...data];
        for( let i=0;i<data.length;i++)
        {
          onchangeVal[i]["salesOrderId"]=response.data.data._id
          onchangeVal[i]["packedQuantity"]=0
          onchangeVal[i]["invoicedQuantity"]=0
          onchangeVal[i]["returnedQuantity"]=0
        }
        console.log(onchangeVal);
        const Detailsresponse= await  axios.post(url+`/salesorder/createDetails/`,onchangeVal)
        let success=false;
         if(status ==="Open" ||status ==="Closed")
  {
    
    let  Inventory={};
    let successcount=0;
    var Inventoryresponse="";
    console.log(onchangeVal,"onchangeVal");
    for (let i= 0; i<onchangeVal.length; i++) {
      Inventory={};
      Inventory=
      {         
          "committedStock":parseInt(onchangeVal[i].quantity) +parseInt(onchangeVal[i].committedStock)
      }
      Inventoryresponse=await axios.put(url+`/item/updatecommittedStock/`+onchangeVal[i].inventoryId,Inventory)
      if(Inventoryresponse.data.success )
      {
        successcount++;
      }
     
    
      if(successcount===onchangeVal.length)
      {
        success=true;
        }

  }
  }
        else
        {
          success=true;
        }
        if(Detailsresponse.data.success && success)
        {
          alert("Sales order created successfully");
          navigate('/salesorder');
        }
        else
        {
          alert("Sales Order creation failed");
        }
      }
    else
    {
      alert("Sales Order creation failed");
    }
  }
}
}
 else
{
   alert("Invalid Input");  
}
}

    const handleChange=e=>{
      
        const {name,value}=e.target
        const {subTotal}=order;
  
        if( e.target.name ==='discount')
        {
          setOrder({...order,[name]:value,["total"]:(parseInt(subTotal) - parseInt(value))})
        }
        else if(e.target.name ==='customerId')
        {
        //  alert(e.target.value);
          const custId=e.target.value;
    
          axios.get(url+'/customer/readone/'+custId)
          .then((getData) => {
            let custName = getData.data.name;
           setOrder({...order,[name]:value,["customerName"]:custName})
          })  
        
        }
        else
        {
          setOrder({...order,[name]:value});
        }
     console.log(order);
      
     }
  

const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<data.length;i++)
  {
     sum=sum+parseInt(data[i]["amount"]);
  }
  setOrder({...order,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(order.discount))})
 
}
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Sales order</h1>
        <Link to="/salesorder">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Sales Order</Header>
            <Segment>
              <Form>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
                  
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Order Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='salesOrderNumber' value={order.salesOrderNumber} onChange={handleChange}  placeholder='Sales Order Number'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <input name='reference' value={order.reference} onChange={handleChange}  placeholder='Reference'  />
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={order.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Expected shipment Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date'  name='expectedShipmentDate' value={order.expectedShipmentDate} onChange={handleChange}   placeholder='Expected Shipment Date'  />
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Method</label>
                  <span className="salesTotalsValue"> 
                  <input  name='deliveryMethod' value={order.deliveryMethod} onChange={handleChange}   placeholder='Delivery Method'  />
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Description</label>
                  <span className="salesTotalsValue"> 
                  <input  name='description' value={order.description} onChange={handleChange}  placeholder='Description'  />
              </span></div>  </Form.Field>

                {
                data.map((val,i)=>

                <div className='itemContainerbox' key={i}>
                <Form.Field>
                <div className='itemRow'>
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                  <label></label> </div>
                </Form.Field>
                <Form.Field>
                <div className='itemRow'>
                <span className='productInfoValue'> 
               <select  id="Select" name='itemId'  onChange={(e)=>handleChangeItems(e,i)} placeholder='Item' >
               <option>--Select Item--</option>
                  {item.map((ds,index)=>{return(<option key={index} value={ds._id}> {ds.itemName}</option> )})} </select>
            </span>
             <span className='productInfoValue'> 
              <input  required name='quantity' value={val.quantity} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Quantity'  />
             </span> 
             <span className='productInfoValue'> 
              <input className='productInfoValue' required name='rate' value={val.rate} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Rate'  />
             </span>
             <span className='productInfoValue'> 
              <input required name='amount' value={val.amount} onChange={(e)=>handleChangeItems(e,i)} placeholder='Amount'  />
              </span>
              
              
              <DeleteOutline 
                className="productListDelete" onClick={()=>handleDelete(i)}
                   />
            
              <button className="productListEdit"  onClick={()=>handleAddmoreClick(i)}>Add More Item</button>
           </div> 
              </Form.Field>
              <Form.Field>

              </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft">
              
          </div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue">  <input required name='subTotal' value={order.subTotal} onChange={handleChange}   placeholder='Sub Total'  />
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <input required name='discount' value={order.discount} onChange={handleChange}  placeholder='Discount'  />
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                 <input required name='total' value={order.total} onChange={handleChange}   placeholder='Total'  />
                </span> </div>
                </Form.Field>  </div>     </div>        
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={order.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option >Draft</option>
      <option>Open</option>
      <option>Dispatched</option>
      <option>Delivered</option>
      <option>Void</option>
      <option>On hold</option>
      <option>Closed</option>
    </select></span>
               </div> </Form.Field>       
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/salesorder' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default SalesOrder