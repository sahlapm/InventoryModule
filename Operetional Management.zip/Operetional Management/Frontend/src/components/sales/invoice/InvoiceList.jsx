import React from 'react'
import moment from 'moment';
import { DataGrid } from "@material-ui/data-grid";
import "./invoiceList.css";
import { DateRangePicker } from 'react-date-range';
import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';
import { Button, Segment, Form, TextArea, Dropdown, Header } from 'semantic-ui-react';

const InvoiceList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    const [details, setDetails] = useState([]);
    const [searchData, setSearchData] = useState([]);
    const [startDate,setStartDate]= useState(new Date());
  const [endDate,setEndDate]= useState(new Date());
 
    useEffect(() => {  
        sessionStorage.setItem("salesOrderId", "0");
             FillData();
          
      },[])     
    
      const makeStyle = (status) => {
        if ( status === 'Paid' ||status === 'Send') {
            return {
                
                color: 'green',
      
            }
        }
        else if (status === 'Open'||status === 'Overdue' ||status === 'Draft') {
            return {
             
                color: 'red',
            }
        }
        else {
            return {
                
                color: 'white',
      
            }
        }
      }
      const FillData=()=>
  {
   console.log("start");
    axios.get(url+'/invoice/read')
    .then((getData)=>{
      setData(getData.data);    
      setSearchData(getData.data);
    })
  }

   
  const handleSelect = (dt) =>{
    let filtered = searchData.filter((data)=>{
      let date = new Date(data["date"]);
      return(date>= dt.selection.startDate &&
        date<= dt.selection.endDate);
    })
    setStartDate(dt.selection.startDate);
    setEndDate(dt.selection.endDate);
    setData(filtered);
  };

 
  const selectionRange = {
    startDate: startDate,
    endDate: endDate,
    key: 'selection',
  }




    const columns = [
      
      { field: "customerName", headerName: "Customer Name", width: 120 
      ,
        },
      {
        field: "invoiceNumber",
        headerName: "Invoice Number",
        width: 120
      },
    
      {
        field: "date",
        headerName: "Date",
        width: 120,
      },
      
      {
        field: "status",
        headerName: "Status",
        width: 120,
        renderCell: (params) => {
          return (
            <>
              <label className='status' style={makeStyle(params.row.status)}>{params.row.status}</label>
              
            </>
          );
        },
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <Link to={"/viewinvoice/" + params.row.id}>
              <button className="productListEdit">View</button>
            </Link>
              
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      customerName:row.customerName,
      invoiceNumber: row.invoiceNumber,
      date: moment(row.date).format("DD-MM-YYYY"),
      status:row.status
     

      
    }))
    
    
    return (
      
      <div className="product">
      <div className="productTitleContainer">


        <h1 className="productTitle">Invoice List</h1>
        <Link to="/Newinvoice">
          <button className="productAddButton">Create New</button>
        </Link>
</div>

        <div className="productTop">
          <div className="productTopLeft">
          <h3 className="productTitle">Select Date Range</h3>
          <DateRangePicker
        ranges={[selectionRange]}
        onChange={handleSelect}
      />
          </div>
          <div className="productTopRight">
          

           <DataGrid autoHeight
          rows={rows}
          columns={columns}
          pageSize={8}
                  
        />
                       
                    
          </div>
      </div>
      

      
    
      
       
        
      </div>
    );
}

export default InvoiceList