
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
import "./invoice.css";
import { DeleteOutline } from "@material-ui/icons";
const Invoice = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
          
  const [data,setData]=useState([{itemName:'--select Item--',sku:'',file:'',quantity:0,rate:0,amount:0,itemId:'',brand:'',invoiceId:'',oldInvoicedQuantity:0,salesDetailsId:'',quantityOut:0,inventoryId:'',stockOnHand:0}]);
  const [sales, setSales] = useState([]);
  const [item, setItem] = useState([]);
  const [customer, setCustomer] = useState([]);
  const [invoice,setInvoice]=useState({
    customerName:'',
              customerId:'',
              invoiceNumber:'',
              salesOrderId:'',
              salesOrderNumber:'',
              placeOfSupply:'',
              date:'',
           
              terms:'',
              salesPerson:'',
              
            subTotal:0,
            discount:0,
            total:0,
            paidAmount:0,
            status:'--Select Status--'
           
  });
const [visible, setVisible] = useState(true);

var total=0;
  useEffect(() => {

    if(sessionStorage.getItem("salesOrderId")!=="0")
    {
    var salesOrderId=sessionStorage.getItem("salesOrderId");
 
    axios.get(url+'/salesorder/readone/'+salesOrderId)
            .then((getData) => {   
              console.log(getData.data);     
               setInvoice({...invoice,["salesOrderId"]:salesOrderId,["customerId"]:getData.data.customerId,["customerName"]:getData.data.customerName,["salesOrderNumber"]:getData.data.salesOrderNumber,["subTotal"]:getData.data.subTotal,["discount"]:getData.data.discount,["total"]:getData.data.total})
            })

            
            axios.get(url+'/salesorder/readDetails/'+salesOrderId)
            .then((getData)=>{
              setData(getData.data);      
            })
        setVisible(false)
  
    }
    else
    {
    setVisible(true);
   
    }


    FillCustomer();
  FillItem(); 
},[])
const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
  })
}
const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
  })
}
const handleAddmoreClick=(i)=>{
  if(data[i].itemName && data[i].quantity && data[i].rate && data[i].amount)
  {
    if(data[i].itemId ==="--Select Item--")
    {
      alert("Select Item");
    }
    else
    {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(data[i].quantity))
    {
      alert('Quantity is invalid')
    }
    else if(!regex.test(data[i].rate))
    {
      alert('Rate is invalid')
    }
    else if(!regex.test(data[i].amount))
    {
      alert('Amount is invalid')
    }
    else
    {
    setData([...data,{itemName:"",quantity:"",rate:"",amount:""}])
    /*
    sbTotal= parseInt(order.subTotal) + parseInt(data[i].amount);
     order.subTotal=sbTotal;*/
    }
  }
  }
    else
    {
      alert("Invalid item details"); 
     }
}
const handleChangeItems=(e,i)=>{
    const {name,value}=e.target
    console.log(data);
    const onchangeVal = [...data]
      
      if(e.target.name==="quantity" || e.target.name==="rate")
      {
            onchangeVal[i][name]=value
            if(onchangeVal[i]["quantity"] && onchangeVal[i]["rate"])
            {
              total=parseInt(onchangeVal[i]["quantity"]) * parseInt(onchangeVal[i]["rate"]);
              onchangeVal[i]["amount"]=total;
            } 
            setData(onchangeVal)
            CalculateTotal()
      }
      else if(e.target.name==="itemId")
      {
        let item_id=e.target.value;
        if(item_id!=='')
        {
       
          axios.get(url+'/item/readone/'+item_id)
          .then((getData) => {
            console.log(getData.data);

            onchangeVal[i]["rate"]=getData.data.sellingPrice;
            onchangeVal[i]["itemName"]=getData.data.itemName;
            onchangeVal[i]["brand"]=getData.data.brand;
            onchangeVal[i]["sku"]=getData.data.sku;
            onchangeVal[i]["file"]=getData.data.file;
            onchangeVal[i]["itemId"]=e.target.value;
            axios.get(url+'/item/readoneitem/'+item_id)
            .then((getData) => {
              onchangeVal[i]["quantityOut"]=getData.data.quantityOut;
              onchangeVal[i]["inventoryId"]=getData.data._id;
              onchangeVal[i]["stockOnHand"]=getData.data.stockOnHand;
            })
            setData(onchangeVal);          
          })  
        }
      }
     total=0;
}

const handleDelete=(i)=>{
  if(i===0)
  {
    setData([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:''}]);
  }
  else
  {
   
    const deleteVal = [...data]
    deleteVal.splice(i,1)
    setData(deleteVal)
    let sum=0;
 
  for(let i=0;i<deleteVal.length;i++)
  {
     sum=sum+parseInt(deleteVal[i]["amount"]);
  }
  setInvoice({...invoice,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(invoice.discount))})
  }
  //CalculateTotal();
}
const sendDataToAPI = async(event)=>{
  console.log(invoice,"invoice")
  const {customerId, invoiceNumber, date,subTotal,discount,total,status,salesOrderId}=invoice

 if(customerId && invoiceNumber && date && subTotal && total && status )
 {     
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else if(status ==="--Select Status--")
  {
    alert("Select Status");
  }
  else
  {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(subTotal))
    {
      alert('Sub Total is invalid')
    }
    else if(!regex.test(discount))
    {
      alert('Discount is invalid')
    }
    if(!regex.test(total))
    {
      alert('Total is invalid')
    }
   else{
    
     console.log(invoice,"invoice");
    const response= await  axios.post(url+`/invoice/create`,invoice)
    if(response.data.success)
    {
        const onchangeVal = [...data];
        for( let i=0;i<data.length;i++)
        {
          onchangeVal[i]["invoiceId"]=response.data.data._id
          onchangeVal[i]["salesDetailsId"]  =data[i]["_id"] 
        }
        let new_list = onchangeVal.map(function(obj) {
          if(obj.paymentReceived!=0)
          {
          return {
            itemName: obj.itemName,
            invoiceNumber: obj.invoiceNumber,
            quantity: obj.quantity,
            rate: obj.rate,
            amount : obj.amount,
            brand  : obj.brand,
            sku:obj.sku,
            file:obj.file,
            invoiceId: obj.invoiceId,
            itemId: obj.itemId,
            invoicedQuantity: obj.invoicedQuantity,
            oldInvoicedQuantity: obj.oldInvoicedQuantity,
            salesDetailsId: obj.salesDetailsId,
            quantityOut: obj.quantityOut,
            stockOnHand: obj.stockOnHand,
            inventoryId: obj.inventoryId,
          }}})
        console.log(onchangeVal,"b4save");
        const Detailsresponse= await  axios.post(url+`/invoice/createDetails/`,new_list)
       
       
        console.log(new_list,"nl");
        let successcount=0;
        let success=false;
        let isOk=false;
        let OrderStatus={};
        var Invoiceresponse="";
        let Inventory={};
        var Inventoryresponse="";
        for (let i= 0; i<new_list.length; i++) {
          let isOk=false;
           if(salesOrderId!="")
          {
                OrderStatus={};
                OrderStatus=
                {         
                    "quantity":parseInt(new_list[i].quantity)+parseInt(new_list[i].oldInvoicedQuantity)
                }
                Invoiceresponse=await axios.put(url+`/salesorder/updateInvoice/`+new_list[i].salesDetailsId,OrderStatus)
                if( Invoiceresponse.data.success)
                {
                    isOk=true;
                }
          }
          else
          {
              isOk=true;
          }
       if(isOk)
      {  
          if(status ==="Send" ||status ==="Overdue" ||status ==="Paid")
          {           
             Inventory={};
              Inventory=
              {         
                  "quantityOut":parseInt(new_list[i].quantity) +parseInt(new_list[i].quantityOut)
              }
            console.log(Inventory,"Inventory");
            Inventoryresponse=await axios.put(url+`/item/updateQtyOut/`+new_list[i].inventoryId,Inventory)
            if(Inventoryresponse.data.success)
            {
                  successcount++;
            }         
          }
          


          if(status ==="Open")
          {           
             Inventory={};
              Inventory=
              {         
                  "stockOnHand":parseInt(new_list[i].quantity) -parseInt(new_list[i].stockOnHand)
              }
            console.log(Inventory,"Inventory");
            Inventoryresponse=await axios.put(url+`/item/updateStockonHand/`+new_list[i].inventoryId,Inventory)
            if(Inventoryresponse.data.success)
            {
                  successcount++;
            }         
          }
      }
  
    }

  if(successcount===new_list.length)
     {
     if(salesOrderId!='')
    {
     const Invresponse=await axios.put(url+`/salesorder/updateInvoiceStatus/`+salesOrderId)
     if(Invresponse.data.success)
     {
     success=true;
     }
     }
     else
     {
       success=true;
     }
     }
       
        if(Detailsresponse.data.success)
        {
          alert("Invoice created successfully");
          navigate('/invoice');
        }
        else
        {
          alert("Invoice creation failed");
        }
      }
    else
    {
      alert("Invoice creation failed");
    }
  }
}
}
 else
{
   alert("Invalid Input");  
}
}

    const handleChange=e=>{
      
        const {name,value}=e.target
        const {subTotal}=invoice;
  
        if( e.target.name ==='discount')
        {
          setInvoice({...invoice,[name]:value,["total"]:(parseInt(subTotal) - parseInt(value))})
        }
        else if(e.target.name ==='customerId')
        {
        //  alert(e.target.value);
          const custId=e.target.value;
         if(custId!=='')
          {
          axios.get(url+'/customer/readone/'+custId)
          .then((getData) => {
            let custName = getData.data.name;
            setInvoice({...invoice,[name]:value,["customerName"]:custName})
          })        
              
            axios.get(url+'/salesorder/salesorderByCustomer/'+custId)
            .then((getData) => {
              setSales(getData.data);      
           })  
          }

        
        }
        else  if(e.target.name==="salesOrderId")
        {
          let item_id=e.target.value;     
          if(item_id!=='')
          {   
            axios.get(url+'/salesorder/readone/'+item_id)
            .then((getData) => {   
              console.log(getData.data);     
               setInvoice({...invoice,[name]:value,["salesOrderNumber"]:getData.data.salesOrdereNumber,["subTotal"]:getData.data.subTotal,["discount"]:getData.data.discount,["total"]:getData.data.total})
            })
console.log(invoice)
            
            axios.get(url+'/salesorder/readDetails/'+item_id)
            .then((getData)=>{
              setData(getData.data);     


              const onchangeVal = getData.data
              for( let i=0;i< getData.data.length;i++)
              {
                
                onchangeVal[i]["oldInvoicedQuantity"]=onchangeVal[i]["invoicedQuantity"];

                axios.get(url+'/item/readoneitem/'+ onchangeVal[i]["itemId"])
                .then((response) => {
                  onchangeVal[i]["quantityOut"]=response.data.quantityOut;
                  onchangeVal[i]["inventoryId"]=response.data._id;
                  onchangeVal[i]["stockOnHand"]=response.data.stockOnHand;
                  onchangeVal[i]["file"]=response.data.file;

                })

                axios.get(url+'/item/readone/'+onchangeVal[i]["itemId"])
          .then((getData) => {
            console.log(getData.data);

           
            onchangeVal[i]["file"]=getData.data.file;
            onchangeVal[i]["sku"]=getData.data.sku;
                   })
                  }
            
              console.log(onchangeVal,"onchangeVal")
             setData(onchangeVal)


            })
          }
        }
        else
        {
            setInvoice({...invoice,[name]:value});
        }
     console.log(invoice);
      
     }
  

const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<data.length;i++)
  {
     sum=sum+parseInt(data[i]["amount"]);
  }
  setInvoice({...invoice,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(invoice.discount))})
 
}
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Invoice</h1>
        <Link to="/invoice">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Invoice</Header>
            <Segment>
              <Form>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  {visible &&       <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
  }
   {!visible &&
 <label>{invoice.customerName}</label>}
                  </span>
               </div> </Form.Field>
               <Form.Field>
              <div className="salesInfoTotals">
                  <label>Sales Order</label>
                  <span className="salesTotalsValue"> 
            {visible &&      <select id="Select" name='salesOrderId'  onChange={handleChange} >
                  <option>--Select Sales Order--</option>
                  {sales.map((so,index)=>{return(<option key={index} value={so._id}>{so.salesOrderNumber}</option> )})} </select>
  }
   {!visible &&
 <label>{invoice.salesOrderNumber}</label>}
                  </span>
               </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Invoice Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='invoiceNumber' value={invoice.invoiceNumber} onChange={handleChange}  placeholder='Invoice Number'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Place of Supply</label>
                  <span className="salesTotalsValue"> 
                  <input name='placeOfSupply' value={invoice.placeOfSupply} onChange={handleChange}  placeholder='Place of Supply'  />
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={invoice.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
                
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Terms</label>
                  <span className="salesTotalsValue"> 
                  <input  name='terms' value={invoice.terms} onChange={handleChange}   placeholder='Terms'  />
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Person</label>
                  <span className="salesTotalsValue"> 
                  <input  name='salesPerson' value={invoice.salesPerson} onChange={handleChange}  placeholder='Sales Person'  />
              </span></div>  </Form.Field>

                {
                data.map((val,i)=>

                <div className='itemContainerbox'  key={i}>
                <Form.Field>
                <div className='itemRow'>
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                  <label></label> </div>
                </Form.Field>
                <Form.Field>
                <div className='itemRow'>
                <span className='productInfoValue'> 
               <select  id="Select" name='itemId'  onChange={(e)=>handleChangeItems(e,i)} placeholder='Item' >
               <option>--Select Item--</option>
                  {item.map((ds,index)=>{return(<option key={index} value={ds._id}
                  selected={ds._id === val.itemId}
                  > {ds.itemName}</option> )})} </select>
            </span>
             <span className='productInfoValue'> 
              <input  required name='quantity' value={val.quantity} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Quantity'  />
             </span> 
             <span className='productInfoValue'> 
              <input className='productInfoValue' required name='rate' value={val.rate} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Rate'  />
             </span>
             <span className='productInfoValue'> 
              <input required name='amount' value={val.amount} onChange={(e)=>handleChangeItems(e,i)} placeholder='Amount'  />
              </span>
              
              
              <DeleteOutline 
                className="productListDelete" onClick={()=>handleDelete(i)}
                   />
            
              <button className="productListEdit"  onClick={()=>handleAddmoreClick(i)}>Add More Item</button>
           </div> 
              </Form.Field>
              <Form.Field>

              </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft">
              
          </div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue">  <input required name='subTotal' value={invoice.subTotal} onChange={handleChange}   placeholder='Sub Total'  />
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <input required name='discount' value={invoice.discount} onChange={handleChange}  placeholder='Discount'  />
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                 <input required name='total' value={invoice.total} onChange={handleChange}   placeholder='Total'  />
                </span> </div>
                </Form.Field> 
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Amount Paid</label>
                  <span className="salesTotalsValue"> 
                  <input required name='paidAmount' value={invoice.paidAmount} onChange={handleChange}  placeholder='Amount Paid'  />
             </span>  </div> </Form.Field>
                 </div>     </div>        
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={invoice.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Select Status" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>     
      <option>Send</option>
      <option>Overdue</option>     
      <option>Paid</option>
    </select></span>
               </div> </Form.Field>       
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/invoice' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default Invoice