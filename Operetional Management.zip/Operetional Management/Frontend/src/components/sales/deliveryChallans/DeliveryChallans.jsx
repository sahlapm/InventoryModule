
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
//import "./deliverChallans.css";
import { DeleteOutline } from "@material-ui/icons";
const DeliveryChallans = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:'',brand:'',deliveryChallanId:''}]);
  
  const [item, setItem] = useState([]);
  const [customer, setCustomer] = useState([]);
  const [challan,setChallan]=useState({
    customerName:'',
              customerId:'',
              deliveryChallanNumber:'',
              reference:'',
              date:'',
              challanType:'',
              warehouseName:'',              
            subTotal:0,
            discount:0,
            total:0,
            status:'--Select Status--'
           
  });
var total=0;
  useEffect(() => {
    FillCustomer();
  FillItem(); 
},[])
const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
  })
}
const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
  })
}
const handleAddmoreClick=(i)=>{
  if(data[i].itemName && data[i].quantity && data[i].rate && data[i].amount)
  {
    if(data[i].itemId ==="--Select Item--")
    {
      alert("Select Item");
    }
    else
    {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(data[i].quantity))
    {
      alert('Quantity is invalid')
    }
    else if(!regex.test(data[i].rate))
    {
      alert('Rate is invalid')
    }
    else if(!regex.test(data[i].amount))
    {
      alert('Amount is invalid')
    }
    else
    {
    setData([...data,{itemName:"",quantity:"",rate:"",amount:""}])
    /*
    sbTotal= parseInt(order.subTotal) + parseInt(data[i].amount);
     order.subTotal=sbTotal;*/
    }
  }
  }
    else
    {
      alert("Invalid item details"); 
     }
}
const handleChangeItems=(e,i)=>{
    const {name,value}=e.target
    console.log(data);
    const onchangeVal = [...data]
      
      if(e.target.name==="quantity" || e.target.name==="rate")
      {
            onchangeVal[i][name]=value
            if(onchangeVal[i]["quantity"] && onchangeVal[i]["rate"])
            {
              total=parseInt(onchangeVal[i]["quantity"]) * parseInt(onchangeVal[i]["rate"]);
              onchangeVal[i]["amount"]=total;
            } 
            setData(onchangeVal)
            CalculateTotal()
      }
      else if(e.target.name==="itemId")
      {
        let item_id=e.target.value;
        if(item_id!=='')
        {
       
          axios.get(url+'/item/readone/'+item_id)
          .then((getData) => {
            console.log(getData.data);

            onchangeVal[i]["rate"]=getData.data.sellingPrice;
            onchangeVal[i]["itemName"]=getData.data.itemName;
            onchangeVal[i]["brand"]=getData.data.brand;
            onchangeVal[i]["itemId"]=e.target.value;
            setData(onchangeVal);          
          })  
        }
      }
     total=0;
}

const handleDelete=(i)=>{
  if(i===0)
  {
    setData([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:''}]);
  }
  else
  {
   
    const deleteVal = [...data]
    deleteVal.splice(i,1)
    setData(deleteVal)
    

    let sum=0;
 
  for(let i=0;i<deleteVal.length;i++)
  {
     sum=sum+parseInt(deleteVal[i]["amount"]);
  }
  setChallan({...challan,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(challan.discount))})
  }
  //CalculateTotal();
}
const sendDataToAPI = async(event)=>{
  const {customerId, deliveryChallanNumber, date,subTotal,discount,total,status}=challan

 if(customerId && deliveryChallanNumber && date && subTotal &&  total && status)
 {     
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else if(status ==="--Select Status--")
  {
    alert("Select Status");
  }
  else
  {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(subTotal))
    {
      alert('Sub Total is invalid')
    }
    else if(!regex.test(discount))
    {
      alert('Discount is invalid')
    }
    if(!regex.test(total))
    {
      alert('Total is invalid')
    }
   else{
    
    
    const response= await  axios.post(url+`/challan/create`,challan)
    if(response.data.success)
    {
        const onchangeVal = [...data];
        for( let i=0;i<data.length;i++)
        {
          onchangeVal[i]["deliveryChallanId"]=response.data.data._id
        }
        console.log(onchangeVal);
        const Detailsresponse= await  axios.post(url+`/challan/createDetails/`,onchangeVal)
        if(Detailsresponse.data.success)
        {
          alert("Delivery Challan created successfully");
          navigate('/challans');
        }
        else
        {
          alert("Delivery Challan creation failed");
        }
      }
    else
    {
      alert("Delivery Challan creation failed");
    }
  }
}
}
 else
{
   alert("Invalid Input");  
}
}

    const handleChange=e=>{
      
        const {name,value}=e.target
        const {subTotal}=challan;
  
        if( e.target.name ==='discount')
        {
          setChallan({...challan,[name]:value,["total"]:(parseInt(subTotal) - parseInt(value))})
        }
        else if(e.target.name ==='customerId')
        {
        //  alert(e.target.value);
          const custId=e.target.value;
    
          axios.get(url+'/customer/readone/'+custId)
          .then((getData) => {
            let custName = getData.data.name;
           setChallan({...challan,[name]:value,["customerName"]:custName})
          })  
        
        }
        else
        {
          setChallan({...challan,[name]:value});
        }
     console.log(challan);
      
     }
  

const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<data.length;i++)
  {
     sum=sum+parseInt(data[i]["amount"]);
  }
  setChallan({...challan,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(challan.discount))})
 
}
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Delivery Challan</h1>
        <Link to="/challans">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Delivery Challan</Header>
            <Segment>
              <Form>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
                  
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Challan Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='deliveryChallanNumber' value={challan.deliveryChallanNumber} onChange={handleChange}  placeholder='Delivery Challan Number'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <input name='reference' value={challan.reference} onChange={handleChange}  placeholder='Reference'  />
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Challan Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={challan.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
              
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Challan Type</label>
                  <span className="salesTotalsValue"> 
                  <input  name='challanType' value={challan.challanType} onChange={handleChange}   placeholder='Challan Type'  />
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Warehouse Name</label>
                  <span className="salesTotalsValue"> 
                  <input  name='warehouseName' value={challan.warehouseName} onChange={handleChange}  placeholder='Warehose Name'  />
              </span></div>  </Form.Field>

                {
                data.map((val,i)=>

                <div className='itemContainerbox'  key={i}>
                <Form.Field>
                <div className='itemRow'>
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                  <label></label> </div>
                </Form.Field>
                <Form.Field>
                <div className='itemRow'>
                <span className='productInfoValue'> 
               <select  id="Select" name='itemId'  onChange={(e)=>handleChangeItems(e,i)} placeholder='Item' >
               <option>--Select Item--</option>
                  {item.map((ds,index)=>{return(<option key={index} value={ds._id}> {ds.itemName}</option> )})} </select>
            </span>
             <span className='productInfoValue'> 
              <input  required name='quantity' value={val.quantity} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Quantity'  />
             </span> 
             <span className='productInfoValue'> 
              <input className='productInfoValue' required name='rate' value={val.rate} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Rate'  />
             </span>
             <span className='productInfoValue'> 
              <input required name='amount' value={val.amount} onChange={(e)=>handleChangeItems(e,i)} placeholder='Amount'  />
              </span>
              
              
              <DeleteOutline 
                className="productListDelete" onClick={()=>handleDelete(i)}
                   />
            
              <button className="productListEdit"  onClick={()=>handleAddmoreClick(i)}>Add More Item</button>
           </div> 
              </Form.Field>
              <Form.Field>

              </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft">
              
          </div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue">  <input required name='subTotal' value={challan.subTotal} onChange={handleChange}   placeholder='Sub Total'  />
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <input required name='discount' value={challan.discount} onChange={handleChange}  placeholder='Discount'  />
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                 <input required name='total' value={challan.total} onChange={handleChange}   placeholder='Total'  />
                </span> </div>
                </Form.Field>  </div>     </div>        
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={challan.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>
      <option>Delivered</option>
      <option>Returned</option>
     
    </select></span>
               </div> </Form.Field>       
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/challans' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default DeliveryChallans