
import { Button, Segment, Form,Header, StatisticGroup } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 
import "./deliveryChallans.css";

const DeliveryChallanView = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([]);
  const [item, setItem] = useState([]);
 
  const [challan,setChallan]=useState({});
  const [status,setStatus]=useState({});    
  let params=useParams();   
  let Id=params.id;

var total=0;


useEffect(() => {  
 FillChallan();
 FillDetails();
},[])


const FillChallan=()=>
{         
  axios.get(url+'/challan/readone/'+Id)
  .then((getData)=>{
    setChallan(getData.data);  
   
   
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/challan/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
  
  })
}


const handleDelete=(i)=>{
  if(i===0)
  {
    setData([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:''}]);
  }
  else
  {
   
    const deleteVal = [...data]
    deleteVal.splice(i,1)
    setData(deleteVal)
  }
  //CalculateTotal();
}

const sendDataToAPI = async(event)=>{
  

const OrderStatus=
{
  "_id":Id,
    "status":status
}
      const response= await  axios.put(url+`/challan/updateStatus/`+Id,OrderStatus)
      if(response.data.success)
      {
        alert("Status updated successfully");        
      }
      else
      {
        alert("Status updation failed");
      }
 

}


const makeStyle = (status) => {
  if (status === 'Shipped' ||status === 'Packed'|| status === 'Clossed' || status === 'Invoiced') {
      return {
          background: 'rgb(145 254 159 / 47%)',
          color: 'green',

      }
  }
  else if (status === 'Not Shipped' ||status === 'Not Packed'|| status === 'Open' || status === 'Not Invoiced') {
      return {
          background: '#ecb3b5',
          color: 'red',
      }
  }
  else {
      return {
          background: '#59bfff',
          color: 'white',

      }
  }
}


  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Delivery Challan</h1>
       
        <Link to="/challans">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Delivery Challan Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.deliveryChallanNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{challan.date}</label>
               </span> </div></Form.Field>
                              <Form.Field>
                <div className="salesInfoTotals">
                  <label>Challan Type</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.challanType}</label>
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Warehouse Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.warehouseName}</label>
              </span></div> 
               </Form.Field>
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.status}</label>
              </span></div> 
               </Form.Field>
               </div>
         </div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                <Form.Field>
                <div className="itemRow">
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                   </div>
                </Form.Field>
                <Form.Field>
                <div className="itemRow">
                  <label>{val.itemName}</label><label>{val.quantity}</label><label>{val.rate}</label> <label>{val.amount}</label>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue"> 
               <label>{challan.subTotal}</label>
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.discount}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                  <label>{challan.total}</label>
                </span> </div>
                </Form.Field>  </div>  
                   </div>    
                   <div className='itemContainer'>   
                <Header as='h3'> Update Status</Header>
                 <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>
        <option>Delivered</option>
      <option>Returned</option>
    </select>
                  </span>
                  
                   </div>    </Form.Field>
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/challans' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default DeliveryChallanView