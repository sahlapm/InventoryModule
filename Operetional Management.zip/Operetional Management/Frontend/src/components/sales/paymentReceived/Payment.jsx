
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
import moment from 'moment';

const Payment = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([]);
  

  const [customer, setCustomer] = useState([]);
  const [payment,setPayment]=useState({
    customerName:'',
              customerId:'',
              paymentNumber:'',
              reference:'',
              date:'',
              paymentMode:'',
              depositTo:'',   
              paidAmount:0, 
              paymentReceived:0,            
              amountReceived:0,
              paymentReceivedBy:''
           
  });

  const [details,setDetails]=useState([{date:'',invoiceNumber:'',total:0,
  dueAmount:0,paymentReceived:0,invoiceId:'',paymentId:''}]);
var total=0;
  useEffect(() => {
    FillCustomer();
 
},[])

const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
  })
}

const handleChangeItems=(e,i)=>{
 
   
  const {name,value}=e.target
  const onchangeVal = [...data]
  onchangeVal[i][name]=value
 console.log(data,"s")
  setDetails(onchangeVal);
  CalculateTotal();
  
  console.log(payment);

}

const sendDataToAPI = async(event)=>{
  const {customerId, paymentNumber, date}=payment
console.log(payment,"Payment");
 if(customerId && paymentNumber && date )
 {     
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else
  {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
   
    if(!regex.test(total))
    {
      alert('Total is invalid')
    }
   else{
    
    
    const response= await  axios.post(url+`/payment/create`,payment)
    if(response.data.success)
    {
      
      
        const onchangeVal = [...details];
        for( let i=0;i<details.length;i++)
        {
          onchangeVal[i]["paymentId"]=response.data.data._id    
          onchangeVal[i]["invoiceId"]  =details[i]["_id"] 
        }

        let filteredData = [];
        for (let i= 0; i<onchangeVal.length; i++) {
            if (onchangeVal[i].paymentReceived !==0 ) {
              filteredData = [...filteredData, onchangeVal[i]];
            }
        }


        console.log(filteredData,"onchangeVal");



        let new_list = filteredData.map(function(obj) {
        
          return {
            date: obj.date,
            invoiceNumber: obj.invoiceNumber,
            total: obj.total,
            paidAmount:obj.paidAmount,
            paymentReceived:obj.paymentReceived,
            paymentReceivedBy:obj.paymentReceivedBy,           
            invoiceId: obj.invoiceId,
            paymentId: obj.paymentId
          }})
          console.log(new_list,"new_list")
        const Detailsresponse= await  axios.post(url+`/payment/createDetails/`,new_list)
       
        let InvStatus={};
        var Invoiceresponse="";
        let successcount=0;
        for (let i= 0; i<filteredData.length; i++) {
          InvStatus={};
           InvStatus=
          {         
              "paidAmount":parseInt(filteredData[i].paidAmount)+parseInt(filteredData[i].paymentReceived),
              "dueAmount":parseInt(filteredData[i].total)-(parseInt(filteredData[i].paidAmount)+parseInt(filteredData[i].paymentReceived))
          }
          Invoiceresponse=await axios.put(url+`/invoice/updatePaidAmount/`+filteredData[i].invoiceId,InvStatus)
          if(Invoiceresponse.data.success )
          {
            successcount++;
          }
      }
     let success=false;
    
     if(successcount===filteredData.length)
     {
      success=true;
     }
       
        /*    let inv_list = filteredData.map(function(obj) {
     
          return {
            _id: obj.invoiceId,
            paidAmount:obj.paidAmount
            
          }})
          console.log(inv_list,"inv_list")
          const Invoiceresponse= await  axios.put(url+`/invoice/updatePaidAmount/`,inv_list)
        
        */
         if(Detailsresponse.data.success && success )
        {
          alert("Payment created successfully");
          navigate('/payment');
        }
        else
        {
          alert("Payment creation failed");
        }
      }
    else
    {
      alert("Payment creation failed");
    }
  }
}
}
 else
{
   alert("Invalid Input");  
}
}

    const handleChange=e=>{
      
        const {name,value}=e.target
          
         if(e.target.name ==='customerId')
        {
        //  alert(e.target.value);
          const custId=e.target.value;
    
          axios.get(url+'/customer/readone/'+custId)
          .then((getData) => {
            let custName = getData.data.name;
           setPayment({...payment,[name]:value,["customerName"]:custName})
          })  
          axios.get(url+'/invoice/invoiceByCustomer/'+custId)
          .then((getData) => {
            
            const onchangeVal = getData.data
            for( let i=0;i< getData.data.length;i++)
            {
              onchangeVal[i]["paymentReceived"]=0;
              onchangeVal[i]["dueAmount"]=parseInt(onchangeVal[i]["total"])-parseInt(onchangeVal[i]["paidAmount"])
            }
          
            console.log(onchangeVal,"onchangeVal")
           setData(onchangeVal)
          
          })  
         
        
        }
        else
        {
          setPayment({...payment,[name]:value});
        }
    
      
     }
  

const CalculateTotal=()=>
{
  let sum=0;
 let amount='0';
 console.log(details,"details");
  for(let i=0;i<details.length;i++)
  {
    if(details[i]["paymentReceived"]==='') 
    {
      amount='0';
    }
    else
    {
      amount=details[i]["paymentReceived"];
    }
    console.log(amount,"amount");
    sum=sum+parseInt(amount);
  }
  console.log(payment,"A");
  setPayment({...payment,["amountReceived"]:sum});

 
}
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Payment Received</h1>
        <Link to="/payment">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Payment received</Header>
            <Segment>
              <Form>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
                  
                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Payment Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='paymentNumber' value={payment.paymentNumber} onChange={handleChange}  placeholder='Payment Number'  />
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <input name='reference' value={payment.reference} onChange={handleChange}  placeholder='Reference'  />
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label> Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={payment.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
              
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Payment Mode</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='paymentMode'  onChange={handleChange} className="form-control form-control-md"   placeholder="paymentMode" required>
                                 
                                 <option>--Select Payment Mode--</option>
                   <option>Bank remittance</option>
                     <option>Bank Transfer</option>
                     <option>Cash</option>
                     <option>Cheque</option>
                     <option>Credit Card</option>
                     <option>Other Payment</option>
                    
                   </select></span>
             </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Deposit To</label>
                  <span className="salesTotalsValue"> 
                  <input  name='depositTo' value={payment.depositTo} onChange={handleChange}  placeholder='Deposit To'  />
              </span></div>  </Form.Field>
           
              <Form.Field>
                <div className="salesInfoTotals">
                  <label>Payment Received By</label>
                  <span className="salesTotalsValue"> 
                  <input  name='paymentReceivedBy' value={payment.paymentReceivedBy} onChange={handleChange}  placeholder='Payment Received By'  />
              </span></div>  </Form.Field>
 
              
              
  <div className='itemContainer'>
            <div className="itemRow">
            <label>Date</label><label>Invoice Number</label><label>Invoice Amount</label> <label>Amount Due</label> <label>Payment</label>
                   </div></div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                
                <Form.Field>
                <div className="itemRow">
                  <label name="date" key={i} onChange={(e)=>handleChangeItems(e,i)}>{moment(val.date).format("DD-MM-YYYY")}</label>
                  <label name="invoiceNumber" onChange={(e)=>handleChangeItems(e,i)}>{val.invoiceNumber}</label>
                  <label name="total" onChange={(e)=>handleChangeItems(e,i)}>{val.total}</label>
                  <label name="dueAmount" onChange={(e)=>handleChangeItems(e,i)} >{val.dueAmount}</label> 
                  <div> 
                  <span className='productInfoValue'> 
                  <input  name='paymentReceived' onChange={(e)=>handleChangeItems(e,i)} />
            </span>
                     </div>
                   </div>
                </Form.Field>
            
                </div>
                )
}

                <div className="salesbottom">
                <div className="salesLeft">
              
          </div>
          <div className="salesRight">
          <Form.Field>
                <div className="salesInfoTotals">
                  <label>Amount Received </label>
                  <span className="salesTotalsValue"> 
                  <input  name='amountReceived' value={payment.amountReceived} onChange={handleChange}  placeholder='Amount Received'  />
              </span></div>  </Form.Field>
              </div>     </div>        
                     
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/payment' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default Payment