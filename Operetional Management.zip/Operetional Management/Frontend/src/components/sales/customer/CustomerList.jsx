import React from 'react'
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";

import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import axios from 'axios';

const CustomerList = () => {
    const url="http://localhost:5000/api";

    const [data, setData] = useState([]);
    useEffect(() => {
      setTimeout(() => {
        FillData();
      }, 1000)
             },[])
     
    
      const handleDelete=(id)=>
      {

        console.log("start");
        axios.delete(url+'/customer/delete/'+id)
        .then((response)=>
        {if(response.data.status==="success")
        {
          alert("Customer deleted successfully");
          FillData();
        }
        else
        {
          alert("Something went wrong");
        }
        })
      }
    
      const FillData=()=>
  {
  
    axios.get(url+'/customer/read')
    .then((getData)=>{
      setData(getData.data);    
    })
  }

    
  
    const columns = [
      
      { field: "name", headerName: "Name", width: 200 
      ,
        },
      {
        field: "type",
        headerName: "Type",
        width: 150
      },
      { field: "contactNumber", headerName: "Contact Number", width: 150 },
      {
        field: "email",
        headerName: "Email",
        width: 200,
      },
      {
        field: "website",
        headerName: "Website",
        width: 160,
      },
      {
        field: "address",
        headerName: "Address",
        width: 160,
      },
      {
        field: "action",
        headerName: "Action",
        width: 150,
        renderCell: (params) => {
          return (
            <>
              <Link to={"/customeredit/" + params.row.id}>
              <button className="productListEdit">Edit</button>
            </Link>
              <DeleteOutline
                className="productListDelete"
                onClick={() => handleDelete(params.row.id)}
              />
            </>
          );
        },
      },
    ];
  
    const rows=data.map((row)=>({
      id : row._id,
      type:row.type,
      name: row.name,
      contactNumber:row.contactNumber,
      email: row.email,
      website:row.website,
      address:row.address
    }))
    
    return (
      
      <div className="productList">
         <div className="productTitleContainer">
        <h1 className="productTitle">Customer List</h1>
        <Link to="/newCustomer">
          <button className="productAddButton">Create New</button>
        </Link>
      </div>
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={8}
          
         
        />
        
      </div>
    );
}

export default CustomerList