
import { Button, Segment, Form, TextArea, Dropdown, Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 

const Customer = () => {

  const url="http://localhost:5000/api";


  const navigate=useNavigate();  
  const [customer,SetCustomer]=useState({
    type:'Business',
              name:'',
              contactNumber:'',
              email:'',
              website:'',
              address:'',
              creditPeriod:'',
              creditLimit:''
  });

 

  const sendDataToAPI = async(event)=>{
    const {type, name, contactNumber,email,creditLimit,creditPeriod}=customer
   if(type && name && contactNumber)
   {     
    let regexNo=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    let emailRegex=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    let contactRegex=/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if(creditLimit &&!regexNo.test(creditLimit))
    {
      alert('creditLimit is invalid')
    }
    else if(creditPeriod && !regexNo.test(creditPeriod))
    {
      alert('creditPeriod is invalid')
    }
    else if(!emailRegex.test(email))
    {
      alert('Email is invalid')
    }
    else if(!contactRegex.test(contactNumber))
    {
      alert('Contact Number is invalid')
    }
    else{
        
        const response= await  axios.post(url+`/customer/create`,customer)
        console.log(response);
        if(response.data.success)
        {
          alert("Customer created successfully");
          navigate('/customerlist');
        }
        else
        {
          alert("Customer Creation failed");
        }
    }
 }
   else
   {
     alert("Invalid Input");  }
  
    }
    const handleChange=e=>{
      
        const {name,value}=e.target
        SetCustomer({...customer,[name]:value})
        console.log(value)
        
     
   
     }

  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Customer</h1>
        <Link to="/customerlist">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Customer</Header>
            <Segment>
              <Form>
              <Form.Field>
                  <label>Customer Type</label>
                  <select id="Select" name='mode' value={customer.type} onChange={handleChange}   placeholder="Customer type" required>
        <option>Business</option>
      <option>Individual</option>   
          </select>
                </Form.Field>
            
                <Form.Field>
                  <label>Name</label>
                  <input required name='name' value={customer.name} onChange={handleChange}  placeholder='Name'  />
                </Form.Field>

            
                <Form.Field>
                  <label>Contact Number</label>
                  <input required name='contactNumber' value={customer.contactNumber} onChange={handleChange}   placeholder='Contact Number'  />
                </Form.Field>            
                <Form.Field>
                  <label>Email</label>
                  <input required name='email' value={customer.email} onChange={handleChange}  placeholder='Email'  />
                </Form.Field>
                
                <Form.Field>
                  <label>Website</label>
                  <input required name='website' value={customer.website} onChange={handleChange}  placeholder='Website'  />
              
                </Form.Field>
                <Form.Field>
                  <label>Address</label>
                  <input required name='address' value={customer.address} onChange={handleChange}  placeholder='address'  />
                </Form.Field>
                <Form.Field>
                  <label>Credit Limit</label>
                  <input required name='creditLimit' value={customer.creditLimit} onChange={handleChange}  placeholder='Credit Limit'  />
                </Form.Field>
                <Form.Field>
                  <label>Credit Period</label>
                  <input required name='creditPeriod' value={customer.creditPeriod} onChange={handleChange}  placeholder='Credit Period'  />
                </Form.Field>
              
                <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>

                <Button size='mini' color='grey'>
                  <Link to='/customerList' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default Customer