
import { Button, Segment, Form,Header } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useNavigate,Link} from 'react-router-dom' 
//import "./invoice.css";
import { DeleteOutline } from "@material-ui/icons";
const CreditNote = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([{creditNoteId:'',itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:'',brand:'',invoiceId:'',quantityIn:0,inventoryId:''}]);
  const [sales, setSales] = useState([]);
  const [item, setItem] = useState([]);
  const [customer, setCustomer] = useState([]);
  const [credit,setCredit]=useState({
    customerName:'',
              customerId:'',
              invoiceNumber:'',
              invoiceId:'',
              creditNoteNumber:'',
             
              date:'',           
              reference:'',
              salesPerson:'',              
            subTotal:0,
            discount:0,
            total:0,
            paidAmount:0,
            status:'--Select Status--'           
  });
const [visible, setVisible] = useState(true);

var total=0;
  useEffect(() => {

    if(sessionStorage.getItem("invoiceId")!=="0")
    {
    var Id=sessionStorage.getItem("invoiceId");
 
    axios.get(url+'/invoice/readone/'+Id)
            .then((getData) => {   
              console.log(getData.data);     
               setCredit({...credit,["invoiceId"]:Id,["customerId"]:getData.data.customerId,["customerName"]:getData.data.customerName,["invoiceNumber"]:getData.data.invoiceNumber,["subTotal"]:getData.data.subTotal,["discount"]:getData.data.discount,["total"]:getData.data.total})
            })

            
            axios.get(url+'/invoice/readDetails/'+Id)
            .then((getData)=>{
              setData(getData.data);      
            })
        setVisible(false)
  
    }
    else
    {
    setVisible(true);
   
    }


    FillCustomer();
  FillItem(); 
},[])
const FillItem=()=>
{
  axios.get(url+'/item/read')
  .then((getData)=>{
    setItem(getData.data);   
  })
}
const FillCustomer=()=>
{
    axios.get(url+'/customer/read')
  .then((getData)=>{
    setCustomer(getData.data);   
  })
}
const handleAddmoreClick=(i)=>{
  if(data[i].itemName && data[i].quantity && data[i].rate && data[i].amount)
  {
    if(data[i].itemId ==="--Select Item--")
    {
      alert("Select Item");
    }
    else
    {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(data[i].quantity))
    {
      alert('Quantity is invalid')
    }
    else if(!regex.test(data[i].rate))
    {
      alert('Rate is invalid')
    }
    else if(!regex.test(data[i].amount))
    {
      alert('Amount is invalid')
    }
    else
    {
    setData([...data,{itemName:"",quantity:"",rate:"",amount:""}])
    /*
    sbTotal= parseInt(order.subTotal) + parseInt(data[i].amount);
     order.subTotal=sbTotal;*/
    }
  }
  }
    else
    {
      alert("Invalid item details"); 
     }
}
const handleChangeItems=(e,i)=>{
    const {name,value}=e.target
    console.log(data);
    const onchangeVal = [...data]
      
      if(e.target.name==="quantity" || e.target.name==="rate")
      {
            onchangeVal[i][name]=value
            if(onchangeVal[i]["quantity"] && onchangeVal[i]["rate"])
            {
              total=parseInt(onchangeVal[i]["quantity"]) * parseInt(onchangeVal[i]["rate"]);
              onchangeVal[i]["amount"]=total;
            } 
            setData(onchangeVal)
            CalculateTotal()
      }
      else if(e.target.name==="itemId")
      {
        let item_id=e.target.value;
        if(item_id!=='')
        {
       
          axios.get(url+'/item/readone/'+item_id)
          .then((getData) => {
            console.log(getData.data);

            onchangeVal[i]["rate"]=getData.data.sellingPrice;
            onchangeVal[i]["itemName"]=getData.data.itemName;
            onchangeVal[i]["brand"]=getData.data.brand;
            onchangeVal[i]["itemId"]=e.target.value;
            setData(onchangeVal);          
          })  
        }
      }
     total=0;
}

const handleDelete=(i)=>{
  if(i===0)
  {
    setData([{itemName:'--select Item--',quantity:0,rate:0,amount:0,itemId:''}]);
  }
  else
  {
   
    const deleteVal = [...data]
    deleteVal.splice(i,1)
    setData(deleteVal)
    let sum=0;
 
  for(let i=0;i<deleteVal.length;i++)
  {
     sum=sum+parseInt(deleteVal[i]["amount"]);
  }
  setCredit({...credit,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(credit.discount))})
  }
  //CalculateTotal();
}
const sendDataToAPI = async(event)=>{
  console.log(credit,"credit")
  const {customerId, invoiceNumber, date,subTotal,discount,total,status}=credit

 if(customerId && date && subTotal && total && status)
 {     
  if(customerId ==="--Select Customer--")
  {
    alert("Select Customer");
  }
  else if(status ==="--Select Status--")
  {
    alert("Select Status");
  }
  else
  {
    let regex=/^(\d*([.,](?=\d{3}))?\d+)+((?!\2)[.,]\d\d)?$/;
    if(!regex.test(subTotal))
    {
      alert('Sub Total is invalid')
    }
    else if(!regex.test(discount))
    {
      alert('Discount is invalid')
    }
    if(!regex.test(total))
    {
      alert('Total is invalid')
    }
   else{
    
     console.log(credit,"credit");
    const response= await  axios.post(url+`/credit/create`,credit)
    if(response.data.success)
    {
        const onchangeVal = [...data];
        for( let i=0;i<data.length;i++)
        {
          onchangeVal[i]["creditNoteId"]=response.data.data._id
        }
        let new_list = onchangeVal.map(function(obj) {
          
          return {
            itemName: obj.itemName,
            creditNoteId:obj.creditNoteId,
            quantity: obj.quantity,
            rate: obj.rate,
            amount : obj.amount,
            brand  : obj.brand,
            invoiceId: obj.invoiceId,
            itemId: obj.itemId,
            inventoryId: obj.inventoryId,
            quantityIn: obj.quantityIn
          }})
        console.log(new_list,"new_list");
        const Detailsresponse= await  axios.post(url+`/credit/createDetails/`,new_list)
        if(Detailsresponse.data.success)
        {
          let Inventory={};
          var Inventoryresponse="";
          let successcount=0; 
          let success=false;
          for (let i= 0; i<new_list.length; i++) 
          {
          if(status ==="Open" ||status ==="Closed" )
            {
             
             Inventory={};
         Inventory=
         {         
             "quantityIn":parseInt(new_list[i].quantity) +parseInt(new_list[i].quantityIn)
         }
         console.log(Inventory,"Inventory");
         Inventoryresponse=await axios.put(url+`/item/updateQtyIn/`+new_list[i].inventoryId,Inventory)
         if(Inventoryresponse.data.success)
         {
               successcount++;
         }
        }  
        else
        {
          success=true;
        }
       }
       if(successcount===new_list.length)
       {
         success=true;
        }
        if(success)
        {
          alert("Credit Note created successfully");
          navigate('/creditnote');
        }
        else
        {
          alert("Credit Note creation failed");
        }
        }
        
      }
    else
    {
      alert("Credit Note creation failed");
    }
  }
}
}
 else
{
   alert("Invalid Input");  
}
}

    const handleChange=e=>{
      
        const {name,value}=e.target
        const {subTotal}=credit;
  
        if( e.target.name ==='discount')
        {
          setCredit({...credit,[name]:value,["total"]:(parseInt(subTotal) - parseInt(value))})
        }
        else if(e.target.name ==='customerId')
        {
        //  alert(e.target.value);
          const custId=e.target.value;
         if(custId!=='')
          {
          axios.get(url+'/customer/readone/'+custId)
          .then((getData) => {
            let custName = getData.data.name;
            setCredit({...credit,[name]:value,["customerName"]:custName})
          })        
              
            axios.get(url+'/invoice/invoiceByCustomer/'+custId)
            .then((getData) => {
              setSales(getData.data);      
           })  
          }

        
        }
        else  if(e.target.name==="invoiceId")
        {
          let item_id=e.target.value;     
          if(item_id!=='')
          {   
            axios.get(url+'/invoice/readone/'+item_id)
            .then((getData) => {   
              console.log(getData.data);     
               setCredit({...credit,[name]:value,["invoiceNumber"]:getData.data.invoiceNumber,["subTotal"]:getData.data.subTotal,["discount"]:getData.data.discount,["total"]:getData.data.total})
            })
console.log(credit)
            
            axios.get(url+'/invoice/readDetails/'+item_id)
            .then((getData)=>{
              setData(getData.data);      

              const onchangeVal = getData.data
              for( let i=0;i< getData.data.length;i++)
              {
                 axios.get(url+'/item/readoneitem/'+ onchangeVal[i]["itemId"])
                .then((response) => {
                  onchangeVal[i]["quantityIn"]=response.data.quantityIn;
                  onchangeVal[i]["inventoryId"]=response.data._id;
                })
                          }
            
              console.log(onchangeVal,"onchangeVal")
             setData(onchangeVal)
            })
          }
        }
        else
        {
            setCredit({...credit,[name]:value});
        }
     console.log(credit);
      
     }
  

const CalculateTotal=()=>
{
  let sum=0;
 
  for(let i=0;i<data.length;i++)
  {
     sum=sum+parseInt(data[i]["amount"]);
  }
  setCredit({...credit,["subTotal"]:sum,["total"]:(parseInt(sum) - parseInt(credit.discount))})
 
}
  return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Credit Note</h1>
        <Link to="/creditnote">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">

            <Header as='h3'>New Credit Note</Header>
            <Segment>
              <Form>
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  {visible &&       <select id="Select" name='customerId'  onChange={handleChange} >
                  <option>--Select Customer--</option>
                  {customer.map((cust,index)=>{return(<option key={index} value={cust._id}>{cust.name}</option> )})} </select>
  }
   {!visible &&
 <label>{credit.customerName}</label>}
                  </span>
               </div> </Form.Field>
               <Form.Field>
              <div className="salesInfoTotals">
                  <label>Invoice</label>
                  <span className="salesTotalsValue"> 
            {visible &&      <select id="Select" name='invoiceId'  onChange={handleChange} >
                  <option>--Select Invoice--</option>
                  {sales.map((so,index)=>{return(<option key={index} value={so._id}>{so.invoiceNumber}</option> )})} </select>
  }
   {!visible &&
 <label>{credit.invoiceNumber}</label>}
                  </span>
               </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Credit Note Number</label>
                  <span className="salesTotalsValue"> 
                  <input required name='creditNoteNumber' value={credit.creditNoteNumber} onChange={handleChange}  placeholder='Credit Note Number'  />
                </span></div>
                
                </Form.Field>
               
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                  <input type='date' required name='date' value={credit.date} onChange={handleChange}   placeholder='Date'  />
               </span> </div></Form.Field>
                
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <input  name='reference' value={credit.reference} onChange={handleChange}   placeholder='Reference'  />
            </span>  </div>  </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Person</label>
                  <span className="salesTotalsValue"> 
                  <input  name='salesPerson' value={credit.salesPerson} onChange={handleChange}  placeholder='Sales Person'  />
              </span></div>  </Form.Field>

                {
                data.map((val,i)=>

                <div className='itemContainerbox'  key={i}>
                <Form.Field>
                <div className='itemRow'>
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                  <label></label> </div>
                </Form.Field>
                <Form.Field>
                <div className='itemRow'>
                <span className='productInfoValue'> 
               <select  id="Select" name='itemId'  onChange={(e)=>handleChangeItems(e,i)} placeholder='Item' >
               <option>--Select Item--</option>
                  {item.map((ds,index)=>{return(<option key={index} value={ds._id}
                  selected={ds._id === val.itemId}
                  > {ds.itemName}</option> )})} </select>
            </span>
             <span className='productInfoValue'> 
              <input  required name='quantity' value={val.quantity} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Quantity'  />
             </span> 
             <span className='productInfoValue'> 
              <input className='productInfoValue' required name='rate' value={val.rate} onChange={(e)=>handleChangeItems(e,i)}  placeholder='Rate'  />
             </span>
             <span className='productInfoValue'> 
              <input required name='amount' value={val.amount} onChange={(e)=>handleChangeItems(e,i)} placeholder='Amount'  />
              </span>
              
              
              <DeleteOutline 
                className="productListDelete" onClick={()=>handleDelete(i)}
                   />
            
              <button className="productListEdit"  onClick={()=>handleAddmoreClick(i)}>Add More Item</button>
           </div> 
              </Form.Field>
              <Form.Field>

              </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft">
              
          </div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue">  <input required name='subTotal' value={credit.subTotal} onChange={handleChange}   placeholder='Sub Total'  />
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <input required name='discount' value={credit.discount} onChange={handleChange}  placeholder='Discount'  />
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                 <input required name='total' value={credit.total} onChange={handleChange}   placeholder='Total'  />
                </span> </div>
                </Form.Field> 
               
                 </div>     </div>        
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                   <span className="salesTotalsValue"> 
                  <select id="Select" name='status' value={credit.status} onChange={handleChange} className="form-control form-control-md"   placeholder="Select Status" required>
                                 
                  <option>--Select Status--</option>
    <option>Draft</option>
      <option>Open</option>     
      <option>Send</option>
       <option>Closed</option>
    </select></span>
               </div> </Form.Field>       
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Submit</Button>
                <Button size='mini' color='grey'>
                  <Link to='/creditnote' style={{ color: '#FFF' }}>Cancel</Link>
                </Button>
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default CreditNote