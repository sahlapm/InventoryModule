
import { Button, Segment, Form,Header, StatisticGroup } from 'semantic-ui-react';
import axios from 'axios';
import React, { useState,useEffect } from 'react';
import {useParams,useNavigate,Link} from 'react-router-dom' 


const CreditNoteView = () => {
  const url="http://localhost:5000/api";
  const navigate=useNavigate();  
  const [data,setData]=useState([]);
  const [item, setItem] = useState([]);
 
  const [credit,setCredit]=useState({});
  const [status,setStatus]=useState({});    
  let params=useParams();   
  let Id=params.id;


useEffect(() => {  
 FillCredit();
 FillDetails();
},[])


const FillCredit=()=>
{         
  axios.get(url+'/credit/readone/'+Id)
  .then((getData)=>{
    setCredit(getData.data);     
  })
}
const FillDetails=()=>
{
         
  axios.get(url+'/credit/readDetails/'+Id)
  .then((getData)=>{
    setData(getData.data);   
    console.log(getData.data,"ghf"); 
  })
}



const sendDataToAPI = async(event)=>{
  
alert(Id);
const OrderStatus=
{
  "_id":Id,
    "status":status
}
      const response= await  axios.put(url+`/credit/updateStatus/`+Id,OrderStatus)
      if(response.data.success)
      {
        
        let success=false;
        if(status ==="Open" ||status ==="Closed" )
       {
        let  Inventory={};
        let successcount=0;
        var Inventoryresponse="";
        
        for (let i= 0; i<data.length; i++) {
          axios.get(url+'/item/readoneitem/'+data[i].itemId)
          .then((getData) => {
             Inventory={};
          Inventory=
          {         
              "quantityIn":parseInt(data[i].quantity) +parseInt(getData.data.quantityIn)
          }
           console.log(Inventory,"Inventory")
          /**/Inventoryresponse= axios.put(url+`/item/updateQtyIn/`+getData.data._id,Inventory)
          
          if(Inventoryresponse.data.success )
          {
            successcount++;
          }
         
        
          if(successcount===data.length)
          {
            success=true;
            }
    
          })
      
          }


      }
        alert("Status updated successfully");        
      }
      else
      {
        alert("Status updation failed");
      }
}

 return (
    <div className="product">
      <div className='itemContainer'>
      <div className="productTitleContainer">
        <h1 className="productTitle">Credit Note</h1>
       
        <Link to="/creditNote">
          <button className="productAddButton">Back</button>
        </Link>
      </div>
      <div className="place-holder">
            <Segment>
              <Form>
                <div className='salesbottom'>
              <div className="salesLeft">
              <Form.Field>
              <div className="salesInfoTotals">
                  <label>Customer Name</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.customerName}</label>

                  </span>
               </div> </Form.Field>
            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Credit Note Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.creditNoteNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Invoice Number</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.invoiceNumber}</label>
                </span></div>
                
                </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Reference</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.reference}</label>
              </span> </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                <label>Date</label>
                <span className="salesTotalsValue"> 
                <label>{credit.date}</label>
               </span> </div></Form.Field>
                              <Form.Field>
                <div className="salesInfoTotals">
                  <label>Sales Person</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.salesPerson}</label>
            </span>  </div>  </Form.Field>            
               
               <Form.Field>
                <div className="salesInfoTotals">
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.status}</label>
              </span></div> 
               </Form.Field>
               </div>
         </div>
                {
                data.map((val,i)=>

                <div className='itemContainer'  key={i}>
                <Form.Field>
                <div className="itemRow">
                  <label>Item</label><label>Quantity</label><label>Rate</label> <label>Amount</label>
                   </div>
                </Form.Field>
                <Form.Field>
                <div className="itemRow">
                  <label>{val.itemName}</label><label>{val.quantity}</label><label>{val.rate}</label> <label>{val.amount}</label>
                   </div>
                </Form.Field>
            
                </div>
                )
}
                <div className="salesbottom">
                <div className="salesLeft"></div>
          <div className="salesRight">
                <Form.Field>
                <div className="salesInfoTotals">
             <span>  <label>SubTotal</label></span> 
               <span className="salesTotalsValue"> 
               <label>{credit.subTotal}</label>
                 </span>  </div>   </Form.Field>            
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Discount</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.discount}</label>
             </span>  </div> </Form.Field>
                <Form.Field>
                <div className="salesInfoTotals">
                  <label>Total</label>
                  <span className="salesTotalsValue"> 
                  <label>{credit.total}</label>
                </span> </div>
                </Form.Field>  </div>  
                   </div>    
                   <div className='itemContainer'>   
                <Header as='h3'> Update Status</Header>
                 <Form.Field>
                <div className="salesInfoTotals">
               
                
                  <label>Status</label>
                  <span className="salesTotalsValue"> 
                  <select id="Select" name='status' onChange={(event) => {
                            setStatus(event.target.value);
                        }} className="form-control form-control-md"   placeholder="Area of Training" required>
                                 
                  <option>--Select Status--</option>
                  <option>Draft</option>
      <option>Open</option>     
      <option>Send</option>
       <option>Closed</option>
    </select>
                  </span>
                  
                   </div>    </Form.Field>
                               <Button size='mini' color='grey' type='submit' onClick={sendDataToAPI} >Update status</Button>
                <Button size='mini' color='grey'>
                  <Link to='/challans' style={{ color: '#FFF' }}>Cancel</Link>
                </Button></div> 
              </Form>
            </Segment>
          </div></div>
    </div>
  )
}

export default CreditNoteView